##Review the [Wiki](https://github.com/carlosmach/api_architecture/wiki) for documentation
