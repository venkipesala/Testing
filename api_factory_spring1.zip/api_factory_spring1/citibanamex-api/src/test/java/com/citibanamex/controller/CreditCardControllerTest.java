package com.citibanamex.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;


public class CreditCardControllerTest {
	 @Autowired
	    private MockMvc mockMvc;
		
	    @Test
	    public void testGetCards() throws Exception {
	        this.mockMvc.perform(get("/cards")).andExpect(status().isOk());

	    }
}
