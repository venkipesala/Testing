package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.citi.gcgi.services.common.esms.v115_1_0_0 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _LostStolenRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "LostStolenRq");
    private final static QName _CreateNewMessageRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "CreateNewMessageRq");
    private final static QName _LostStolenRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "LostStolenRs");
    private final static QName _CreateNewMessageRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "CreateNewMessageRs");
    private final static QName _AutoFulfillmentRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "AutoFulfillmentRs");
    private final static QName _MessageDetailInqRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "MessageDetailInqRs");
    private final static QName _DeleteMessageRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "DeleteMessageRq");
    private final static QName _LogonRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "LogonRs");
    private final static QName _SaveMessageRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "SaveMessageRs");
    private final static QName _SaveMessageRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "SaveMessageRq");
    private final static QName _SendMessageRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "SendMessageRs");
    private final static QName _DeleteMessageRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "DeleteMessageRs");
    private final static QName _MessageDetailInqRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "MessageDetailInqRq");
    private final static QName _LogonRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "LogonRq");
    private final static QName _PersonalCreditLimitMaintenanceRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "PersonalCreditLimitMaintenanceRs");
    private final static QName _PersonalCreditLimitMaintenanceRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "PersonalCreditLimitMaintenanceRq");
    private final static QName _SendMessageRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "SendMessageRq");
    private final static QName _ListSavedMessageRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "ListSavedMessageRq");
    private final static QName _ListSavedMessageRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "ListSavedMessageRs");
    private final static QName _AutoFulfillmentRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "AutoFulfillmentRq");
    private final static QName _ListMessageInqRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "ListMessageInqRq");
    private final static QName _ListMessageInqRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", "ListMessageInqRs");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.citi.gcgi.services.common.esms.v115_1_0_0
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DeleteMessageRs }
     * 
     */
    public DeleteMessageRs createDeleteMessageRs() {
        return new DeleteMessageRs();
    }

    /**
     * Create an instance of {@link MessageDetailInqRq }
     * 
     */
    public MessageDetailInqRq createMessageDetailInqRq() {
        return new MessageDetailInqRq();
    }

    /**
     * Create an instance of {@link LogonRq }
     * 
     */
    public LogonRq createLogonRq() {
        return new LogonRq();
    }

    /**
     * Create an instance of {@link SendMessageRs }
     * 
     */
    public SendMessageRs createSendMessageRs() {
        return new SendMessageRs();
    }

    /**
     * Create an instance of {@link SaveMessageRq }
     * 
     */
    public SaveMessageRq createSaveMessageRq() {
        return new SaveMessageRq();
    }

    /**
     * Create an instance of {@link MessageDetailInqRs }
     * 
     */
    public MessageDetailInqRs createMessageDetailInqRs() {
        return new MessageDetailInqRs();
    }

    /**
     * Create an instance of {@link DeleteMessageRq }
     * 
     */
    public DeleteMessageRq createDeleteMessageRq() {
        return new DeleteMessageRq();
    }

    /**
     * Create an instance of {@link LogonRs }
     * 
     */
    public LogonRs createLogonRs() {
        return new LogonRs();
    }

    /**
     * Create an instance of {@link SaveMessageRs }
     * 
     */
    public SaveMessageRs createSaveMessageRs() {
        return new SaveMessageRs();
    }

    /**
     * Create an instance of {@link AutoFulfillmentRs }
     * 
     */
    public AutoFulfillmentRs createAutoFulfillmentRs() {
        return new AutoFulfillmentRs();
    }

    /**
     * Create an instance of {@link LostStolenRs }
     * 
     */
    public LostStolenRs createLostStolenRs() {
        return new LostStolenRs();
    }

    /**
     * Create an instance of {@link CreateNewMessageRs }
     * 
     */
    public CreateNewMessageRs createCreateNewMessageRs() {
        return new CreateNewMessageRs();
    }

    /**
     * Create an instance of {@link LostStolenRq }
     * 
     */
    public LostStolenRq createLostStolenRq() {
        return new LostStolenRq();
    }

    /**
     * Create an instance of {@link CreateNewMessageRq }
     * 
     */
    public CreateNewMessageRq createCreateNewMessageRq() {
        return new CreateNewMessageRq();
    }

    /**
     * Create an instance of {@link ListMessageInqRs }
     * 
     */
    public ListMessageInqRs createListMessageInqRs() {
        return new ListMessageInqRs();
    }

    /**
     * Create an instance of {@link ListMessageInqRq }
     * 
     */
    public ListMessageInqRq createListMessageInqRq() {
        return new ListMessageInqRq();
    }

    /**
     * Create an instance of {@link AutoFulfillmentRq }
     * 
     */
    public AutoFulfillmentRq createAutoFulfillmentRq() {
        return new AutoFulfillmentRq();
    }

    /**
     * Create an instance of {@link ListSavedMessageRs }
     * 
     */
    public ListSavedMessageRs createListSavedMessageRs() {
        return new ListSavedMessageRs();
    }

    /**
     * Create an instance of {@link ListSavedMessageRq }
     * 
     */
    public ListSavedMessageRq createListSavedMessageRq() {
        return new ListSavedMessageRq();
    }

    /**
     * Create an instance of {@link PersonalCreditLimitMaintenanceRq }
     * 
     */
    public PersonalCreditLimitMaintenanceRq createPersonalCreditLimitMaintenanceRq() {
        return new PersonalCreditLimitMaintenanceRq();
    }

    /**
     * Create an instance of {@link SendMessageRq }
     * 
     */
    public SendMessageRq createSendMessageRq() {
        return new SendMessageRq();
    }

    /**
     * Create an instance of {@link PersonalCreditLimitMaintenanceRs }
     * 
     */
    public PersonalCreditLimitMaintenanceRs createPersonalCreditLimitMaintenanceRs() {
        return new PersonalCreditLimitMaintenanceRs();
    }

    /**
     * Create an instance of {@link RequestList }
     * 
     */
    public RequestList createRequestList() {
        return new RequestList();
    }

    /**
     * Create an instance of {@link MisGroupdDetails }
     * 
     */
    public MisGroupdDetails createMisGroupdDetails() {
        return new MisGroupdDetails();
    }

    /**
     * Create an instance of {@link MisTypeDetails }
     * 
     */
    public MisTypeDetails createMisTypeDetails() {
        return new MisTypeDetails();
    }

    /**
     * Create an instance of {@link RequestDetails }
     * 
     */
    public RequestDetails createRequestDetails() {
        return new RequestDetails();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LostStolenRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "LostStolenRq")
    public JAXBElement<LostStolenRq> createLostStolenRq(LostStolenRq value) {
        return new JAXBElement<LostStolenRq>(_LostStolenRq_QNAME, LostStolenRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateNewMessageRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "CreateNewMessageRq")
    public JAXBElement<CreateNewMessageRq> createCreateNewMessageRq(CreateNewMessageRq value) {
        return new JAXBElement<CreateNewMessageRq>(_CreateNewMessageRq_QNAME, CreateNewMessageRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LostStolenRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "LostStolenRs")
    public JAXBElement<LostStolenRs> createLostStolenRs(LostStolenRs value) {
        return new JAXBElement<LostStolenRs>(_LostStolenRs_QNAME, LostStolenRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateNewMessageRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "CreateNewMessageRs")
    public JAXBElement<CreateNewMessageRs> createCreateNewMessageRs(CreateNewMessageRs value) {
        return new JAXBElement<CreateNewMessageRs>(_CreateNewMessageRs_QNAME, CreateNewMessageRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AutoFulfillmentRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "AutoFulfillmentRs")
    public JAXBElement<AutoFulfillmentRs> createAutoFulfillmentRs(AutoFulfillmentRs value) {
        return new JAXBElement<AutoFulfillmentRs>(_AutoFulfillmentRs_QNAME, AutoFulfillmentRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MessageDetailInqRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "MessageDetailInqRs")
    public JAXBElement<MessageDetailInqRs> createMessageDetailInqRs(MessageDetailInqRs value) {
        return new JAXBElement<MessageDetailInqRs>(_MessageDetailInqRs_QNAME, MessageDetailInqRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteMessageRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "DeleteMessageRq")
    public JAXBElement<DeleteMessageRq> createDeleteMessageRq(DeleteMessageRq value) {
        return new JAXBElement<DeleteMessageRq>(_DeleteMessageRq_QNAME, DeleteMessageRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LogonRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "LogonRs")
    public JAXBElement<LogonRs> createLogonRs(LogonRs value) {
        return new JAXBElement<LogonRs>(_LogonRs_QNAME, LogonRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveMessageRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "SaveMessageRs")
    public JAXBElement<SaveMessageRs> createSaveMessageRs(SaveMessageRs value) {
        return new JAXBElement<SaveMessageRs>(_SaveMessageRs_QNAME, SaveMessageRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveMessageRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "SaveMessageRq")
    public JAXBElement<SaveMessageRq> createSaveMessageRq(SaveMessageRq value) {
        return new JAXBElement<SaveMessageRq>(_SaveMessageRq_QNAME, SaveMessageRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendMessageRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "SendMessageRs")
    public JAXBElement<SendMessageRs> createSendMessageRs(SendMessageRs value) {
        return new JAXBElement<SendMessageRs>(_SendMessageRs_QNAME, SendMessageRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteMessageRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "DeleteMessageRs")
    public JAXBElement<DeleteMessageRs> createDeleteMessageRs(DeleteMessageRs value) {
        return new JAXBElement<DeleteMessageRs>(_DeleteMessageRs_QNAME, DeleteMessageRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MessageDetailInqRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "MessageDetailInqRq")
    public JAXBElement<MessageDetailInqRq> createMessageDetailInqRq(MessageDetailInqRq value) {
        return new JAXBElement<MessageDetailInqRq>(_MessageDetailInqRq_QNAME, MessageDetailInqRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LogonRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "LogonRq")
    public JAXBElement<LogonRq> createLogonRq(LogonRq value) {
        return new JAXBElement<LogonRq>(_LogonRq_QNAME, LogonRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PersonalCreditLimitMaintenanceRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "PersonalCreditLimitMaintenanceRs")
    public JAXBElement<PersonalCreditLimitMaintenanceRs> createPersonalCreditLimitMaintenanceRs(PersonalCreditLimitMaintenanceRs value) {
        return new JAXBElement<PersonalCreditLimitMaintenanceRs>(_PersonalCreditLimitMaintenanceRs_QNAME, PersonalCreditLimitMaintenanceRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PersonalCreditLimitMaintenanceRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "PersonalCreditLimitMaintenanceRq")
    public JAXBElement<PersonalCreditLimitMaintenanceRq> createPersonalCreditLimitMaintenanceRq(PersonalCreditLimitMaintenanceRq value) {
        return new JAXBElement<PersonalCreditLimitMaintenanceRq>(_PersonalCreditLimitMaintenanceRq_QNAME, PersonalCreditLimitMaintenanceRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendMessageRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "SendMessageRq")
    public JAXBElement<SendMessageRq> createSendMessageRq(SendMessageRq value) {
        return new JAXBElement<SendMessageRq>(_SendMessageRq_QNAME, SendMessageRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListSavedMessageRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "ListSavedMessageRq")
    public JAXBElement<ListSavedMessageRq> createListSavedMessageRq(ListSavedMessageRq value) {
        return new JAXBElement<ListSavedMessageRq>(_ListSavedMessageRq_QNAME, ListSavedMessageRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListSavedMessageRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "ListSavedMessageRs")
    public JAXBElement<ListSavedMessageRs> createListSavedMessageRs(ListSavedMessageRs value) {
        return new JAXBElement<ListSavedMessageRs>(_ListSavedMessageRs_QNAME, ListSavedMessageRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AutoFulfillmentRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "AutoFulfillmentRq")
    public JAXBElement<AutoFulfillmentRq> createAutoFulfillmentRq(AutoFulfillmentRq value) {
        return new JAXBElement<AutoFulfillmentRq>(_AutoFulfillmentRq_QNAME, AutoFulfillmentRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListMessageInqRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "ListMessageInqRq")
    public JAXBElement<ListMessageInqRq> createListMessageInqRq(ListMessageInqRq value) {
        return new JAXBElement<ListMessageInqRq>(_ListMessageInqRq_QNAME, ListMessageInqRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListMessageInqRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", name = "ListMessageInqRs")
    public JAXBElement<ListMessageInqRs> createListMessageInqRs(ListMessageInqRs value) {
        return new JAXBElement<ListMessageInqRs>(_ListMessageInqRs_QNAME, ListMessageInqRs.class, null, value);
    }

}
