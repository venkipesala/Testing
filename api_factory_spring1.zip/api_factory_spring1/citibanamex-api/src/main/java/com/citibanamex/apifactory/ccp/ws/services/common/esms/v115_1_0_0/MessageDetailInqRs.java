package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.citibanamex.apifactory.ccp.ws.shared.util.v3_0_0_0.GenericResponse;


/**
 * <p>Java class for MessageDetailInqRs complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MessageDetailInqRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_0_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="Description" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}Description"/>
 *         &lt;element name="FromToFlag" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}FromToFlag"/>
 *         &lt;element name="ReferenceNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}ReferenceNo"/>
 *         &lt;element name="RequestDate" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}RequestDate"/>
 *         &lt;element name="RequestDetails" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}RequestDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="RequestTime" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}RequestTime"/>
 *         &lt;element name="Subject" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}Subject"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageDetailInqRs", propOrder = {
    "description",
    "fromToFlag",
    "referenceNo",
    "requestDate",
    "requestDetails",
    "requestTime",
    "subject"
})
public class MessageDetailInqRs
    extends GenericResponse
{

    @XmlElement(name = "Description", required = true)
    protected String description;
    @XmlElement(name = "FromToFlag", required = true)
    protected String fromToFlag;
    @XmlElement(name = "ReferenceNo", required = true)
    protected String referenceNo;
    @XmlElement(name = "RequestDate", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar requestDate;
    @XmlElement(name = "RequestDetails")
    protected List<RequestDetails> requestDetails;
    @XmlElement(name = "RequestTime", required = true)
    @XmlSchemaType(name = "time")
    protected XMLGregorianCalendar requestTime;
    @XmlElement(name = "Subject", required = true)
    protected String subject;

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the fromToFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromToFlag() {
        return fromToFlag;
    }

    /**
     * Sets the value of the fromToFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromToFlag(String value) {
        this.fromToFlag = value;
    }

    /**
     * Gets the value of the referenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceNo() {
        return referenceNo;
    }

    /**
     * Sets the value of the referenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceNo(String value) {
        this.referenceNo = value;
    }

    /**
     * Gets the value of the requestDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the value of the requestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRequestDate(XMLGregorianCalendar value) {
        this.requestDate = value;
    }

    /**
     * Gets the value of the requestDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the requestDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequestDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RequestDetails }
     * 
     * 
     */
    public List<RequestDetails> getRequestDetails() {
        if (requestDetails == null) {
            requestDetails = new ArrayList<RequestDetails>();
        }
        return this.requestDetails;
    }

    /**
     * Gets the value of the requestTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRequestTime() {
        return requestTime;
    }

    /**
     * Sets the value of the requestTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRequestTime(XMLGregorianCalendar value) {
        this.requestTime = value;
    }

    /**
     * Gets the value of the subject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubject() {
        return subject;
    }

    /**
     * Sets the value of the subject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubject(String value) {
        this.subject = value;
    }

}
