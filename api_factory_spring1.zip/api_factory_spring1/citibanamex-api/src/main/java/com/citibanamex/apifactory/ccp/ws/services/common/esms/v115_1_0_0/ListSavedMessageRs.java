package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.citibanamex.apifactory.ccp.ws.shared.util.v3_0_0_0.GenericResponse;

/**
 * <p>Java class for ListSavedMessageRs complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListSavedMessageRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_0_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="RequestList" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}RequestList" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListSavedMessageRs", propOrder = {
    "requestList"
})
public class ListSavedMessageRs
    extends GenericResponse
{

    @XmlElement(name = "RequestList")
    protected List<RequestList> requestList;

    /**
     * Gets the value of the requestList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the requestList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequestList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RequestList }
     * 
     * 
     */
    public List<RequestList> getRequestList() {
        if (requestList == null) {
            requestList = new ArrayList<RequestList>();
        }
        return this.requestList;
    }

}
