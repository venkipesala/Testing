@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.citi.com/gcgi/shared/system/fault", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.citibanamex.apifactory.ccp.ws.shared.system.fault;
