/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

package com.citibanamex.apifactory.ccp.service;

import java.util.List;

import com.citibanamex.apifactory.ccp.model.CreditCard;

import org.json.JSONException;

/**
 * The service class for the credit card lock and unlock functionality.
 *
 * @author Venkateswarlu Pesala
 *
 */
public interface CreditCardService {

	/**
	 * Retrieve all cards from the account.
	 * @return List<> list of cards.
	 * @throws JSONException if any JSON error.
	 */
	List<CreditCard> getCards() throws JSONException;

	/**
	 * Retrieve specific credit card details.
	 *
	 * @param cardNumber to retrieve specific card details.
	 * @return CreditCard details.
	 * @throws JSONException if any JSON error.
	 */
	CreditCard getCard(String cardNumber) throws JSONException;

	/**
	 * Unlock the card.
	 *
	 * @param id
	 *            to unlock the card.
	 * @param status to update the status of the card.
	 * @return String returns unlock status.
	 */
	CreditCard updateCardStatus(String id, String status);

	/**
	 * Get the status of the Card.
	 *
	 * @param id
	 *            to unlock the card.
	 * @return String returns unlock status.
	 */
	CreditCard getCardStatus(String id);
}
