/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

package com.citibanamex.apifactory.ccp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
//import org.springframework.cloud.netflix.hystrix.EnableHystrix;

/**
 * Credit Card Lock and Unlock Micro service.
 * @author Venkateswarlu Pesala
 *
 */
@SpringBootApplication
//@EnableHystrix
//@EnableEurekaClient
public class CreditCardApplication {
//	private CreditCardUnlockApplication() {
//        // Prevent instantiation
//	}

	public static void main(String[] args) {
		SpringApplication.run(CreditCardApplication.class, args);
	}

}
