/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

package com.citibanamex.apifactory.ccp.serviceimpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;

import com.citibanamex.apifactory.ccp.model.CreditCard;
import com.citibanamex.apifactory.ccp.service.CreditCardService;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.LostStolenRq;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.LostStolenRs;
import com.citibanamex.apifactory.ccp.ws.shared.system.header.ClientDetails;
import com.citibanamex.apifactory.ccp.ws.shared.system.header.RqHeader;
import com.citibanamex.apifactory.ccp.ws.shared.system.header.RsHeader;
import com.citibanamex.apifactory.ccp.ws.wsdls.common.esms.v115_1_0_0.EsmsService;
import com.citibanamex.apifactory.ccp.ws.wsdls.common.esms.v115_1_0_0.Fault;
import com.citibanamex.apifactory.ccp.ws.wsdls.common.esms.v115_1_0_0.Op;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

/**
 * The service class for the credit card lock and unlock functionality.
 *
 * @author Venkateswarlu Pesala
 *
 */
@Service
public class CreditCardServiceImpl implements CreditCardService {

	
	/**
	 * Update status of the card either lock or unlock.
	 *
	 * @param id
	 *            to update the card status.
	 * @return CreditCard returns status of the card.
	 */
	@Override
	public CreditCard updateCardStatus(String id, String status) {
		CreditCard card = new CreditCard();
		card.setEmbosserName("ZZYYYYXXZZZZYYZXX");
		card.setCardNumber(id);
		card.setCurrentBalance("35.52");
		card.setCardType("S");
		card.setCardStatus("0");
		card.setCardCashLimit(0);
		card.setLastPaymentDate("12112017");
		card.setBlockCode("");
		card.setCardStatus(status);
		
//		EsmsService esmsService = new EsmsService();
//				
//		Op operations = esmsService.getOpEndpointHTTP();
//		
//		LostStolenRq lostStolenRq = new LostStolenRq();
//		lostStolenRq.setBlockCode("L");
//		lostStolenRq.setCardNumber("543610984567");
//		lostStolenRq.setEmbossName("PETER");
//		lostStolenRq.setEmergencyReplInd("Y");
//		lostStolenRq.setNewCardExpDate("2019-01-01");
//		lostStolenRq.setPlasticId("456");
//		lostStolenRq.setPlasticIndicator("1");
//		lostStolenRq.setReasonCode("01");
//		lostStolenRq.setReplaceInd24Hr("Y");
//		lostStolenRq.setReplacementMethod("1");
//		lostStolenRq.setRequestFlag("B");
//		
//		RqHeader rqHeader = new RqHeader();
//		DatatypeFactory dataTypeFactory = null;
//		try {
//			dataTypeFactory = DatatypeFactory.newInstance();
//		} catch (DatatypeConfigurationException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		XMLGregorianCalendar dateTimeStamp = dataTypeFactory.newXMLGregorianCalendar("2017-03-28T19:23:26.047-05:00");
//		rqHeader.setDateAndTimeStamp(dateTimeStamp);
//		rqHeader.setUUID("1234");
//		ClientDetails clientDetails = new ClientDetails();
//		clientDetails.setOrg("CITI");
//		clientDetails.setOrgUnit("CITI");
//		clientDetails.setChannelID("BMX");
//		clientDetails.setTerminalID("0000");
//		clientDetails.setUserID("CITI");
//		clientDetails.setSrcCountryCode("SrcCountryCode");
//		clientDetails.setDestCountryCode("MX");		
//		rqHeader.setClientDetails(clientDetails);
//		
//		LostStolenRs lostStolenRs = null;
//		
//		Holder<RsHeader> rsHeader = null;
//		
//		try {
////			lostStolenRs = operations.lostStolen(lostStolenRq, header, header0);
//			lostStolenRs = operations.lostStolen(lostStolenRq, rqHeader, rsHeader);
//		} catch(Fault e) {
//			System.out.println(e.getMessage());
//		}
		
		
		return card;
	}

	/**
	 * Get status of the card.
	 *
	 * @param id
	 *            to get the card status.
	 * @return CreditCard returns status of the card.
	 */
	@Override
	public CreditCard getCardStatus(String id) {
		CreditCard card = new CreditCard();
		card.setEmbosserName("ZZYYYYXXZZZZYYZXX");
		card.setCardNumber(id);
		card.setCurrentBalance("35.52");
		card.setCardType("S");
		card.setCardStatus("0");
		card.setCardCashLimit(0);
		card.setLastPaymentDate("12112017");
		card.setBlockCode("");
		card.setCardStatus("UnBlocked");
		return card;
	}

	/**
	 * Function to get list of cards.
	 * @return List<> list of credit cards.
	 * @throws JSONException if any JSON error.
	 */
	@Override
	public List<CreditCard> getCards() throws JSONException {
		List<CreditCard> cards = new ArrayList<CreditCard>();
		CreditCard card;
		JSONObject result = null;
		String crudResponse = null;
		JSONObject jsnobject = null;
		JSONArray jsonArray = null;
		crudResponse = getCRUDConnectorResponse();
		jsnobject = new JSONObject(crudResponse).getJSONObject("GBOF0003OperationResponse")
				.getJSONObject("getRelationshipAcctRes");
		jsonArray = jsnobject.getJSONArray("accountInfoTable");

		for (int i = 0; i < jsonArray.length(); i++) {
			card = new CreditCard();
			result = jsonArray.getJSONObject(i);
			card.setEmbosserName(result.getString("embosserName"));
			card.setCardNumber(result.getString("responseCardNumber"));
			Double currentBal = result.getDouble("currentBalance");
			card.setCurrentBalance(Double.toString(currentBal));
			card.setCardType(result.getString("cardType"));
			card.setCardStatus(result.getString("cardStatus"));
			card.setCardCashLimit(result.getInt("cardCashLimit"));
			Integer lastPaymentDate = result.getInt("lastPaymentDate");
			card.setLastPaymentDate(Integer.toString(lastPaymentDate));
			card.setBlockCode(result.getString("blockCode"));
			card.setThankYouPoints(500);
			card.setMinimumPaymentAmt(10.0);
			card.setMinimumPaymentDueDate("12112017");
			card.setBalOfLastStmt(result.getDouble("endingBalOfLastStmt"));
			if (result.getString("responseCardNumber").length() > 0) {
				cards.add(card);
			}
		}
		return cards;
	}

	/**
	 * Function to get particular card details.
	 * @param cardNumber to retrieve credit card details.
	 * @return CreditCard details.
	 * @throws JSONException if any JSON error.
	 */
	public CreditCard getCard(String cardNumber) throws JSONException {
		CreditCard card = new CreditCard();
		JSONObject result = null;
		String respCardNum = null;
		String crudResponse = null;
		JSONObject jsnobject = null;
		JSONArray jsonArray = null;
		crudResponse = getCRUDConnectorResponse();
		jsnobject = new JSONObject(crudResponse).getJSONObject("GBOF0003OperationResponse")
				.getJSONObject("getRelationshipAcctRes");
		jsonArray = jsnobject.getJSONArray("accountInfoTable");
		for (int i = 0; i < jsonArray.length(); i++) {
			respCardNum = jsonArray.getJSONObject(i).getString("responseCardNumber");
			if (!cardNumber.isEmpty() && cardNumber.equalsIgnoreCase(respCardNum)) {
				result = jsonArray.getJSONObject(i);
				card.setEmbosserName(result.getString("embosserName"));
				card.setCardNumber(result.getString("responseCardNumber"));
				Double currentBal = result.getDouble("currentBalance");
				card.setCurrentBalance(Double.toString(currentBal));
				card.setCardType(result.getString("cardType"));
				card.setCardStatus(result.getString("cardStatus"));
				card.setCardCashLimit(result.getInt("cardCashLimit"));
				Integer lastPaymentDate = result.getInt("lastPaymentDate");
				card.setLastPaymentDate(Integer.toString(lastPaymentDate));
				// card.setThankYouPoints(result.getInt("thankYouPoints"));
				card.setBlockCode(result.getString("blockCode"));
				card.setThankYouPoints(500);
				card.setMinimumPaymentAmt(10.0);
				card.setBalOfLastStmt(result.getDouble("endingBalOfLastStmt"));
				card.setMinimumPaymentDueDate("12112017");
				break;
			}
		}
		return card;
	}

	/**
	 * Function to get crud connector response.
	 * @return String response from CRUDConnector interface.
	 */
	private String getCRUDConnectorResponse() {
		String result = null;
		try {
			String output = null;
			URL url = new URL("https://sit.api.banamex.com/ccp/sit/v1/card/cardinfo/RelatedCardListInq");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("client_id", "ffe4d269-1c59-493b-94f4-fbca960bc0f0");
			conn.setRequestProperty("Authorization", "Basic dGVzdDAwMTpwd2QwMDE=");
			String input = "{\"GBOF0003Operation\":{\"getRelationshipAcctReq\":{\"requestMessageId\":\"0003\","
					+ "\"requestVersionNumber\":15,\"requestTerminalId\":\"00000000MX\","
					+ "\"requestUserId\":\" \",\"requestDateTime\":\"07132015120500\","
					+ "\"requestChannelInd\":\"ECL\",\"requestCustomerOrg\":\"322\","
					+ "\"requestRelationshipNumber\":\"0000000000067739496\"}}}";

			OutputStream os = conn.getOutputStream();
			os.write(input.getBytes());
			os.flush();
			/*
			 * if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
			 * throw new RuntimeException("Failed : HTTP error code : "+
			 * conn.getResponseCode()); }
			 */
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				result = output;
			}
			conn.disconnect();
		}
		catch (MalformedURLException e)	{
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
}
