package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.citibanamex.apifactory.ccp.ws.shared.util.v3_0_0_0.GenericResponse;


/**
 * <p>Java class for LostStolenRs complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LostStolenRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_0_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="newCardNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LostStolenRs", propOrder = {
    "newCardNumber"
})
public class LostStolenRs
    extends GenericResponse
{

    protected String newCardNumber;

    /**
     * Gets the value of the newCardNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewCardNumber() {
        return newCardNumber;
    }

    /**
     * Sets the value of the newCardNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewCardNumber(String value) {
        this.newCardNumber = value;
    }

}
