package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MisGroupdDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MisGroupdDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MisGroupDescription" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}MisGroupDescription"/>
 *         &lt;element name="MisGroupId" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}MisGroupId"/>
 *         &lt;element name="MisTypeDetails" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}MisTypeDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MisGroupdDetails", propOrder = {
    "misGroupDescription",
    "misGroupId",
    "misTypeDetails"
})
public class MisGroupdDetails {

    @XmlElement(name = "MisGroupDescription", required = true)
    protected String misGroupDescription;
    @XmlElement(name = "MisGroupId", required = true)
    protected String misGroupId;
    @XmlElement(name = "MisTypeDetails")
    protected List<MisTypeDetails> misTypeDetails;

    /**
     * Gets the value of the misGroupDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMisGroupDescription() {
        return misGroupDescription;
    }

    /**
     * Sets the value of the misGroupDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMisGroupDescription(String value) {
        this.misGroupDescription = value;
    }

    /**
     * Gets the value of the misGroupId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMisGroupId() {
        return misGroupId;
    }

    /**
     * Sets the value of the misGroupId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMisGroupId(String value) {
        this.misGroupId = value;
    }

    /**
     * Gets the value of the misTypeDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the misTypeDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMisTypeDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MisTypeDetails }
     * 
     * 
     */
    public List<MisTypeDetails> getMisTypeDetails() {
        if (misTypeDetails == null) {
            misTypeDetails = new ArrayList<MisTypeDetails>();
        }
        return this.misTypeDetails;
    }

}
