/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

package com.citibanamex.apifactory.ccp.model;

/**
 * Credit card model class.
 *
 * @author Venkateswarlu Pesala
 *
 */
public class CreditCard {

	private String embosserName;
	private String cardNumber;
	private String currentBalance;
	private String cardType;
	private String cardStatus;
	private String lastPaymentDate;
	private String blockCode;
	private int thankYouPoints;
	private int cardCashLimit;
	private String minimumPaymentDueDate;
	private double balOfLastStmt;
	private double minimumPaymentAmt;
	private String accountNumber;
	private String customerNumber;

	public CreditCard() {
	}
	
	public String getEmbosserName() {
		return this.embosserName;
	}

	public void setEmbosserName(String embosserName) {
		this.embosserName = embosserName;
	}

	public String getCardNumber() {
		return this.cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCurrentBalance() {
		return this.currentBalance;
	}

	public void setCurrentBalance(String currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getCardType() {
		return this.cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getCardStatus() {
		return this.cardStatus;
	}

	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}

	public int getCardCashLimit() {
		return this.cardCashLimit;
	}

	public void setCardCashLimit(int cardCashLimit) {
		this.cardCashLimit = cardCashLimit;
	}

	public String getLastPaymentDate() {
		return this.lastPaymentDate;
	}

	public void setLastPaymentDate(String lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}

	public int getThankYouPoints() {
		return this.thankYouPoints;
	}

	public void setThankYouPoints(int thankYouPoints) {
		this.thankYouPoints = thankYouPoints;
	}

	public String getBlockCode() {
		return this.blockCode;
	}

	public void setBlockCode(String blockCode) {
		this.blockCode = blockCode;
	}

	public String getMinimumPaymentDueDate() {
		return this.minimumPaymentDueDate;
	}

	public void setMinimumPaymentDueDate(String minimumPaymentDueDate) {
		this.minimumPaymentDueDate = minimumPaymentDueDate;
	}

	public double getBalOfLastStmt() {
		return this.balOfLastStmt;
	}

	public void setBalOfLastStmt(double balOfLastStmt) {
		this.balOfLastStmt = balOfLastStmt;
	}

	public double getMinimumPaymentAmt() {
		return this.minimumPaymentAmt;
	}

	public void setMinimumPaymentAmt(double minimumPaymentAmt) {
		this.minimumPaymentAmt = minimumPaymentAmt;
	}

	public String getAccountNumber() {
		return this.accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCustomerNumber() {
		return this.customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

}
