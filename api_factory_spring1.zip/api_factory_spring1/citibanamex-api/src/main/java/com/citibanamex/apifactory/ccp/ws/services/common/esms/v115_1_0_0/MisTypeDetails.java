package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MisTypeDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MisTypeDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MisTypeDescription" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}MisTypeDescription"/>
 *         &lt;element name="MistypeId" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}MistypeId"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MisTypeDetails", propOrder = {
    "misTypeDescription",
    "mistypeId"
})
public class MisTypeDetails {

    @XmlElement(name = "MisTypeDescription", required = true)
    protected String misTypeDescription;
    @XmlElement(name = "MistypeId", required = true)
    protected String mistypeId;

    /**
     * Gets the value of the misTypeDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMisTypeDescription() {
        return misTypeDescription;
    }

    /**
     * Sets the value of the misTypeDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMisTypeDescription(String value) {
        this.misTypeDescription = value;
    }

    /**
     * Gets the value of the mistypeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMistypeId() {
        return mistypeId;
    }

    /**
     * Sets the value of the mistypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMistypeId(String value) {
        this.mistypeId = value;
    }

}
