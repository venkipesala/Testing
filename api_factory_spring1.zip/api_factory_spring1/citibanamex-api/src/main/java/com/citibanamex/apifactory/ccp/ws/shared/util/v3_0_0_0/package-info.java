@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.citi.com/gcgi/shared/util/v3_0_0_0")
package com.citibanamex.apifactory.ccp.ws.shared.util.v3_0_0_0;
