
package com.citibanamex.apifactory.ccp.ws.shared.util.v3_0_0_0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.AutoFulfillmentRs;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.CreateNewMessageRs;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.DeleteMessageRs;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.ListMessageInqRs;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.ListSavedMessageRs;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.LogonRs;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.LostStolenRs;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.MessageDetailInqRs;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.PersonalCreditLimitMaintenanceRs;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.SaveMessageRs;
import com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0.SendMessageRs;
import com.citibanamex.apifactory.ccp.ws.shared.system.header.RsHeader;


/**
 * <p>Java class for GenericResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GenericResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RsHeader" type="{http://www.citi.com/gcgi/shared/system/header}RsHeader" minOccurs="0"/>
 *         &lt;element name="ProviderInfo" type="{http://www.citi.com/gcgi/shared/util/v3_0_0_0}ProviderInfo" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GenericResponse", propOrder = {
    "rsHeader",
    "providerInfo"
})
@XmlSeeAlso({
    DeleteMessageRs.class,
    SendMessageRs.class,
    MessageDetailInqRs.class,
    LogonRs.class,
    SaveMessageRs.class,
    AutoFulfillmentRs.class,
    LostStolenRs.class,
    CreateNewMessageRs.class,
    ListMessageInqRs.class,
    ListSavedMessageRs.class,
    PersonalCreditLimitMaintenanceRs.class
})
public class GenericResponse {

    @XmlElement(name = "RsHeader")
    protected RsHeader rsHeader;
    @XmlElement(name = "ProviderInfo")
    protected List<ProviderInfo> providerInfo;

    /**
     * Gets the value of the rsHeader property.
     * 
     * @return
     *     possible object is
     *     {@link RsHeader }
     *     
     */
    public RsHeader getRsHeader() {
        return rsHeader;
    }

    /**
     * Sets the value of the rsHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link RsHeader }
     *     
     */
    public void setRsHeader(RsHeader value) {
        this.rsHeader = value;
    }

    /**
     * Gets the value of the providerInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the providerInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProviderInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProviderInfo }
     * 
     * 
     */
    public List<ProviderInfo> getProviderInfo() {
        if (providerInfo == null) {
            providerInfo = new ArrayList<ProviderInfo>();
        }
        return this.providerInfo;
    }

}
