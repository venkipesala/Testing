package com.citibanamex.apifactory.ccp.ws.shared.system.header;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ClientDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClientDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Org" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OrgUnit" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ChannelID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TerminalID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClientIPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SrcCountryCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DestCountryCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UserDomicileBranchCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserDomicileResponsibilityCentre" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProcessingBranchCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProcessingResponsibilityCentre" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SessionLanguageCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientDetails", propOrder = {
    "org",
    "orgUnit",
    "channelID",
    "terminalID",
    "clientIPAddress",
    "userID",
    "srcCountryCode",
    "destCountryCode",
    "userDomicileBranchCode",
    "userDomicileResponsibilityCentre",
    "processingBranchCode",
    "processingResponsibilityCentre",
    "userGroup",
    "sessionLanguageCode"
})
public class ClientDetails {

    @XmlElement(name = "Org", required = true)
    protected String org;
    @XmlElement(name = "OrgUnit", required = true)
    protected String orgUnit;
    @XmlElement(name = "ChannelID", required = true)
    protected String channelID;
    @XmlElement(name = "TerminalID", required = true)
    protected String terminalID;
    @XmlElement(name = "ClientIPAddress")
    protected String clientIPAddress;
    @XmlElement(name = "UserID", required = true)
    protected String userID;
    @XmlElement(name = "SrcCountryCode", required = true)
    protected String srcCountryCode;
    @XmlElement(name = "DestCountryCode", required = true)
    protected String destCountryCode;
    @XmlElement(name = "UserDomicileBranchCode")
    protected String userDomicileBranchCode;
    @XmlElement(name = "UserDomicileResponsibilityCentre")
    protected String userDomicileResponsibilityCentre;
    @XmlElement(name = "ProcessingBranchCode")
    protected String processingBranchCode;
    @XmlElement(name = "ProcessingResponsibilityCentre")
    protected String processingResponsibilityCentre;
    @XmlElement(name = "UserGroup")
    protected String userGroup;
    @XmlElement(name = "SessionLanguageCode")
    protected String sessionLanguageCode;

    /**
     * Gets the value of the org property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrg() {
        return org;
    }

    /**
     * Sets the value of the org property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrg(String value) {
        this.org = value;
    }

    /**
     * Gets the value of the orgUnit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgUnit() {
        return orgUnit;
    }

    /**
     * Sets the value of the orgUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgUnit(String value) {
        this.orgUnit = value;
    }

    /**
     * Gets the value of the channelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelID() {
        return channelID;
    }

    /**
     * Sets the value of the channelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelID(String value) {
        this.channelID = value;
    }

    /**
     * Gets the value of the terminalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTerminalID() {
        return terminalID;
    }

    /**
     * Sets the value of the terminalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTerminalID(String value) {
        this.terminalID = value;
    }

    /**
     * Gets the value of the clientIPAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientIPAddress() {
        return clientIPAddress;
    }

    /**
     * Sets the value of the clientIPAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientIPAddress(String value) {
        this.clientIPAddress = value;
    }

    /**
     * Gets the value of the userID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Sets the value of the userID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

    /**
     * Gets the value of the srcCountryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcCountryCode() {
        return srcCountryCode;
    }

    /**
     * Sets the value of the srcCountryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcCountryCode(String value) {
        this.srcCountryCode = value;
    }

    /**
     * Gets the value of the destCountryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestCountryCode() {
        return destCountryCode;
    }

    /**
     * Sets the value of the destCountryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestCountryCode(String value) {
        this.destCountryCode = value;
    }

    /**
     * Gets the value of the userDomicileBranchCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserDomicileBranchCode() {
        return userDomicileBranchCode;
    }

    /**
     * Sets the value of the userDomicileBranchCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserDomicileBranchCode(String value) {
        this.userDomicileBranchCode = value;
    }

    /**
     * Gets the value of the userDomicileResponsibilityCentre property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserDomicileResponsibilityCentre() {
        return userDomicileResponsibilityCentre;
    }

    /**
     * Sets the value of the userDomicileResponsibilityCentre property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserDomicileResponsibilityCentre(String value) {
        this.userDomicileResponsibilityCentre = value;
    }

    /**
     * Gets the value of the processingBranchCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessingBranchCode() {
        return processingBranchCode;
    }

    /**
     * Sets the value of the processingBranchCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessingBranchCode(String value) {
        this.processingBranchCode = value;
    }

    /**
     * Gets the value of the processingResponsibilityCentre property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessingResponsibilityCentre() {
        return processingResponsibilityCentre;
    }

    /**
     * Sets the value of the processingResponsibilityCentre property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessingResponsibilityCentre(String value) {
        this.processingResponsibilityCentre = value;
    }

    /**
     * Gets the value of the userGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserGroup() {
        return userGroup;
    }

    /**
     * Sets the value of the userGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserGroup(String value) {
        this.userGroup = value;
    }

    /**
     * Gets the value of the sessionLanguageCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionLanguageCode() {
        return sessionLanguageCode;
    }

    /**
     * Sets the value of the sessionLanguageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionLanguageCode(String value) {
        this.sessionLanguageCode = value;
    }

}
