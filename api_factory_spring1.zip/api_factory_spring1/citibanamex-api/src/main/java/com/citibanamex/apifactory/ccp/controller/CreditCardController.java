/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

package com.citibanamex.apifactory.ccp.controller;

import java.util.ArrayList;
import java.util.List;

import com.citibanamex.apifactory.ccp.model.CreditCard;
import com.citibanamex.apifactory.ccp.service.CreditCardService;

import org.json.JSONException;
import org.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * This is the controller to unlock the credit card.
 *
 * @author venkateswarlu pesala
 *
 */
@RestController
public class CreditCardController {

	@Autowired
	private CreditCardService creditCardService;

	/**
	 * An API to get list of credit cards.
	 *
	 * @return List<> list of credit cards.
	 */
	@RequestMapping(value = "/cards", method = RequestMethod.GET, produces = "application/json")
	public List<CreditCard> getCards() {
		List<CreditCard> cards = new ArrayList<CreditCard>();
		try {
			cards = this.creditCardService.getCards();
		}
		catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cards;
	}

	/**
	 * An API to get particular credit card details.
	 *
	 * @param cardNumber to retrieve specific credit card.
	 * @return CreditCard details.
	 */
	@RequestMapping(value = "/cards/{cardNumber}", method = RequestMethod.GET, produces = "application/json")
	public CreditCard getCard(@PathVariable String cardNumber) {
		CreditCard result = new CreditCard();
		try {
			result = this.creditCardService.getCard(cardNumber);
		}
		catch (JSONException e) {
			e.printStackTrace();
		}
		return result;
	}

	@RequestMapping(value = "/cards/{card_id}/status", method = RequestMethod.POST, produces = "application/json", consumes = "text/plain")
	public CreditCard updateCardStatus(@PathVariable("card_id") String id, @RequestBody String payload) {
		JSONObject jsonObj = new JSONObject(payload);
		String status = jsonObj.getString("cardStatus");
		return this.creditCardService.updateCardStatus(id, status);
	}

	@RequestMapping(value = "/cards/{card_id}/status", method = RequestMethod.GET, produces = "application/json")
	public CreditCard getCardStatus(@PathVariable("card_id") String id) {
		return this.creditCardService.getCardStatus(id);
	}
}
