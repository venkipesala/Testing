package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LostStolenRq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LostStolenRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="addressEffDateFrm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addressEffDateTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addressLine1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addressLine2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addressLine3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addressLine4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="blockCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cardNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="city" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="deliveryIns" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="embossName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="emergencyReplInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="feeIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="letterCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="newCardExpDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="plasticId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="plasticIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="postCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="purgeDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="reasonCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="regionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="renewalFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="replaceInd24hr" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="replacementMethod" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestFlag" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sendToName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="state" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LostStolenRq", propOrder = {
    "addressEffDateFrm",
    "addressEffDateTo",
    "addressLine1",
    "addressLine2",
    "addressLine3",
    "addressLine4",
    "blockCode",
    "cardNumber",
    "city",
    "country",
    "deliveryIns",
    "embossName",
    "emergencyReplInd",
    "feeIndicator",
    "letterCode",
    "newCardExpDate",
    "plasticId",
    "plasticIndicator",
    "postCode",
    "purgeDate",
    "reasonCode",
    "regionCode",
    "renewalFlag",
    "replaceInd24Hr",
    "replacementMethod",
    "requestFlag",
    "sendToName",
    "state"
})
public class LostStolenRq {

    protected String addressEffDateFrm;
    protected String addressEffDateTo;
    protected String addressLine1;
    protected String addressLine2;
    protected String addressLine3;
    protected String addressLine4;
    @XmlElement(required = true)
    protected String blockCode;
    @XmlElement(required = true)
    protected String cardNumber;
    protected String city;
    protected String country;
    protected String deliveryIns;
    @XmlElement(required = true)
    protected String embossName;
    @XmlElement(required = true)
    protected String emergencyReplInd;
    protected String feeIndicator;
    protected String letterCode;
    @XmlElement(required = true)
    protected String newCardExpDate;
    @XmlElement(required = true)
    protected String plasticId;
    @XmlElement(required = true)
    protected String plasticIndicator;
    protected String postCode;
    protected String purgeDate;
    @XmlElement(required = true)
    protected String reasonCode;
    protected String regionCode;
    protected String renewalFlag;
    @XmlElement(name = "replaceInd24hr", required = true)
    protected String replaceInd24Hr;
    @XmlElement(required = true)
    protected String replacementMethod;
    @XmlElement(required = true)
    protected String requestFlag;
    protected String sendToName;
    @XmlElement(required = true)
    protected String state;

    /**
     * Gets the value of the addressEffDateFrm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressEffDateFrm() {
        return addressEffDateFrm;
    }

    /**
     * Sets the value of the addressEffDateFrm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressEffDateFrm(String value) {
        this.addressEffDateFrm = value;
    }

    /**
     * Gets the value of the addressEffDateTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressEffDateTo() {
        return addressEffDateTo;
    }

    /**
     * Sets the value of the addressEffDateTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressEffDateTo(String value) {
        this.addressEffDateTo = value;
    }

    /**
     * Gets the value of the addressLine1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressLine1() {
        return addressLine1;
    }

    /**
     * Sets the value of the addressLine1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressLine1(String value) {
        this.addressLine1 = value;
    }

    /**
     * Gets the value of the addressLine2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressLine2() {
        return addressLine2;
    }

    /**
     * Sets the value of the addressLine2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressLine2(String value) {
        this.addressLine2 = value;
    }

    /**
     * Gets the value of the addressLine3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressLine3() {
        return addressLine3;
    }

    /**
     * Sets the value of the addressLine3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressLine3(String value) {
        this.addressLine3 = value;
    }

    /**
     * Gets the value of the addressLine4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressLine4() {
        return addressLine4;
    }

    /**
     * Sets the value of the addressLine4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressLine4(String value) {
        this.addressLine4 = value;
    }

    /**
     * Gets the value of the blockCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBlockCode() {
        return blockCode;
    }

    /**
     * Sets the value of the blockCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBlockCode(String value) {
        this.blockCode = value;
    }

    /**
     * Gets the value of the cardNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardNumber() {
        return cardNumber;
    }

    /**
     * Sets the value of the cardNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardNumber(String value) {
        this.cardNumber = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * Gets the value of the deliveryIns property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveryIns() {
        return deliveryIns;
    }

    /**
     * Sets the value of the deliveryIns property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveryIns(String value) {
        this.deliveryIns = value;
    }

    /**
     * Gets the value of the embossName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmbossName() {
        return embossName;
    }

    /**
     * Sets the value of the embossName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbossName(String value) {
        this.embossName = value;
    }

    /**
     * Gets the value of the emergencyReplInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmergencyReplInd() {
        return emergencyReplInd;
    }

    /**
     * Sets the value of the emergencyReplInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmergencyReplInd(String value) {
        this.emergencyReplInd = value;
    }

    /**
     * Gets the value of the feeIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFeeIndicator() {
        return feeIndicator;
    }

    /**
     * Sets the value of the feeIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFeeIndicator(String value) {
        this.feeIndicator = value;
    }

    /**
     * Gets the value of the letterCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLetterCode() {
        return letterCode;
    }

    /**
     * Sets the value of the letterCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLetterCode(String value) {
        this.letterCode = value;
    }

    /**
     * Gets the value of the newCardExpDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewCardExpDate() {
        return newCardExpDate;
    }

    /**
     * Sets the value of the newCardExpDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewCardExpDate(String value) {
        this.newCardExpDate = value;
    }

    /**
     * Gets the value of the plasticId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlasticId() {
        return plasticId;
    }

    /**
     * Sets the value of the plasticId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlasticId(String value) {
        this.plasticId = value;
    }

    /**
     * Gets the value of the plasticIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlasticIndicator() {
        return plasticIndicator;
    }

    /**
     * Sets the value of the plasticIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlasticIndicator(String value) {
        this.plasticIndicator = value;
    }

    /**
     * Gets the value of the postCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostCode() {
        return postCode;
    }

    /**
     * Sets the value of the postCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostCode(String value) {
        this.postCode = value;
    }

    /**
     * Gets the value of the purgeDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPurgeDate() {
        return purgeDate;
    }

    /**
     * Sets the value of the purgeDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPurgeDate(String value) {
        this.purgeDate = value;
    }

    /**
     * Gets the value of the reasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Sets the value of the reasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonCode(String value) {
        this.reasonCode = value;
    }

    /**
     * Gets the value of the regionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegionCode() {
        return regionCode;
    }

    /**
     * Sets the value of the regionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegionCode(String value) {
        this.regionCode = value;
    }

    /**
     * Gets the value of the renewalFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRenewalFlag() {
        return renewalFlag;
    }

    /**
     * Sets the value of the renewalFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRenewalFlag(String value) {
        this.renewalFlag = value;
    }

    /**
     * Gets the value of the replaceInd24Hr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReplaceInd24Hr() {
        return replaceInd24Hr;
    }

    /**
     * Sets the value of the replaceInd24Hr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReplaceInd24Hr(String value) {
        this.replaceInd24Hr = value;
    }

    /**
     * Gets the value of the replacementMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReplacementMethod() {
        return replacementMethod;
    }

    /**
     * Sets the value of the replacementMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReplacementMethod(String value) {
        this.replacementMethod = value;
    }

    /**
     * Gets the value of the requestFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestFlag() {
        return requestFlag;
    }

    /**
     * Sets the value of the requestFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestFlag(String value) {
        this.requestFlag = value;
    }

    /**
     * Gets the value of the sendToName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendToName() {
        return sendToName;
    }

    /**
     * Sets the value of the sendToName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendToName(String value) {
        this.sendToName = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

}
