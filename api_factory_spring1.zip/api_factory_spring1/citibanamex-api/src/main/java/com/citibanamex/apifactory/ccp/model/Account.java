/*
 * Copyright Banco Nacional de Mexico, S.A.
 * Integrante de Grupo Financiero Banamex.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

package com.citibanamex.api.cards.model;

/**
 * Account model class.
 *
 * @author Ammulu Addhanki
 *
 */
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class Account {
	private int accountId;
	private String accountName;
	private String accountType;
	private List<CreditCard> cards;
	
	public Account(){}
	
	public Account(int accountId, String accountName, String accountType, List<CreditCard> cards) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.accountType = accountType;
		this.cards = cards;
	}
	@JsonProperty(required = true)
    @ApiModelProperty(notes = "The id of the Account", required = true)
	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	@JsonProperty(required = true)
    @ApiModelProperty(notes = "The type of the Account", required = true)
	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public List<CreditCard> getCards() {
		return cards;
	}

	public void setCards(List<CreditCard> cards) {
		this.cards = cards;
	}
	
}
