@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.citi.com/gcgi/services/common/esms/v115_1_0_0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;
