package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for RequestList complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RequestList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CardNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}CardNo"/>
 *         &lt;element name="CustomerNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}CustomerNo"/>
 *         &lt;element name="FromtoFlag" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}FromToFlag"/>
 *         &lt;element name="ReferenceNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}ReferenceNo"/>
 *         &lt;element name="RequestDate" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}RequestDate"/>
 *         &lt;element name="RequestTime" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}RequestTime"/>
 *         &lt;element name="Subject" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}Subject"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestList", propOrder = {
    "cardNo",
    "customerNo",
    "fromtoFlag",
    "referenceNo",
    "requestDate",
    "requestTime",
    "subject"
})
public class RequestList {

    @XmlElement(name = "CardNo", required = true)
    protected String cardNo;
    @XmlElement(name = "CustomerNo", required = true)
    protected String customerNo;
    @XmlElement(name = "FromtoFlag", required = true)
    protected String fromtoFlag;
    @XmlElement(name = "ReferenceNo", required = true)
    protected String referenceNo;
    @XmlElement(name = "RequestDate", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar requestDate;
    @XmlElement(name = "RequestTime", required = true)
    @XmlSchemaType(name = "time")
    protected XMLGregorianCalendar requestTime;
    @XmlElement(name = "Subject", required = true)
    protected String subject;

    /**
     * Gets the value of the cardNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardNo() {
        return cardNo;
    }

    /**
     * Sets the value of the cardNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardNo(String value) {
        this.cardNo = value;
    }

    /**
     * Gets the value of the customerNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerNo() {
        return customerNo;
    }

    /**
     * Sets the value of the customerNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerNo(String value) {
        this.customerNo = value;
    }

    /**
     * Gets the value of the fromtoFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromtoFlag() {
        return fromtoFlag;
    }

    /**
     * Sets the value of the fromtoFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromtoFlag(String value) {
        this.fromtoFlag = value;
    }

    /**
     * Gets the value of the referenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceNo() {
        return referenceNo;
    }

    /**
     * Sets the value of the referenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceNo(String value) {
        this.referenceNo = value;
    }

    /**
     * Gets the value of the requestDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the value of the requestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRequestDate(XMLGregorianCalendar value) {
        this.requestDate = value;
    }

    /**
     * Gets the value of the requestTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRequestTime() {
        return requestTime;
    }

    /**
     * Sets the value of the requestTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRequestTime(XMLGregorianCalendar value) {
        this.requestTime = value;
    }

    /**
     * Gets the value of the subject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubject() {
        return subject;
    }

    /**
     * Sets the value of the subject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubject(String value) {
        this.subject = value;
    }

}
