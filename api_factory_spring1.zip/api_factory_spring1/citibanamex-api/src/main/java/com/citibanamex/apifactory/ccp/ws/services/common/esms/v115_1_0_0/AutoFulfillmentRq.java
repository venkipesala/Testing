
package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AutoFulfillmentRq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AutoFulfillmentRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ProcessName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ACCTNUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ACCTTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CAMPAIGNID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CARDNUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CUSTNUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DESCRIPTION" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LASTUPDATEDBY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LVCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PRDCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WAVEID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD7" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD8" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD9" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD10" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD11" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD12" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD13" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD14" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD15" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD16" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD17" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD18" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD19" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD20" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD21" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD22" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD23" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD24" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD25" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD26" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD27" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD28" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD29" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USERFIELD30" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AutoFulfillmentRq", propOrder = {
    "processName",
    "acctnumber",
    "accttype",
    "campaignid",
    "cardnumber",
    "custnumber",
    "description",
    "lastupdatedby",
    "lvcode",
    "prdcode",
    "waveid",
    "userfield1",
    "userfield2",
    "userfield3",
    "userfield4",
    "userfield5",
    "userfield6",
    "userfield7",
    "userfield8",
    "userfield9",
    "userfield10",
    "userfield11",
    "userfield12",
    "userfield13",
    "userfield14",
    "userfield15",
    "userfield16",
    "userfield17",
    "userfield18",
    "userfield19",
    "userfield20",
    "userfield21",
    "userfield22",
    "userfield23",
    "userfield24",
    "userfield25",
    "userfield26",
    "userfield27",
    "userfield28",
    "userfield29",
    "userfield30"
})
public class AutoFulfillmentRq {

    @XmlElement(name = "ProcessName")
    protected String processName;
    @XmlElement(name = "ACCTNUMBER")
    protected String acctnumber;
    @XmlElement(name = "ACCTTYPE")
    protected String accttype;
    @XmlElement(name = "CAMPAIGNID")
    protected String campaignid;
    @XmlElement(name = "CARDNUMBER")
    protected String cardnumber;
    @XmlElement(name = "CUSTNUMBER")
    protected String custnumber;
    @XmlElement(name = "DESCRIPTION")
    protected String description;
    @XmlElement(name = "LASTUPDATEDBY")
    protected String lastupdatedby;
    @XmlElement(name = "LVCODE")
    protected String lvcode;
    @XmlElement(name = "PRDCODE")
    protected String prdcode;
    @XmlElement(name = "WAVEID")
    protected String waveid;
    @XmlElement(name = "USERFIELD1")
    protected String userfield1;
    @XmlElement(name = "USERFIELD2")
    protected String userfield2;
    @XmlElement(name = "USERFIELD3")
    protected String userfield3;
    @XmlElement(name = "USERFIELD4")
    protected String userfield4;
    @XmlElement(name = "USERFIELD5")
    protected String userfield5;
    @XmlElement(name = "USERFIELD6")
    protected String userfield6;
    @XmlElement(name = "USERFIELD7")
    protected String userfield7;
    @XmlElement(name = "USERFIELD8")
    protected String userfield8;
    @XmlElement(name = "USERFIELD9")
    protected String userfield9;
    @XmlElement(name = "USERFIELD10")
    protected String userfield10;
    @XmlElement(name = "USERFIELD11")
    protected String userfield11;
    @XmlElement(name = "USERFIELD12")
    protected String userfield12;
    @XmlElement(name = "USERFIELD13")
    protected String userfield13;
    @XmlElement(name = "USERFIELD14")
    protected String userfield14;
    @XmlElement(name = "USERFIELD15")
    protected String userfield15;
    @XmlElement(name = "USERFIELD16")
    protected String userfield16;
    @XmlElement(name = "USERFIELD17")
    protected String userfield17;
    @XmlElement(name = "USERFIELD18")
    protected String userfield18;
    @XmlElement(name = "USERFIELD19")
    protected String userfield19;
    @XmlElement(name = "USERFIELD20")
    protected String userfield20;
    @XmlElement(name = "USERFIELD21")
    protected String userfield21;
    @XmlElement(name = "USERFIELD22")
    protected String userfield22;
    @XmlElement(name = "USERFIELD23")
    protected String userfield23;
    @XmlElement(name = "USERFIELD24")
    protected String userfield24;
    @XmlElement(name = "USERFIELD25")
    protected String userfield25;
    @XmlElement(name = "USERFIELD26")
    protected String userfield26;
    @XmlElement(name = "USERFIELD27")
    protected String userfield27;
    @XmlElement(name = "USERFIELD28")
    protected String userfield28;
    @XmlElement(name = "USERFIELD29")
    protected String userfield29;
    @XmlElement(name = "USERFIELD30")
    protected String userfield30;

    /**
     * Gets the value of the processName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessName() {
        return processName;
    }

    /**
     * Sets the value of the processName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessName(String value) {
        this.processName = value;
    }

    /**
     * Gets the value of the acctnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCTNUMBER() {
        return acctnumber;
    }

    /**
     * Sets the value of the acctnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCTNUMBER(String value) {
        this.acctnumber = value;
    }

    /**
     * Gets the value of the accttype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCTTYPE() {
        return accttype;
    }

    /**
     * Sets the value of the accttype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCTTYPE(String value) {
        this.accttype = value;
    }

    /**
     * Gets the value of the campaignid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCAMPAIGNID() {
        return campaignid;
    }

    /**
     * Sets the value of the campaignid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCAMPAIGNID(String value) {
        this.campaignid = value;
    }

    /**
     * Gets the value of the cardnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCARDNUMBER() {
        return cardnumber;
    }

    /**
     * Sets the value of the cardnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCARDNUMBER(String value) {
        this.cardnumber = value;
    }

    /**
     * Gets the value of the custnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTNUMBER() {
        return custnumber;
    }

    /**
     * Sets the value of the custnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTNUMBER(String value) {
        this.custnumber = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDESCRIPTION() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDESCRIPTION(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the lastupdatedby property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTUPDATEDBY() {
        return lastupdatedby;
    }

    /**
     * Sets the value of the lastupdatedby property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTUPDATEDBY(String value) {
        this.lastupdatedby = value;
    }

    /**
     * Gets the value of the lvcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLVCODE() {
        return lvcode;
    }

    /**
     * Sets the value of the lvcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLVCODE(String value) {
        this.lvcode = value;
    }

    /**
     * Gets the value of the prdcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRDCODE() {
        return prdcode;
    }

    /**
     * Sets the value of the prdcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRDCODE(String value) {
        this.prdcode = value;
    }

    /**
     * Gets the value of the waveid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWAVEID() {
        return waveid;
    }

    /**
     * Sets the value of the waveid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWAVEID(String value) {
        this.waveid = value;
    }

    /**
     * Gets the value of the userfield1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD1() {
        return userfield1;
    }

    /**
     * Sets the value of the userfield1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD1(String value) {
        this.userfield1 = value;
    }

    /**
     * Gets the value of the userfield2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD2() {
        return userfield2;
    }

    /**
     * Sets the value of the userfield2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD2(String value) {
        this.userfield2 = value;
    }

    /**
     * Gets the value of the userfield3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD3() {
        return userfield3;
    }

    /**
     * Sets the value of the userfield3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD3(String value) {
        this.userfield3 = value;
    }

    /**
     * Gets the value of the userfield4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD4() {
        return userfield4;
    }

    /**
     * Sets the value of the userfield4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD4(String value) {
        this.userfield4 = value;
    }

    /**
     * Gets the value of the userfield5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD5() {
        return userfield5;
    }

    /**
     * Sets the value of the userfield5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD5(String value) {
        this.userfield5 = value;
    }

    /**
     * Gets the value of the userfield6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD6() {
        return userfield6;
    }

    /**
     * Sets the value of the userfield6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD6(String value) {
        this.userfield6 = value;
    }

    /**
     * Gets the value of the userfield7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD7() {
        return userfield7;
    }

    /**
     * Sets the value of the userfield7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD7(String value) {
        this.userfield7 = value;
    }

    /**
     * Gets the value of the userfield8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD8() {
        return userfield8;
    }

    /**
     * Sets the value of the userfield8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD8(String value) {
        this.userfield8 = value;
    }

    /**
     * Gets the value of the userfield9 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD9() {
        return userfield9;
    }

    /**
     * Sets the value of the userfield9 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD9(String value) {
        this.userfield9 = value;
    }

    /**
     * Gets the value of the userfield10 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD10() {
        return userfield10;
    }

    /**
     * Sets the value of the userfield10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD10(String value) {
        this.userfield10 = value;
    }

    /**
     * Gets the value of the userfield11 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD11() {
        return userfield11;
    }

    /**
     * Sets the value of the userfield11 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD11(String value) {
        this.userfield11 = value;
    }

    /**
     * Gets the value of the userfield12 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD12() {
        return userfield12;
    }

    /**
     * Sets the value of the userfield12 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD12(String value) {
        this.userfield12 = value;
    }

    /**
     * Gets the value of the userfield13 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD13() {
        return userfield13;
    }

    /**
     * Sets the value of the userfield13 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD13(String value) {
        this.userfield13 = value;
    }

    /**
     * Gets the value of the userfield14 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD14() {
        return userfield14;
    }

    /**
     * Sets the value of the userfield14 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD14(String value) {
        this.userfield14 = value;
    }

    /**
     * Gets the value of the userfield15 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD15() {
        return userfield15;
    }

    /**
     * Sets the value of the userfield15 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD15(String value) {
        this.userfield15 = value;
    }

    /**
     * Gets the value of the userfield16 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD16() {
        return userfield16;
    }

    /**
     * Sets the value of the userfield16 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD16(String value) {
        this.userfield16 = value;
    }

    /**
     * Gets the value of the userfield17 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD17() {
        return userfield17;
    }

    /**
     * Sets the value of the userfield17 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD17(String value) {
        this.userfield17 = value;
    }

    /**
     * Gets the value of the userfield18 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD18() {
        return userfield18;
    }

    /**
     * Sets the value of the userfield18 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD18(String value) {
        this.userfield18 = value;
    }

    /**
     * Gets the value of the userfield19 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD19() {
        return userfield19;
    }

    /**
     * Sets the value of the userfield19 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD19(String value) {
        this.userfield19 = value;
    }

    /**
     * Gets the value of the userfield20 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD20() {
        return userfield20;
    }

    /**
     * Sets the value of the userfield20 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD20(String value) {
        this.userfield20 = value;
    }

    /**
     * Gets the value of the userfield21 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD21() {
        return userfield21;
    }

    /**
     * Sets the value of the userfield21 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD21(String value) {
        this.userfield21 = value;
    }

    /**
     * Gets the value of the userfield22 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD22() {
        return userfield22;
    }

    /**
     * Sets the value of the userfield22 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD22(String value) {
        this.userfield22 = value;
    }

    /**
     * Gets the value of the userfield23 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD23() {
        return userfield23;
    }

    /**
     * Sets the value of the userfield23 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD23(String value) {
        this.userfield23 = value;
    }

    /**
     * Gets the value of the userfield24 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD24() {
        return userfield24;
    }

    /**
     * Sets the value of the userfield24 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD24(String value) {
        this.userfield24 = value;
    }

    /**
     * Gets the value of the userfield25 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD25() {
        return userfield25;
    }

    /**
     * Sets the value of the userfield25 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD25(String value) {
        this.userfield25 = value;
    }

    /**
     * Gets the value of the userfield26 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD26() {
        return userfield26;
    }

    /**
     * Sets the value of the userfield26 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD26(String value) {
        this.userfield26 = value;
    }

    /**
     * Gets the value of the userfield27 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD27() {
        return userfield27;
    }

    /**
     * Sets the value of the userfield27 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD27(String value) {
        this.userfield27 = value;
    }

    /**
     * Gets the value of the userfield28 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD28() {
        return userfield28;
    }

    /**
     * Sets the value of the userfield28 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD28(String value) {
        this.userfield28 = value;
    }

    /**
     * Gets the value of the userfield29 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD29() {
        return userfield29;
    }

    /**
     * Sets the value of the userfield29 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD29(String value) {
        this.userfield29 = value;
    }

    /**
     * Gets the value of the userfield30 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERFIELD30() {
        return userfield30;
    }

    /**
     * Sets the value of the userfield30 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERFIELD30(String value) {
        this.userfield30 = value;
    }

}
