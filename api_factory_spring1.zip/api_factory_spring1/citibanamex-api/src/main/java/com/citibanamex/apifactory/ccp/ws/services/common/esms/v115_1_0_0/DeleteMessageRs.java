package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.citibanamex.apifactory.ccp.ws.shared.util.v3_0_0_0.GenericResponse;


/**
 * <p>Java class for DeleteMessageRs complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeleteMessageRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_0_0_0}GenericResponse">
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeleteMessageRs")
public class DeleteMessageRs
    extends GenericResponse
{


}
