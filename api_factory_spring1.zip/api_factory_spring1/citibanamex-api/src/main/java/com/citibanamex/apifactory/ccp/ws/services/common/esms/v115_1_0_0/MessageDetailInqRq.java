package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MessageDetailInqRq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MessageDetailInqRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CountryCode" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}CountryCode"/>
 *         &lt;element name="MessageFlag" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ReferenceNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}ReferenceNo"/>
 *         &lt;element name="UserID" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}UserID"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageDetailInqRq", propOrder = {
    "countryCode",
    "messageFlag",
    "referenceNo",
    "userID"
})
public class MessageDetailInqRq {

    @XmlElement(name = "CountryCode", required = true)
    protected String countryCode;
    @XmlElement(name = "MessageFlag", required = true)
    protected String messageFlag;
    @XmlElement(name = "ReferenceNo", required = true)
    protected String referenceNo;
    @XmlElement(name = "UserID", required = true)
    protected String userID;

    /**
     * Gets the value of the countryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String value) {
        this.countryCode = value;
    }

    /**
     * Gets the value of the messageFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageFlag() {
        return messageFlag;
    }

    /**
     * Sets the value of the messageFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageFlag(String value) {
        this.messageFlag = value;
    }

    /**
     * Gets the value of the referenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceNo() {
        return referenceNo;
    }

    /**
     * Sets the value of the referenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceNo(String value) {
        this.referenceNo = value;
    }

    /**
     * Gets the value of the userID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Sets the value of the userID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

}
