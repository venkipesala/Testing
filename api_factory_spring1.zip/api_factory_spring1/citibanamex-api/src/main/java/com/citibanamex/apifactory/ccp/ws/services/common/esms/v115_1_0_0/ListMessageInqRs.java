package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.citibanamex.apifactory.ccp.ws.shared.util.v3_0_0_0.GenericResponse;


/**
 * <p>Java class for ListMessageInqRs complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListMessageInqRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_0_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="MisGroupDetails" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}MisGroupdDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListMessageInqRs", propOrder = {
    "misGroupDetails"
})
public class ListMessageInqRs
    extends GenericResponse
{

    @XmlElement(name = "MisGroupDetails")
    protected List<MisGroupdDetails> misGroupDetails;

    /**
     * Gets the value of the misGroupDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the misGroupDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMisGroupDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MisGroupdDetails }
     * 
     * 
     */
    public List<MisGroupdDetails> getMisGroupDetails() {
        if (misGroupDetails == null) {
            misGroupDetails = new ArrayList<MisGroupdDetails>();
        }
        return this.misGroupDetails;
    }

}
