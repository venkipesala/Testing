package com.citibanamex.apifactory.ccp.ws.services.common.esms.v115_1_0_0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SendMessageRq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SendMessageRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AccountNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}AccountNo"/>
 *         &lt;element name="CardNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}CardNo"/>
 *         &lt;element name="CountryCode" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}CountryCode"/>
 *         &lt;element name="CustomerNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}CustomerNo"/>
 *         &lt;element name="Description" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}Description"/>
 *         &lt;element name="MisGroup" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}MisGroup"/>
 *         &lt;element name="MisType" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}MisType"/>
 *         &lt;element name="ProblemType" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}ProblemType"/>
 *         &lt;element name="RequestDetails" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}RequestDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="SaveFlag" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}SaveFlag"/>
 *         &lt;element name="Subject" type="{http://www.citi.com/gcgi/services/common/esms/v115_1_0_0}Subject"/>
 *         &lt;element name="UserID" type="{http://www.citi.com/gcgi/shared/datatypes/v3_0_0_0}UserID"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SendMessageRq", propOrder = {
    "accountNo",
    "cardNo",
    "countryCode",
    "customerNo",
    "description",
    "misGroup",
    "misType",
    "problemType",
    "requestDetails",
    "saveFlag",
    "subject",
    "userID"
})
public class SendMessageRq {

    @XmlElement(name = "AccountNo", required = true)
    protected String accountNo;
    @XmlElement(name = "CardNo", required = true)
    protected String cardNo;
    @XmlElement(name = "CountryCode", required = true)
    protected String countryCode;
    @XmlElement(name = "CustomerNo", required = true)
    protected String customerNo;
    @XmlElement(name = "Description", required = true)
    protected String description;
    @XmlElement(name = "MisGroup", required = true)
    protected String misGroup;
    @XmlElement(name = "MisType", required = true)
    protected String misType;
    @XmlElement(name = "ProblemType", required = true)
    protected String problemType;
    @XmlElement(name = "RequestDetails")
    protected List<RequestDetails> requestDetails;
    @XmlElement(name = "SaveFlag", required = true)
    protected String saveFlag;
    @XmlElement(name = "Subject", required = true)
    protected String subject;
    @XmlElement(name = "UserID", required = true)
    protected String userID;

    /**
     * Gets the value of the accountNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNo() {
        return accountNo;
    }

    /**
     * Sets the value of the accountNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNo(String value) {
        this.accountNo = value;
    }

    /**
     * Gets the value of the cardNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardNo() {
        return cardNo;
    }

    /**
     * Sets the value of the cardNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardNo(String value) {
        this.cardNo = value;
    }

    /**
     * Gets the value of the countryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String value) {
        this.countryCode = value;
    }

    /**
     * Gets the value of the customerNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerNo() {
        return customerNo;
    }

    /**
     * Sets the value of the customerNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerNo(String value) {
        this.customerNo = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the misGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMisGroup() {
        return misGroup;
    }

    /**
     * Sets the value of the misGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMisGroup(String value) {
        this.misGroup = value;
    }

    /**
     * Gets the value of the misType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMisType() {
        return misType;
    }

    /**
     * Sets the value of the misType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMisType(String value) {
        this.misType = value;
    }

    /**
     * Gets the value of the problemType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProblemType() {
        return problemType;
    }

    /**
     * Sets the value of the problemType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProblemType(String value) {
        this.problemType = value;
    }

    /**
     * Gets the value of the requestDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the requestDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequestDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RequestDetails }
     * 
     * 
     */
    public List<RequestDetails> getRequestDetails() {
        if (requestDetails == null) {
            requestDetails = new ArrayList<RequestDetails>();
        }
        return this.requestDetails;
    }

    /**
     * Gets the value of the saveFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSaveFlag() {
        return saveFlag;
    }

    /**
     * Sets the value of the saveFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSaveFlag(String value) {
        this.saveFlag = value;
    }

    /**
     * Gets the value of the subject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubject() {
        return subject;
    }

    /**
     * Sets the value of the subject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubject(String value) {
        this.subject = value;
    }

    /**
     * Gets the value of the userID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Sets the value of the userID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

}
