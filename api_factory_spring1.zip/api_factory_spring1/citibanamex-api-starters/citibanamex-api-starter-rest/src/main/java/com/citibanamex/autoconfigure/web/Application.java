package com.citibanamex.autoconfigure.web;

import java.net.URISyntaxException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.web.ErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.boot.autoconfigure.web.WebMvcAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.citibanamex.web.annotation.ApiVersion;
import com.citibanamex.web.annotation.ApiVersionRequestMappingHandlerMapping;

@AutoConfigureAfter({ WebMvcAutoConfiguration.class })
@SpringBootConfiguration
public class Application {
	
	/**
	 * This implementation makes json-only the responses trying to access a
	 * resource it doesn't exist.
	 */
	@RestController
	@RequestMapping("/error")
	static class SimpleErrorController implements ErrorController {

		private final ErrorAttributes errorAttributes;

		@Autowired
		public SimpleErrorController(ErrorAttributes errorAttributes) {
			this.errorAttributes = errorAttributes;
		}

		@Override
		public String getErrorPath() {
			return "/error";
		}

		@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
		public Map<String, Object> error(HttpServletRequest request) {
			RequestAttributes requestAttributes = new ServletRequestAttributes(request);
			return errorAttributes.getErrorAttributes(requestAttributes, false); // false: does not include stack trace
		}

	}

	// NOTE: This section was created for showing the implementation of version API control. 
	/**
	 * 
	 * @author Martin Barcenas
	 *
	 */
	@Configuration
	static class WebMvcConfig extends WebMvcConfigurationSupport {
		@Override
		public RequestMappingHandlerMapping requestMappingHandlerMapping() {
			return new ApiVersionRequestMappingHandlerMapping("api/v");
		}
	}

	@RestController
	static class HelloController {

		@ApiVersion(1) // this adds /api/v1 preffix to the service
		@RequestMapping(method = RequestMethod.GET, value = "/hello/{word}", produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Response> hello(@PathVariable(name = "word") String word) throws URISyntaxException {
			return new ResponseEntity<>(new Response(String.format("Hello %s!", word)), HttpStatus.OK);
		}
	}

	@SuppressWarnings("unused")
	private static final class Response {

		private String message;

		public Response(String message) {
			super();
			this.message = message;
		}

		public final String getMessage() {
			return message;
		}

		public final void setMessage(String message) {
			this.message = message;
		}
	}

}
