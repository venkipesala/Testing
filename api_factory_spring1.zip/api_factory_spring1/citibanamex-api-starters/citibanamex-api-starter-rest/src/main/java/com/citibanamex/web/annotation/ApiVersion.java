package com.citibanamex.web.annotation;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;


/**
 * Annotation used for adding version using URI approach, i.e. api/v1/... 
 * @author Martin Barcenas
 *
 */
@Retention(RUNTIME)
@Target({ TYPE, METHOD })
public @interface ApiVersion {
	
	int[] value();

}
