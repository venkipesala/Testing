package com.citibanamex.api.sample.stubrunner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.contract.stubrunner.server.EnableStubRunnerServer;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.cloud.stream.test.binder.TestSupportBinderAutoConfiguration;

/**
 * @author Martin Barcenas
 *
 */
@SpringBootApplication(exclude = TestSupportBinderAutoConfiguration.class)
@EnableStubRunnerServer
public class ApiStubRunnerBootApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(ApiStubRunnerBootApplication.class, args);
	}

	@AutoConfigureStubRunner
	static class Config {}

}
