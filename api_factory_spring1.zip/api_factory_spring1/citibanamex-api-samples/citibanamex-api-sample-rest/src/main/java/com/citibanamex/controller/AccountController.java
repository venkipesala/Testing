package com.citibanamex.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citibanamex.hateoas.Response;
import com.citibanamex.model.Account;
import com.citibanamex.service.AccountService;
import com.citibanamex.web.annotation.ApiVersion;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@ApiVersion(1)
@RestController
@RequestMapping("/accounts")
public class AccountController {
	
	@Autowired
	private AccountService accountService;

	@GetMapping
	public ResponseEntity<?> findAll() throws JsonParseException, JsonMappingException, IOException {
		List<Account> data = accountService.getAll();
		Response<List<Account>> response = new Response<>(data);
		response.add(linkTo(methodOn(AccountController.class).findAll()).withSelfRel());
		
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping(value = "/{uuid}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findOne(@PathVariable("uuid") String uuid) throws IOException {
		Account data = accountService.get(uuid);
		Response<Account> response = new Response<Account>(data);
		response.add(linkTo(methodOn(AccountController.class).findOne(uuid)).withSelfRel());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> save(@RequestBody Account account) throws InterruptedException {
		accountService.save(account);
		Response<Account> response = new Response<Account>(account);
		response.add(linkTo(methodOn(AccountController.class).save(account)).withSelfRel());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
