package com.citibanamex.service;

import java.io.IOException;
import java.util.List;

import com.citibanamex.model.Account;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

/**
 * @author Martin Barcenas
 *
 */
public interface AccountService {

	/**
	 * Lists all accounts.
	 * 
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 * @return list of accounts
	 */
	List<Account> getAll() throws JsonParseException, JsonMappingException, IOException;

	/**
	 * Gets one account by uuid.
	 * 
	 * @throws IOException
	 * @param uuid
	 *            the account uuid
	 * @return the found account
	 */
	Account get(String uuid) throws IOException;

	/**
	 * Saves an account.
	 * 
	 * @param account
	 *            the account to save
	 */
	void save(Account account) throws InterruptedException;

}
