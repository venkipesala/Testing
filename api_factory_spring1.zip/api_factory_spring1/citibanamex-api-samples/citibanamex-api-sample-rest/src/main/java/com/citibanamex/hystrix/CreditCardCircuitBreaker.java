package com.citibanamex.hystrix;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/**
 * Wraps diverse types of validation for an Account.
 * 
 * @author Martin Barcenas
 *
 */
@Service
public class CreditCardCircuitBreaker {

	private static final Logger LOG = LoggerFactory.getLogger(CreditCardCircuitBreaker.class);
	
	/**
	 * Validates one credit card number at a time
	 * 
	 * @param number
	 *            the credit card number
	 * @return <code>true</code> if credit card number is valid,
	 *         <code>false</code> otherwise
	 * @throws InterruptedException
	 */
	@HystrixCommand(fallbackMethod = "validateCreditCardNumberFallback")
	public synchronized boolean validateCreditCardNumber(String number) throws InterruptedException {
		LOG.debug("trying to validate credit card number by service 1");
		// TODO: to simulate a service invocation in order to see fallback functionality 
		return true;
	}

	/**
	 * Fallback method for {@link CircuitBreakerTests#validateCreditCardNumber}.
	 * 
	 * @param number
	 *            the credit card number
	 * @return <code>true</code> if credit card number is valid,
	 *         <code>false</code> otherwise
	 */
	@SuppressWarnings("unused")
	private synchronized boolean validateCreditCardNumberFallback(String number) {
		LOG.debug("trying to validate credit card number by service 2");
		// TODO: to get info or data from Cache or similar
		return true;
	}

}
