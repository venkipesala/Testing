package com.citibanamex.service;

import static com.jayway.jsonpath.Criteria.where;
import static com.jayway.jsonpath.Filter.filter;
import static com.jayway.jsonpath.JsonPath.parse;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.citibanamex.hystrix.CreditCardCircuitBreaker;
import com.citibanamex.model.Account;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.jayway.jsonpath.Filter;


/**
 * This service works as an example and will be replace for a real service one later.
 * 
 * @author Martin Barcenas
 *
 */
@Service
public class AccountServiceImpl implements AccountService {
	
	private ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
	private CreditCardCircuitBreaker creditCardCircuitBreaker;

	/**
	 * @see com.citibanamex.service.AccountService#getAll()
	 */
	@Override
	public List<Account> getAll() throws JsonParseException, JsonMappingException, IOException {
		return mapper.readValue(getDataResource().getFile(), new TypeReference<List<Account>>(){});
	}

	/**
	 * @see com.citibanamex.service.AccountService#get(java.lang.String)
	 */
	@Override
	public Account get(String uuid) throws IOException {
		mapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
		Filter uuidFilter = filter(where("account_id").is(uuid));
		List<Map<String, Object>> accounts = parse(getDataResource().getFile()).read("$.[?]", uuidFilter);
		if (CollectionUtils.isEmpty(accounts)) {
			return null;
		}
		Account account = new Account();
		account.setAccountId(accounts.get(0).get("account_id").toString());
		account.setName(accounts.get(0).get("name").toString());
		account.setLastName(accounts.get(0).get("last_name").toString());
		account.setEmail(accounts.get(0).get("email").toString());
		account.setAddress(accounts.get(0).get("address").toString());
		account.setCity(accounts.get(0).get("city").toString());
		account.setCreditCard(accounts.get(0).get("credit_card").toString());
		account.setZipCode(accounts.get(0).get("zip_code").toString());
		
		return account;
	}
	
	/**
	 * @throws InterruptedException 
	 * @see com.citibanamex.service.AccountService#save(com.citibanamex.model.Account)
	 */
	@Override
	public void save(Account account) throws InterruptedException {
		// tries to simulate a credit card number validation
		if (!creditCardCircuitBreaker.validateCreditCardNumber(account.getCreditCard())) { // this command executes a Circuit Breaker 
			throw new RuntimeException("Invalid credit card number");
		}
		account.setAccountId(UUID.randomUUID().toString());
	}

	private Resource getDataResource() {
		return new ClassPathResource("dataJan-18-2017.json");
	}

}
