package smoke;

import static org.assertj.core.api.BDDAssertions.then;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Martin Barcenas
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = SmokeTests.class,
		webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class SmokeTests {
	
	@Value("${application.url}") 
	private String applicationUrl;

	private TestRestTemplate testRestTemplate;

	@Before
	public void setup(){
		testRestTemplate = new TestRestTemplate();
	}
	
	@Test
	public void pingTest() {
		ResponseEntity<String> entity = 
				this.testRestTemplate.getForEntity(String.format("http://%s/health", applicationUrl), String.class);

		then(entity.getStatusCode().is2xxSuccessful()).isTrue();
	}

}
