package com.citibanamex.hystrix.test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;

import com.citibanamex.ApiExampleApplicationTests;
import com.citibanamex.hystrix.CreditCardCircuitBreaker;
import com.netflix.config.ConfigurationManager;

/**
 * 
 * @author Martin Barcenas
 *
 */
@ActiveProfiles("default")
public class CircuitBreakerTests extends ApiExampleApplicationTests {

	@Autowired
	private CreditCardCircuitBreaker creditCardCircuitBreaker;

	@Test
	public void testCreditCardCommand() throws InterruptedException {
		assertThat(creditCardCircuitBreaker.validateCreditCardNumber(""), equalTo(Boolean.TRUE));
	}

	@Test
	public void testCreditCardCommandFallback() throws InterruptedException {
		ConfigurationManager.getConfigInstance().setProperty("hystrix.command.default.circuitBreaker.forceOpen",
				"true");
		assertThat(creditCardCircuitBreaker.validateCreditCardNumber(""), equalTo(Boolean.TRUE));
	}
	
	@After
	public void teardown() {
		ConfigurationManager.getConfigInstance().setProperty("hystrix.command.default.circuitBreaker.forceOpen",
				"false");
	}

}
