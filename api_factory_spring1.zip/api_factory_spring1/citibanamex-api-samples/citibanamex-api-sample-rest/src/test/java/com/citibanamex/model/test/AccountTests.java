package com.citibanamex.model.test;

import static com.jayway.jsonpath.JsonPath.*;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.io.IOException;
import java.text.ParseException;

import org.apache.commons.lang3.time.DateUtils;
import org.junit.Before;
import org.junit.Test;

import com.citibanamex.model.Account;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;


/**
 * @author Martin Barcenas
 *
 */
public class AccountTests {

	private Account account;

	@Before
	public void instantiate() throws ParseException {
		account = new Account();
		account.setAccountId("7DDA1631-4E89-8678-F96A-052069C62C48");
		account.setAddress("5931 Egestas Street");
		account.setBirthday(DateUtils.parseDate("13/02/1952", "dd/MM/yyyy"));
		account.setCity("Musselburgh");
		account.setCreditCard("5158-0244-4984-8067");
		account.setEmail("neque.tellus.imperdiet@sagittissemper.ca");
		account.setLastName("Harrington");
		account.setName("Beck");
		account.setZipCode("39861");
	}

	@Test
	public void serialize() throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(account);
		
		assertThat(read(json, "$.account_id"), equalTo("7DDA1631-4E89-8678-F96A-052069C62C48"));
		assertThat(read(json, "$.address"), equalTo("5931 Egestas Street"));
		assertThat(read(json, "$.credit_card"), equalTo("5158-0244-4984-8067"));
		assertThat(read(json, "$.birthday"), equalTo("13/02/1952"));
		
	}

	@Test
	public void deserialize() throws JsonParseException, JsonMappingException, IOException, ParseException {
		String json = "{\"account_id\":\"7DDA1631-4E89-8678-F96A-052069C62C48\",\"name\":\"Beck\",\"last_name\":\"Harrington\",\"email\":\"neque.tellus.imperdiet@sagittissemper.ca\",\"birthday\":\"13/02/1952\",\"address\":\"5931 Egestas Street\",\"city\":\"Musselburgh\",\"zip_code\":\"39861\",\"credit_card\":\"5158-0244-4984-8067\"}";
		ObjectMapper mapper = new ObjectMapper();
		mapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
		
		Account account = mapper.readValue(json, Account.class);
		
		assertThat(account.getAccountId(), equalTo("7DDA1631-4E89-8678-F96A-052069C62C48"));
		assertThat(account.getAddress(), equalTo("5931 Egestas Street"));
		assertThat(account.getCreditCard(), equalTo("5158-0244-4984-8067"));
	}

}
