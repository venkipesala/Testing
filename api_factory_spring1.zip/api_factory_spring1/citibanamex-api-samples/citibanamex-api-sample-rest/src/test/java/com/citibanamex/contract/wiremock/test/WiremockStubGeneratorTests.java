package com.citibanamex.contract.wiremock.test;

import static org.springframework.cloud.contract.wiremock.restdocs.WireMockRestDocs.verify;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.AutoConfigureJsonTesters;
import org.springframework.boot.test.autoconfigure.restdocs.AutoConfigureRestDocs;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.citibanamex.ApiExampleApplication;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Martin Barcenas
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = ApiExampleApplication.class)
@AutoConfigureRestDocs(outputDir = "target/snippets")
@AutoConfigureMockMvc
@AutoConfigureJsonTesters
@DirtiesContext
public class WiremockStubGeneratorTests {
	
	@Autowired
	private MockMvc mockMvc;
	
	//private JacksonTester<FraudCheck> fraudCheckJson;
	
	@Before
	public void setup() {
		ObjectMapper objectMappper = new ObjectMapper();
		// Possibly configure the mapper
		JacksonTester.initFields(this, objectMappper);
	}
	
	@Test
	public void contextLoads() throws Exception {
		String uuid = "237E9C6D-B390-5CE2-AC9D-3EE18C35EAAB";
		
		mockMvc.perform(get("/api/v1/accounts/{uuid}", uuid))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.data.name").value("Kyle"))
				.andExpect(jsonPath("$.data.last_name").value("Holmes"))
				.andDo(document("accountByUUID"));
				/*.andDo(verify().jsonPath("$.data.account_id")
						.stub("accountByUUID"));*/
	}

	/* ------------------------------------------------------------
	 * OTHER WAYS HOW THIS WORKS
	 * ------------------------------------------------------------
	 */
	
	@Test
	@Ignore
	public void contextLoads2() throws Exception {
		mockMvc.perform(post("/resource")
                .content("{\"id\":\"123456\",\"message\":\"Hello World\"}"))
				.andExpect(status().isOk())
				.andDo(verify().jsonPath("$.id")
                        .stub("resource"));
	}

	@Test
	@Ignore
	public void statusIsMaintained() throws Exception {
		this.mockMvc.perform(get("/status"))
				.andExpect(content().string("Hello World"))
				.andExpect(status().is(HttpStatus.ACCEPTED.value()))
				.andDo(document("status"));
	}
	
	/*@Test
	@Ignore
	public void shouldMarkClientAsFraud() throws Exception {
		FraudCheck fraudCheck = new FraudCheck();
		fraudCheck.setClientId("1234567890");
		fraudCheck.setLoanAmount(BigDecimal.valueOf(99999.0));
		mockMvc.perform(put("/fraudcheck")
				.contentType(MediaType.valueOf("application/vnd.fraud.v1+json"))
				.content(fraudCheckJson.write(fraudCheck).getJson()))
				.andExpect(jsonPath("$.fraudCheckStatus").value("FRAUD"))
				.andExpect(jsonPath("$.rejectionReason").value("Amount too high"))
				.andDo(verify().jsonPath("$.clientId")
						.jsonPath("$[?(@.loanAmount > 1000)]")
						.contentType(MediaType.valueOf("application/vnd.fraud.v1+json"))
						.stub("markClientAsFraud"));
	}

	@Test
	@Ignore
	public void shouldMarkClientAsNotFraud() throws Exception {
		FraudCheck fraudCheck = new FraudCheck();
		fraudCheck.setClientId("1234567890");
		fraudCheck.setLoanAmount(BigDecimal.valueOf(123.123));
		mockMvc.perform(put("/fraudcheck")
				.contentType(MediaType.valueOf("application/vnd.fraud.v1+json"))
				.content(fraudCheckJson.write(fraudCheck).getJson()))
				.andExpect(jsonPath("$.fraudCheckStatus").value("OK"))
				.andExpect(jsonPath("$.rejectionReason").doesNotExist())
				.andDo(verify().jsonPath("$.clientId")
						.jsonPath("$[?(@.loanAmount <= 1000)]")
						.contentType(MediaType.valueOf("application/vnd.fraud.v1+json"))
						.stub("markClientAsNotFraud"));
	}
	
	
	/*@Configuration
	@RestController
	static class TestConfiguration {

		@ResponseBody
		@RequestMapping("/resource")
		public String resource() {
			return "Hello World";
		}

		@ResponseBody
		@RequestMapping("/status")
		public ResponseEntity<String> status() {
			return ResponseEntity.status(HttpStatus.ACCEPTED).body("Hello World");
		}
	}*/

}
