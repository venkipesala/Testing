package com.citibanamex.service.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.io.IOException;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.citibanamex.ApiExampleApplicationTests;
import com.citibanamex.model.Account;
import com.citibanamex.service.AccountService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

/**
 * @author Martin Barcenas
 *
 */
public class AccountServiceTests extends ApiExampleApplicationTests {

	@Autowired
	private AccountService accountService;

	@Test
	public void getAll() throws JsonParseException, JsonMappingException, IOException {
		assertNotNull(accountService);
		List<Account> accounts = accountService.getAll();
		assertThat(accounts.size(), equalTo(100));
	}

	@Test
	public void getOne() throws IOException {
		assertNotNull(accountService);
		Account account = accountService.get("CFBDC2D6-D261-D8D3-295E-757F62FC2138");
		assertNotNull(account);
		assertThat(account.getAccountId(), equalTo("CFBDC2D6-D261-D8D3-295E-757F62FC2138"));
	}
}
