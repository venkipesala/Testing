package com.citibanamex.controller.test;

import static com.jayway.restassured.path.json.JsonPath.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.io.InputStream;
import java.net.URL;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.citibanamex.ApiExampleApplicationTests;
import com.citibanamex.model.Account;

/**
 * @author Martin Barcenas
 *
 */
@AutoConfigureMockMvc
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AccountControllerTests extends ApiExampleApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void test1_Accounts() throws Exception {
		mockMvc.perform(get("/api/v1/accounts"))
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.data").isArray());
	}

	@Test
	public void test2_accountByUUID() throws Exception {
		String uuid = "237E9C6D-B390-5CE2-AC9D-3EE18C35EAAB";
		MvcResult result = mockMvc.perform(get("/api/v1/accounts/{uuid}", uuid)).andExpect(status().isOk()).andReturn();
		Account account = from(result.getResponse().getContentAsString()).getObject("data", Account.class);
		assertThat(account.getAccountId(), equalTo(uuid));
	}
	
	@Test
	public void test3_create() throws Exception {
		String body = new StringBuilder().append("{")
				.append("\"account_id\": \"\",")
				.append("\"name\": \"Rajah\",")
				.append("\"last_name\": \"Dudley\",")
				.append("\"email\": \"aliquet.lobortis@tincidunt.edu\",")
				.append("\"birthday\": \"14/02/1994\",")
				.append("\"address\": \"8130 Quisque Rd.\",")
				.append("\"city\": \"Altmunster\",")
				.append("\"zip_code\": \"10412\",")
				.append("\"credit_card\": \"5298-8220-6975-0229\"")
			.append("}").toString();
		
		MvcResult result = mockMvc.perform(post("/api/v1/accounts").contentType(MediaType.APPLICATION_JSON).content(body))
				.andExpect(status().isOk()).andReturn();
		String json = result.getResponse().getContentAsString();
		Account account = from(json).getObject("data", Account.class);
		assertNotNull(account.getAccountId());
	}
	
	// This tests needs that Hystrix circuit breaker has been hit before the stream sends anything
	@Test
	public void test4_testHystrixStream() throws Exception {
		String url = "http://localhost:" + port + "/hystrix.stream";
		
		URL hystrixUrl = new URL(url);
		InputStream in = hystrixUrl.openStream();
		byte[] buffer = new byte[1024];
		in.read(buffer);
		String contents = new String(buffer);
		assertTrue("Wrong content: \n" + contents, contents.contains("data") || contents.contains("ping"));
		in.close();
	}

}
