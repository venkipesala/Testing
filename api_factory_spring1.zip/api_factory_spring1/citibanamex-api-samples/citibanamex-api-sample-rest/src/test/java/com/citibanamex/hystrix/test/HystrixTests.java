/**
 * 
 */
package com.citibanamex.hystrix.test;

import static org.junit.Assert.*;

import java.io.InputStream;
import java.net.URL;

import org.junit.Test;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.citibanamex.ApiExampleApplicationTests;

/**
 * @author Martin Barcenas
 *
 */
public class HystrixTests /*extends ApiExampleApplicationTests*/ {
	
	//@Test
	public void testHystrixStream() throws Exception {
		String url = "http://localhost:" + 23;
		// you have to hit a Hystrix circuit breaker before the stream sends anything
		ResponseEntity<String> response = new TestRestTemplate().getForEntity(url, String.class);
		assertEquals("bad response code", HttpStatus.OK, response.getStatusCode());

		URL hystrixUrl = new URL(url + "/hystrix.stream");
		InputStream in = hystrixUrl.openStream();
		byte[] buffer = new byte[1024];
		in.read(buffer);
		String contents = new String(buffer);
		assertTrue("Wrong content: \n" + contents, contents.contains("data") || contents.contains("ping"));
		in.close();
	}

}
