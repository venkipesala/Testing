#!/bin/bash

mkdir -p ${HOME}/.m2

ROOT_IN_M2_RESOURCE="${ROOT_FOLDER}/${M2_REPO}/root"
export M2_HOME="${ROOT_IN_M2_RESOURCE}/.m2"
export NEW_LOCAL_REPO="${M2_HOME}/repository/"

echo "Generating settings.xml for Maven in local m2"

cat > ${HOME}/.m2/settings.xml <<EOF

<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0
                          https://maven.apache.org/xsd/settings-1.0.0.xsd">
  <pluginGroups>
    <pluginGroup>org.sonarsource.scanner.maven</pluginGroup>
  </pluginGroups>
  <mirrors>
    <mirror>
      <!--This sends everything else to /public -->
      <id>nexus</id>
      <mirrorOf>*</mirrorOf>
      <url>${M2_REPO_URL}</url>
    </mirror>
  </mirrors>
  <profiles>
    <profile>
      <id>nexus</id>
      <!--Enable snapshots for the built in central repo to direct -->
      <!--all requests to nexus via the mirror -->
      <repositories>
        <repository>
          <id>central</id>
          <url>http://central</url>
          <!--url>http://repo1.maven.org/maven2</url-->
          <releases><enabled>true</enabled></releases>
          <snapshots><enabled>true</enabled></snapshots>
        </repository>
      </repositories>
     <pluginRepositories>
        <pluginRepository>
          <id>central</id>
          <url>http://central</url>
          <!--url>http://repo1.maven.org/maven2</url-->
          <releases><enabled>true</enabled></releases>
          <snapshots><enabled>true</enabled></snapshots>
        </pluginRepository>
      </pluginRepositories>
    </profile>
    <profile>
      <id>sonar</id>
      <properties>
        <!-- Optional URL to server. Default value is http://localhost:9000 -->
        <sonar.host.url>${M2_SETTINGS_SONAR_URL}</sonar.host.url>
      </properties>
    </profile>
  </profiles>
  <activeProfiles>
    <!--make the profile active all the time -->
    <activeProfile>nexus</activeProfile>
  </activeProfiles>

  <servers>
    <server>
      <id>${M2_SETTINGS_REPO_ID}</id>
      <username>${M2_SETTINGS_REPO_USERNAME}</username>
      <password>${M2_SETTINGS_REPO_PASSWORD}</password>
    </server>
  </servers>
</settings>
EOF
echo "Settings xml written"

echo "Moving [${NEW_LOCAL_REPO}] [${HOME}] folder"
mv ${NEW_LOCAL_REPO} ${HOME}/.m2/repository

