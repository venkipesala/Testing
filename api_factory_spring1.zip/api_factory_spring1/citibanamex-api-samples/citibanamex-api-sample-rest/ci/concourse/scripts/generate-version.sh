#!/bin/bash

export ROOT_FOLDER=$( pwd )
export REPO_RESOURCE=repo
export VERSION_RESOURCE=version
export M2_RESOURCE=m2
export OUTPUT_RESOURCE=out

cd out

output=$( pwd )

if [[ -f ../version/version ]]; then 
  VERSION=$( cat ../version/version)

else
  source ${ROOT_FOLDER}/${REPO_RESOURCE}/citibanamex-api-samples/citibanamex-api-sample-rest/ci/concourse/scripts/maven-settings.sh
  cd ${ROOT_FOLDER}/${REPO_RESOURCE}/citibanamex-api-samples/citibanamex-api-sample-rest
  echo "Using mvnw, it could take a while to download..."
  ./mvnw help:evaluate -Dexpression=project.version > output-trace.txt
  while read -r line
  do
    if [[ $line == [0-9]* ]]; then 
      VERSION=$line 
    fi
  done < output-trace.txt

fi

echo "Current Version: ${VERSION}"

IFS='.' read -ra version_tokens <<< "$VERSION"

last_index=`echo "$VERSION" | awk -F'.' '{print NF}'`
last_index=$((last_index-1))

VERSION=${VERSION%${version_tokens[$last_index]}}

if [[ "${version_tokens[$last_index]}" == rc-* ]]; then 
  version_number=`echo "${version_tokens[$last_index]}" | awk -F'rc-' '{print $2}'`
  version_number=$((version_number+1))
else
  version_number=1
fi

VERSION="$VERSION"rc-"$version_number"

MESSAGE="[Concourse CI] Bump to Next Version ($VERSION)"

echo "moving to folder $output"

cd $(echo $output)

cp -r ../version/. ./
echo "Bump to ${VERSION}"
echo "${VERSION}" > version

git config --global user.email "${GIT_EMAIL}"
git config --global user.name "${GIT_NAME}"
git add version
git commit -m "${MESSAGE}"