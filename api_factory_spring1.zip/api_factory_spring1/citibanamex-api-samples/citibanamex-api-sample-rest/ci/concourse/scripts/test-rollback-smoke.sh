#!/bin/bash

export ROOT_FOLDER=$( pwd )
export REPO_RESOURCE=repo
export VERSION_RESOURCE=version
export OUTPUT_RESOURCE=out

echo "Root folder is [${ROOT_FOLDER}]"
echo "Repo resource folder is [${REPO_RESOURCE}]"
echo "Version resource folder is [${VERSION_RESOURCE}]"

source ${ROOT_FOLDER}/${REPO_RESOURCE}/citibanamex-api-samples/citibanamex-api-sample-rest/ci/concourse/scripts/pipeline.sh

echo "Testing the rolled back built application on test environment"
cd ${ROOT_FOLDER}/${REPO_RESOURCE}/citibanamex-api-samples/citibanamex-api-sample-rest

prepareForSmokeTests "${REDOWNLOAD_INFRA}" "${CF_TEST_USERNAME}" "${CF_TEST_PASSWORD}" "${CF_TEST_ORG}" "${CF_TEST_SPACE}" "${CF_TEST_API_URL}"

echo "Resolving latest prod tag"
LATEST_PROD_TAG=$( findLatestProdTag )

echo "Retrieved application and stub runner urls"
echo "Latest prod tag: ${LATEST_PROD_TAG}"
if [[ -z "${LATEST_PROD_TAG}" || "${LATEST_PROD_TAG}" == "development" ]]; then
    echo "No prod release took place - skipping this step"
else
    git checkout "${LATEST_PROD_TAG}"
    . ${SCRIPTS_OUTPUT_FOLDER}/test-rollback-smoke.sh
fi