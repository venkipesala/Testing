#!/bin/bash

export ROOT_FOLDER=$( pwd )
export REPO_RESOURCE=repo
export OUTPUT=out

source ${ROOT_FOLDER}/${REPO_RESOURCE}/api-example/ci/scripts/maven-settings.sh

cd ${ROOT_FOLDER}/${REPO_RESOURCE}/api-example

#VERSION=$(mvn help:evaluate -Dexpression=project.version | grep -e '^[0-9]')
mvn help:evaluate -Dexpression=project.version > version.txt
while read -r line
do
  if [[ $line == [0-9]* ]]; then 
    VERSION=$line 
  fi
done < version.txt

echo "Current Version: ${VERSION}"

MESSAGE="[Citi api-example] Release ${VERSION}"

echo "Git configuring email: ${GIT_EMAIL}"
git config --global user.email "${GIT_EMAIL}"
echo "Git configuring name: ${GIT_NAME}"
git config --global user.name "${GIT_NAME}"

#git remote set-url origin ${GIT_REPO}

echo "Tagging version: ${VERSION}"
git tag -a "${VERSION}" -m "${MESSAGE}"

#echo "pushing version: ${VERSION}"
#git push origin "${VERSION}"

echo $VERSION > ${ROOT_FOLDER}/${OUTPUT}/tag