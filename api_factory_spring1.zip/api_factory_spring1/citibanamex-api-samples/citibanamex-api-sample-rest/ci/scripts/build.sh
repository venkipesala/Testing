#!/bin/bash

export ROOT_FOLDER=$( pwd )
export REPO_RESOURCE=repo
export OUTPUT=binaries

source ${ROOT_FOLDER}/${REPO_RESOURCE}/api-example/ci/scripts/maven-settings.sh

cd ${ROOT_FOLDER}/${REPO_RESOURCE}/api-example

mvn package sonar:sonar -Dsonar.host.url=${M2_SETTINGS_SONAR_URL}

cp target/api-example*.jar ${ROOT_FOLDER}/${OUTPUT}/api-example.jar