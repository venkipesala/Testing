#!/bin/bash

export ROOT_FOLDER=$( pwd )
export REPO_RESOURCE=repo

source ${ROOT_FOLDER}/${REPO_RESOURCE}/api-example/ci/scripts/maven-settings.sh

echo "Testing project"
cd ${ROOT_FOLDER}/${REPO_RESOURCE}/api-example

mvn test
