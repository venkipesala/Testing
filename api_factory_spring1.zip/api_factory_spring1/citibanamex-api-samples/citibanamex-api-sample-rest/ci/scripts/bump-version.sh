
#!/bin/bash

export ROOT_FOLDER=$( pwd )
VERSION=`cat version/number`
MESSAGE="[Citi api-example] Release $VERSION"
REPO_RESOURCE=repo

source ${ROOT_FOLDER}/${REPO_RESOURCE}/api-example/ci/scripts/maven-settings.sh

cd ${ROOT_FOLDER}/${REPO_RESOURCE}/api-example

echo "Bump to ($VERSION)"
echo "${VERSION}" > version

mvn versions:set -DnewVersion=${VERSION}

git config --global user.email "${GIT_EMAIL}"
git config --global user.name "${GIT_NAME}"
git add pom.xml
git commit -m "${MESSAGE}"