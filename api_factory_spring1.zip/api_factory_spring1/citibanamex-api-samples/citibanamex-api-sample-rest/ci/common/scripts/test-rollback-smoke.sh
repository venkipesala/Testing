#!/bin/bash

set -o errexit

__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ -f "${__DIR}/pipeline-functions.sh" ]] && source "${__DIR}/pipeline-functions.sh" || \
    echo "No pipeline.sh found"

echo "Application URL [${APPLICATION_URL}]"
echo "StubRunner URL [${STUBRUNNER_URL}]"
echo "Latest production tag [${LATEST_PROD_TAG}]"

if [[ -z "${LATEST_PROD_TAG}" || "${LATEST_PROD_TAG}" == "development" ]]; then
    echo "No prod release took place - skipping this step"
else
    LATEST_PROD_VERSION=$( extractVersionFromProdTag ${LATEST_PROD_TAG} )
    echo "Last prod version equals ${LATEST_PROD_VERSION}"
    runSmokeTests ${APPLICATION_URL} ${STUBRUNNER_URL}
fi