#!/bin/bash

set -o errexit

__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ -f "${__DIR}/pipeline-functions.sh" ]] && source "${__DIR}/pipeline-functions.sh" || \
    echo "No pipeline.sh found"

echo "PWD: `pwd`"
echo "__DIR: ${__DIR}"
echo "Additional Maven Args [${MAVEN_ARGS}]"

./mvnw versions:set -DnewVersion=${PIPELINE_VERSION} ${MAVEN_ARGS}

if [[ "${CI}" == "CONCOURSE" ]]; then
    ./mvnw clean deploy -DuniqueVersion=false -Ddistribution.management.repository.id=${M2_SETTINGS_REPO_ID} -Ddistribution.management.releases.url=${M2_REPO_RELEASES_URL} -Ddistribution.management.snapshots.url=${M2_REPO_SNAPSHOTS_URL} ${MAVEN_ARGS} || ( $( printTestResults ) && return 1)
else
    ./mvnw clean deploy -DuniqueVersion=false -Ddistribution.management.repository.id=${M2_SETTINGS_REPO_ID} -Ddistribution.management.releases.url=${M2_REPO_RELEASES_URL} -Ddistribution.management.snapshots.url=${M2_REPO_SNAPSHOTS_URL} ${MAVEN_ARGS}
fi
