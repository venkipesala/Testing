package e2e;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.citibanamex.api.samples.rest.consumer.gateway.AccountGateway;
import com.citibanamex.api.samples.rest.consumer.model.Account;

/**
 * @author Martin Barcenas
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = E2ETests.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
@EnableAutoConfiguration
public class E2ETests {

	@Autowired
	private AccountGateway accountGateway;
	
	private String accountId;

	@Before
	public void setup() {
		accountId = "FDDFD7E5-09DC-4AA6-ABF8-5CC32BF17B94";
	}
	
	@Test
	public void createBillTest(){
		Account account = accountGateway.getById(accountId);
		assertThat(account).isNotNull();
		assertThat(account.getAccountId()).isEqualTo(accountId);
		assertThat(account.getName()).isEqualTo("Peter");
		assertThat(account.getEmail()).isEqualTo("neque.tellus@Duis.ca");
	}

}
