package com.citibanamex.api.samples.consumer.service.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.citibanamex.api.samples.consumer.test.ApiConsumerApplicationTests;
import com.citibanamex.api.samples.rest.consumer.service.BillingService;

/**
 * @author Martin Barcenas
 *
 */
public class BillingServiceTests extends ApiConsumerApplicationTests {

	@Autowired
	private BillingService billingService;

	@Test
	public void notNullTest() {
		assertThat(billingService).isNotNull();
	}

}
