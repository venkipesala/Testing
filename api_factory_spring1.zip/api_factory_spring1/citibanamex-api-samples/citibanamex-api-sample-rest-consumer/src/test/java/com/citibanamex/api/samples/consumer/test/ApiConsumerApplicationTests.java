package com.citibanamex.api.samples.consumer.test;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.citibanamex.api.samples.rest.consumer.ApiConsumerApplication;

/**
 * @author Martin Barcenas
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = ApiConsumerApplication.class, webEnvironment = WebEnvironment.RANDOM_PORT)
@DirtiesContext
public abstract class ApiConsumerApplicationTests {
	
	@Value("${local.server.port}")
	protected int port;
}
