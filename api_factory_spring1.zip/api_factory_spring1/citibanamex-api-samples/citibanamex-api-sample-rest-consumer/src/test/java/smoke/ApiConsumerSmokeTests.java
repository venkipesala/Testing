package smoke;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;

import com.citibanamex.api.samples.rest.consumer.ApiConsumerApplication;
import com.citibanamex.api.samples.rest.consumer.model.Invoice;
import com.citibanamex.api.samples.rest.consumer.service.BillingService;

/**
 * Smoke tests for consuming services from API.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = ApiConsumerApplication.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureStubRunner(ids = {"com.citibanamex.api:citibanamex-api-sample-rest:+:stubs:6565"}, workOffline = true)
@DirtiesContext
public class ApiConsumerSmokeTests {
	
	@Autowired
	private BillingService billingService;
	
	@Test
	public void contextLoads() {
		assertThat(billingService).isNotNull();
	}
	
	@Test
	public void should_successfully_create_invoice() {
		String accountId = "237E9C6D-B390-5CE2-AC9D-3EE18C35EAAB";
		
		Invoice invoice = billingService.createInvoice(accountId);
		
		assertThat(invoice.getClientEmail()).isEqualTo("Quisque@etultricesposuere.org");
		assertThat(invoice.getPaymentDue()).isNotNull();
	}
	
	@Test(expected = HttpClientErrorException.class)
	public void should_fail_create_invoice() {
		String accountId = "FDDFD7E5-09DC-4AA6-ABF8-5CC32BF17B94";

		billingService.createInvoice(accountId);
	}
	
}
