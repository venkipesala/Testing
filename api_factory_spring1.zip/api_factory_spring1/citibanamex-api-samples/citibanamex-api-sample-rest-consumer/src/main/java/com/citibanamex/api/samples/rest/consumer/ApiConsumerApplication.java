package com.citibanamex.api.samples.rest.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 * @author Martin Barcenas 
 * 
 */
@SpringBootApplication
public class ApiConsumerApplication {
	
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder){
		return builder.build();
	}
	
	public static void main(String[] args) {
		SpringApplication.run(ApiConsumerApplication.class, args);
	}
	
}
