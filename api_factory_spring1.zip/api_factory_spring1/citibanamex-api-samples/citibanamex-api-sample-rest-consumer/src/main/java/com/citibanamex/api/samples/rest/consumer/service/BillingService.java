package com.citibanamex.api.samples.rest.consumer.service;

import com.citibanamex.api.samples.rest.consumer.model.Invoice;

/**
 * @author Martin Barcenas
 *
 */
public interface BillingService {
	
	public Invoice createInvoice(String accountUUID);

}
