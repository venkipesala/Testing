package com.citibanamex.api.samples.rest.consumer.gateway;

import static io.restassured.path.json.JsonPath.from;

import java.net.URI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.citibanamex.api.samples.rest.consumer.model.Account;

/**
 * @author Martin Barcenas
 *
 */
@Component
public class AccountGateway {

	private static final Logger LOG = LoggerFactory.getLogger(AccountGateway.class);

	@Autowired
	private RestTemplate restTemplate;

	@Value("${api.url}")
	private String apiUrl;

	public Account getById(String accountId) {

		URI uri = UriComponentsBuilder.fromUriString(apiUrl).pathSegment("accounts", accountId).build().toUri();

		LOG.debug("trying to get account from: {}", uri.toString());

		ResponseEntity<String> response = restTemplate.getForEntity(uri, String.class);
		String json = response.getBody();

		Account account = from(json).getObject("data", Account.class);
		return account;
	}

}
