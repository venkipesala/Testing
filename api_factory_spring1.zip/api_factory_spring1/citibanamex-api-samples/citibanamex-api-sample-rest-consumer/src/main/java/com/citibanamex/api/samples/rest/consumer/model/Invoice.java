package com.citibanamex.api.samples.rest.consumer.model;

/**
 * @author Martin Barcenas
 *
 */
public class Invoice {

	private String clientEmail;
	
	private Double paymentDue;

	/**
	 * Default constructor
	 */
	// for json serialization
	public Invoice() {
		// placeholder
	}

	/**
	 * Creates an invoice by its client email and payment due.
	 * 
	 * @param clientEmail
	 *            String representation of the client email
	 * @param paymentDue
	 *            integer for the payment due
	 */
	public Invoice(String clientEmail, Double paymentDue) {
		this.clientEmail = clientEmail;
		this.paymentDue = paymentDue;
	}

	/**
	 * @return the client email
	 */
	public String getClientEmail() {
		return clientEmail;
	}

	/**
	 * @return the payment due
	 */
	public Double getPaymentDue() {
		return paymentDue;
	}

}
