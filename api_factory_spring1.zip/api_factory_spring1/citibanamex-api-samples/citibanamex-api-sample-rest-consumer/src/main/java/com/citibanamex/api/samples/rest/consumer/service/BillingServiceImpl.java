/**
 * 
 */
package com.citibanamex.api.samples.rest.consumer.service;

import java.util.concurrent.ThreadLocalRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citibanamex.api.samples.rest.consumer.gateway.AccountGateway;
import com.citibanamex.api.samples.rest.consumer.model.Account;
import com.citibanamex.api.samples.rest.consumer.model.Invoice;

/**
 * @author Martin Barcenas
 *
 */
@Service
public class BillingServiceImpl implements BillingService {
	
	@Autowired
	private AccountGateway accountGateway;

	/**
	 * @see smoke.service.BillingService#createInvoice(String)
	 */
	@Override
	public Invoice createInvoice(String accountUUID) {
		Account account = accountGateway.getById(accountUUID);
		double paymentDue = ThreadLocalRandom.current().nextDouble(100, 1000);
		return new Invoice(account.getEmail(), paymentDue);
	}

}
