/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CommonResponseFormatter.java
 * Original Author: Softtek
 * Creation Date: 10/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.formatter.responseformatter;

/**
 * The Interface CommonResponseFormatter.
 */
@FunctionalInterface
public interface CommonResponseFormatter {
	
	/**
	 * Format to response.
	 *
	 * @param maccountChecksCommonOutputOk the maccount checks common output ok
	 * @return the object
	 */
	public Object formatToResponse(
			Object maccountChecksCommonOutputOk);
}
