/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksCommonResponseAggregator.java
 * Original Author: Softtek
 * Creation Date: 2/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.aggregator;

import org.springframework.stereotype.Component;

import com.citi.query.aggregator.reader.MaccountChecksCommonResponseRead;
import com.citi.query.aggregator.reader.impl.MaccountChecksAfterBalanceResponseRead;
import com.citi.query.aggregator.reader.impl.MaccountChecksBeforeBalanceResponseRead;
import com.citi.query.aggregator.reader.impl.MaccountChecksMovementsResponseRead;
import com.citi.query.contract.MaccountChecksCommonsResponseContract;
import com.citi.query.exception.MaccountChecksCommonException;
import com.citi.query.formatter.responseformatter.impl.MaccountChecksAfterBalanceResponseFormatter;
import com.citi.query.formatter.responseformatter.impl.MaccountChecksBeforeBalanceResponseFormatter;
import com.citi.query.formatter.responseformatter.impl.MaccountChecksMovementsResponseFormatter;
import com.citi.query.model.MaccounChecksMovementsOutputOk;
import com.citi.query.model.MaccountCheckBeforeBalanceOutputOk;
import com.citi.query.model.MaccountChecksAfterBalanceOutputOk;
import com.citi.query.model.MaccountChecksCommonError;
import com.citi.query.response.MaccountCheckBeforeBalanceResponse;
import com.citi.query.response.MaccountCheckMovementsResponse;
import com.citi.query.response.MaccountChecksAfterBalanceResponse;
import com.citi.unisys.model.HeaderBnmx;
import com.citi.unisys.model.HeaderSa2;
import com.citi.unisys.utils.UnisysResultException;
import com.softtek.legacy.framework.model.DataElementFormatException;
import com.softtek.legacy.framework.parser.ParserException;
import com.softtek.legacy.framework.util.BufferToEntity;

/**
 * The Class MaccountChecksCommonResponseAggregator.
 */
@Component
public class MaccountChecksCommonResponseAggregator {

	/** The maccount checks commons response contract. */
	private MaccountChecksCommonsResponseContract maccountChecksCommonsResponseContract;

	/**
	 * Gets the contract response.
	 *
	 * @param bufferOutput
	 *            the buffer output
	 * @param opcion
	 *            the opcion
	 * @return the contract response
	 * @throws DataElementFormatException
	 *             the data element format exception
	 * @throws ParserException
	 *             the parser exception
	 * @throws UnisysResultException
	 *             the unisys result exception
	 * @throws MaccountChecksCommonException
	 *             the maccount checks common exception
	 */
	public MaccountChecksCommonsResponseContract getContractResponse(String bufferOutput, int opcion)
			throws DataElementFormatException, ParserException, UnisysResultException, MaccountChecksCommonException {
//		bufferOutput = "F0200000Y0870D62040000200         0015120050140015007810050007812214700060020100011001506208024925150723163244200000        A FR90660006600081234512567690000000033664238HECTOR EFREN LOZANO GONZALEZ                           15070415072215070115070400000082039459S000161000000013193000000120000000005848000000083402021S123456789012341234567890123412345678901234301850000009478392100000105909956000000001017420000000085699900128001800008000000000040434123456654321001506300000005100150015060500000011DEPOSITO P/TRASPASO00000                S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO00000000000          S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO00000000000000000    S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO°                    S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO°°°°°°°              S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO°°°°°°°°°°°°°        S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO°°°°°°°°°°°°°°°°°°°  S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S00000082049459";
		maccountChecksCommonsResponseContract = new MaccountChecksCommonsResponseContract();

		readHeaderContractResponse(bufferOutput.substring(0, 125));
		int result = maccountChecksCommonsResponseContract.getHeaderSa2().getSa2Resultado();
//		result = Integer.parseInt(bufferOutput.substring(82,83));
		switch (result) {
		case 0:
			throw new UnisysResultException(
					maccountChecksCommonsResponseContract.getHeaderBnmx().getHdrBnmxResultado());
		case 1:
			return responseGetContract(bufferOutput, opcion);
//			maccountChecksCommonsResponseContract.setMaccountChecksCommonsResponse(
//					responseReadBuild(opcion).readResponse(bufferOutput.substring(125)));
		case 2:
			readOutputErrorContractResponse(bufferOutput.substring(125));
			MaccountChecksCommonError errorModel = maccountChecksCommonsResponseContract.getCommunError();
			throw new MaccountChecksCommonException(errorModel.getWksN012EcResult(), errorModel.getFiller4());
		default:
			return maccountChecksCommonsResponseContract;
		}
		
	}

	/**
	 * Read header contract response.
	 *
	 * @param bufferOutput
	 *            the buffer output
	 * @throws DataElementFormatException
	 *             the data element format exception
	 * @throws ParserException
	 *             the parser exception
	 */
	private void readHeaderContractResponse(String bufferOutput) throws DataElementFormatException, ParserException {

		HeaderBnmx headerBnmx = new HeaderBnmx();
		HeaderSa2 headerSa2 = new HeaderSa2();

		maccountChecksCommonsResponseContract
				.setHeaderBnmx((HeaderBnmx) getEntityFromBuffer(bufferOutput.substring(0, 48), headerBnmx));
		maccountChecksCommonsResponseContract
				.setHeaderSa2((HeaderSa2) getEntityFromBuffer(bufferOutput.substring(48), headerSa2));
	}

	/**
	 * Response read build.
	 *
	 * @param opcion
	 *            the opcion
	 * @return the maccount checks common response read
	 */
	private MaccountChecksCommonResponseRead responseReadBuild(int opcion) {
		switch (opcion) {
		case 41:
			return new MaccountChecksAfterBalanceResponseRead();
		case 42:
			return new MaccountChecksBeforeBalanceResponseRead();
		case 43:
			return new MaccountChecksMovementsResponseRead();
		default:
			return null;
		}

	}

	
	private MaccountChecksCommonsResponseContract responseGetContract(String bufferOutput, int opcion) throws DataElementFormatException, ParserException{
	
		switch (opcion) {
		case 41:
			MaccountChecksAfterBalanceResponseFormatter afterFormatter = new MaccountChecksAfterBalanceResponseFormatter();
			MaccountChecksAfterBalanceOutputOk outputOkAfter = new MaccountChecksAfterBalanceResponseRead().readResponse(bufferOutput.substring(125));
			MaccountChecksAfterBalanceResponse afterResponse = afterFormatter.formatToResponse(outputOkAfter);
			maccountChecksCommonsResponseContract.setAfterResponse(afterResponse);
			return maccountChecksCommonsResponseContract;
		case 42:
			MaccountChecksBeforeBalanceResponseFormatter beforeFormatter = new MaccountChecksBeforeBalanceResponseFormatter();
			MaccountCheckBeforeBalanceOutputOk outputOkBefore = new MaccountChecksBeforeBalanceResponseRead().readResponse(bufferOutput.substring(125));
			MaccountCheckBeforeBalanceResponse beforeResponse = beforeFormatter.formatToResponse(outputOkBefore);
			maccountChecksCommonsResponseContract.setBeforeResponse(beforeResponse);
			return maccountChecksCommonsResponseContract;
			
		case 43:
			
			MaccountChecksMovementsResponseFormatter movementsFormatter = new MaccountChecksMovementsResponseFormatter();
			MaccounChecksMovementsOutputOk outputOkMovements = new MaccountChecksMovementsResponseRead().readResponse(bufferOutput.substring(125));
			MaccountCheckMovementsResponse movementsResponse = movementsFormatter.formatToResponse(outputOkMovements);
			maccountChecksCommonsResponseContract.setMovementsResponse(movementsResponse);
			return maccountChecksCommonsResponseContract;
	
		default:
			
			return null;
		}
		
	}
	/**
	 * Gets the entity from buffer.
	 *
	 * @param bufferOutput
	 *            the buffer output
	 * @param objectModel
	 *            the object model
	 * @return the entity from buffer
	 * @throws DataElementFormatException
	 *             the data element format exception
	 * @throws ParserException
	 *             the parser exception
	 */
	protected Object getEntityFromBuffer(String bufferOutput, Object objectModel)
			throws DataElementFormatException, ParserException {

		if (bufferOutput.trim().isEmpty())
			return objectModel;

		BufferToEntity buffToEntityBnmx = new BufferToEntity(bufferOutput, objectModel);
		buffToEntityBnmx.build();

		return objectModel;
	}

	/**
	 * Read output error contract response.
	 *
	 * @param bufferOutput
	 *            the buffer output
	 * @throws DataElementFormatException
	 *             the data element format exception
	 * @throws ParserException
	 *             the parser exception
	 */
	private void readOutputErrorContractResponse(String bufferOutput)
			throws DataElementFormatException, ParserException {

		MaccountChecksCommonError errorModel = new MaccountChecksCommonError();
		maccountChecksCommonsResponseContract
				.setCommunError((MaccountChecksCommonError) getEntityFromBuffer(bufferOutput, errorModel));
	}

	/**
	 * Gets the maccount checks commons response contract.
	 *
	 * @return the maccount checks commons response contract
	 */
	public MaccountChecksCommonsResponseContract getMaccountChecksCommonsResponseContract() {
		return maccountChecksCommonsResponseContract;
	}

	/**
	 * Sets the maccount checks commons response contract.
	 *
	 * @param contractResponse
	 *            the new maccount checks commons response contract
	 */
	public void setMaccountChecksCommonsResponseContract(MaccountChecksCommonsResponseContract contractResponse) {
		this.maccountChecksCommonsResponseContract = contractResponse;
	}

}
