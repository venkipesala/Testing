/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: GroupOccurs.java
 * Original Author: ENLM
 * Creation Date: 31/01/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.model;

import com.softtek.legacy.framework.model.DataElement.DataType;
import com.softtek.legacy.framework.model.EntityModel;

/**
 * The Class GroupOccurs.
 *
 * @author el14811
 * @version 1.0
 */
public class GroupOccurs {
	
	/** The wks N 012 ec mov ciclo. */
	@EntityModel(index = 0, value = "", name = "wksN012EcMovCiclo", fieldType = DataType.INTEGER, length = 2, decimales = 0, format = "")
	private int wksN012EcMovCiclo;
	
	/** The wks N 012 ec mov fecha. */
	@EntityModel(index = 1, value = "", name = "wksN012EcMovFecha", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcMovFecha;
	
	/** The wks N 012 ec mov sig. */
	@EntityModel(index = 2, value = "", name = "wksN012EcMovSig", fieldType = DataType.INTEGER, length = 8, decimales = 0, format = "")
	private int wksN012EcMovSig;
	
	/** The wks N 012 ec mov concept. */
	@EntityModel(index = 3, value = "", name = "wksN012EcMovConcept", fieldType = DataType.VARCHAR, length = 40, decimales = 0, format = "")
	private String wksN012EcMovConcept;
	
	/** The wks N 012 ec mov signo. */
	@EntityModel(index = 4, value = "", name = "wksN012EcMovSigno", fieldType = DataType.VARCHAR, length = 1, decimales = 0, format = "")
	private String wksN012EcMovSigno;
	
	/** The wks N 012 ec mov importe. */
	@EntityModel(index = 5, value = "", name = "wksN012EcMovImporte", fieldType = DataType.DOUBLE, length = 12, decimales = 2, format = "")
	private double wksN012EcMovImporte;
	
	/** The wks N 012 ec referencia num. */
	@EntityModel(index = 6, value = "", name = "wksN012EcReferenciaNum", fieldType = DataType.VARCHAR, length = 16, decimales = 0, format = "")
	private String wksN012EcReferenciaNum;
	
	/** The wks N 012 ec num aut. */
	@EntityModel(index = 7, value = "", name = "wksN012EcNumAut", fieldType = DataType.INTEGER, length = 8, decimales = 0, format = "")
	private int wksN012EcNumAut;
	
	/** The wks N 012 ec mov signo imp. */
	@EntityModel(index = 8, value = "", name = "wksN012EcMovSignoImp", fieldType = DataType.VARCHAR, length = 1, decimales = 0, format = "")
	private String wksN012EcMovSignoImp;
	
	/** The wks N 012 ec mov imp des trx. */
	@EntityModel(index = 9, value = "", name = "wksN012EcMovImpDesTrx", fieldType = DataType.DOUBLE, length = 12, decimales = 2, format = "")
	private double wksN012EcMovImpDesTrx;

	/**
	 * Sets the wks N 012 ec mov ciclo.
	 *
	 * @param parameter the new wks N 012 ec mov ciclo
	 */
	public void setWksN012EcMovCiclo(int parameter) {
		wksN012EcMovCiclo = parameter;
	}

	/**
	 * Gets the wks N 012 ec mov ciclo.
	 *
	 * @return wksN012EcMovCiclo
	 */
	public int getWksN012EcMovCiclo() {
		return wksN012EcMovCiclo;
	}

	/**
	 * Sets the wks N 012 ec mov fecha.
	 *
	 * @param parameter the new wks N 012 ec mov fecha
	 */
	public void setWksN012EcMovFecha(int parameter) {
		wksN012EcMovFecha = parameter;
	}

	/**
	 * Gets the wks N 012 ec mov fecha.
	 *
	 * @return wksN012EcMovFecha
	 */
	public int getWksN012EcMovFecha() {
		return wksN012EcMovFecha;
	}

	/**
	 * Sets the wks N 012 ec mov sig.
	 *
	 * @param parameter the new wks N 012 ec mov sig
	 */
	public void setWksN012EcMovSig(int parameter) {
		wksN012EcMovSig = parameter;
	}

	/**
	 * Gets the wks N 012 ec mov sig.
	 *
	 * @return wksN012EcMovSig
	 */
	public int getWksN012EcMovSig() {
		return wksN012EcMovSig;
	}

	/**
	 * Sets the wks N 012 ec mov concept.
	 *
	 * @param parameter the new wks N 012 ec mov concept
	 */
	public void setWksN012EcMovConcept(String parameter) {
		wksN012EcMovConcept = parameter;
	}

	/**
	 * Gets the wks N 012 ec mov concept.
	 *
	 * @return wksN012EcMovConcept
	 */
	public String getWksN012EcMovConcept() {
		return wksN012EcMovConcept;
	}

	/**
	 * Sets the wks N 012 ec mov signo.
	 *
	 * @param parameter the new wks N 012 ec mov signo
	 */
	public void setWksN012EcMovSigno(String parameter) {
		wksN012EcMovSigno = parameter;
	}

	/**
	 * Gets the wks N 012 ec mov signo.
	 *
	 * @return wksN012EcMovSigno
	 */
	public String getWksN012EcMovSigno() {
		return wksN012EcMovSigno;
	}

	/**
	 * Sets the wks N 012 ec mov importe.
	 *
	 * @param parameter the new wks N 012 ec mov importe
	 */
	public void setWksN012EcMovImporte(double parameter) {
		wksN012EcMovImporte = parameter;
	}

	/**
	 * Gets the wks N 012 ec mov importe.
	 *
	 * @return wksN012EcMovImporte
	 */
	public double getWksN012EcMovImporte() {
		return wksN012EcMovImporte;
	}

	/**
	 * Sets the wks N 012 ec referencia num.
	 *
	 * @param parameter the new wks N 012 ec referencia num
	 */
	public void setWksN012EcReferenciaNum(String parameter) {
		wksN012EcReferenciaNum = parameter;
	}

	/**
	 * Gets the wks N 012 ec referencia num.
	 *
	 * @return wksN012EcReferenciaNum
	 */
	public String getWksN012EcReferenciaNum() {
		return wksN012EcReferenciaNum;
	}

	/**
	 * Sets the wks N 012 ec num aut.
	 *
	 * @param parameter the new wks N 012 ec num aut
	 */
	public void setWksN012EcNumAut(int parameter) {
		wksN012EcNumAut = parameter;
	}

	/**
	 * Gets the wks N 012 ec num aut.
	 *
	 * @return wksN012EcNumAut
	 */
	public int getWksN012EcNumAut() {
		return wksN012EcNumAut;
	}

	/**
	 * Sets the wks N 012 ec mov signo imp.
	 *
	 * @param parameter the new wks N 012 ec mov signo imp
	 */
	public void setWksN012EcMovSignoImp(String parameter) {
		wksN012EcMovSignoImp = parameter;
	}

	/**
	 * Gets the wks N 012 ec mov signo imp.
	 *
	 * @return wksN012EcMovSignoImp
	 */
	public String getWksN012EcMovSignoImp() {
		return wksN012EcMovSignoImp;
	}

	/**
	 * Sets the wks N 012 ec mov imp des trx.
	 *
	 * @param parameter the new wks N 012 ec mov imp des trx
	 */
	public void setWksN012EcMovImpDesTrx(double parameter) {
		wksN012EcMovImpDesTrx = parameter;
	}

	/**
	 * Gets the wks N 012 ec mov imp des trx.
	 *
	 * @return wksN012EcMovImpDesTrx
	 */
	public double getWksN012EcMovImpDesTrx() {
		return wksN012EcMovImpDesTrx;
	}

} // groupOccurs
