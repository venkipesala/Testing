/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksAfterBalanceOutputOk.java
 * Original Author: Softtek
 * Creation Date: 2/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.model;

import java.math.BigInteger;
import java.util.List;

import com.softtek.legacy.framework.model.DataElement.DataType;
import com.softtek.legacy.framework.model.EntityModel;

/**
 * The Class MaccountChecksAfterBalanceOutputOk.
 */
public class MaccountChecksAfterBalanceOutputOk {

	/** The filler 3. */
	@EntityModel(index = 0, value = "", name = "filler3", fieldType = DataType.VARCHAR, length = 6, decimales = 0, format = "")
	private String filler3;

	/** The wks N 012 ec result. */
	@EntityModel(index = 1, value = "", name = "wksN012EcResult", fieldType = DataType.INTEGER, length = 2, decimales = 0, format = "")
	private int wksN012EcResult;

	/** The wks N 012 ec prod. */
	@EntityModel(index = 2, value = "", name = "wksN012EcProd", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcProd;

	/** The wks N 012 ec inst. */
	@EntityModel(index = 3, value = "", name = "wksN012EcInst", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcInst;

	/** The wks N 012 tra dt suc. */
	@EntityModel(index = 4, value = "", name = "wksN012TraDtSuc", fieldType = DataType.VARCHAR, length = 4, decimales = 0, format = "")
	private String wksN012TraDtSuc;

	/** The wks N 012 tra dt cta. */
	@EntityModel(index = 5, value = "", name = "wksN012TraDtCta", fieldType = DataType.BIGINTEGER, length = 12, decimales = 0, format = "")
	private BigInteger wksN012TraDtCta;

	/** The wks nctl numcte. */
	@EntityModel(index = 6, value = "", name = "wksNctlNumcte", fieldType = DataType.BIGINTEGER, length = 12, decimales = 0, format = "")
	private BigInteger wksNctlNumcte;

	/** The wks N 012 ec nomcte. */
	@EntityModel(index = 7, value = "", name = "wksN012EcNomcte", fieldType = DataType.VARCHAR, length = 55, decimales = 0, format = "")
	private String wksN012EcNomcte;

	/** The wks N 012 ec fecha corte. */
	@EntityModel(index = 8, value = "", name = "wksN012EcFechaCorte", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcFechaCorte;

	/** The wks N 012 ec fecha ultmov. */
	@EntityModel(index = 9, value = "", name = "wksN012EcFechaUltmov", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcFechaUltmov;

	/** The wks N 012 ec fecha ini. */
	@EntityModel(index = 10, value = "", name = "wksN012EcFechaIni", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcFechaIni;

	/** The wks N 012 ec fecha fin. */
	@EntityModel(index = 11, value = "", name = "wksN012EcFechaFin", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcFechaFin;

	/** The wks N 012 ec sdo inicial. */
	@EntityModel(index = 12, value = "", name = "wksN012EcSdoInicial", fieldType = DataType.VARCHAR, length = 12, decimales = 2, format = "")
	private String wksN012EcSdoInicial;

	/** The wks N 012 ec sdo inisigno. */
	@EntityModel(index = 13, value = "", name = "wksN012EcSdoInisigno", fieldType = DataType.VARCHAR, length = 1, decimales = 0, format = "")
	private String wksN012EcSdoInisigno;

	/** The wks N 012 ec abo num. */
	@EntityModel(index = 14, value = "", name = "wksN012EcAboNum", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcAboNum;

	/** The wks N 012 ec abo importe. */
	@EntityModel(index = 15, value = "", name = "wksN012EcAboImporte", fieldType = DataType.VARCHAR, length = 12, decimales = 2, format = "")
	private String wksN012EcAboImporte;

	/** The wks N 012 ec car num. */
	@EntityModel(index = 16, value = "", name = "wksN012EcCarNum", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcCarNum;

	/** The wks N 012 ec car importe. */
	@EntityModel(index = 17, value = "", name = "wksN012EcCarImporte", fieldType = DataType.VARCHAR, length = 12, decimales = 2, format = "")
	private String wksN012EcCarImporte;

	/** The wks N 012 ec sdo actual. */
	@EntityModel(index = 18, value = "", name = "wksN012EcSdoActual", fieldType = DataType.VARCHAR, length = 12, decimales = 2, format = "")
	private String wksN012EcSdoActual;

	/** The wks N 012 ec sdo actsigno. */
	@EntityModel(index = 19, value = "", name = "wksN012EcSdoActsigno", fieldType = DataType.VARCHAR, length = 1, decimales = 0, format = "")
	private String wksN012EcSdoActsigno;

	/** The wks N 012 ec lc importe. */
	@EntityModel(index = 20, value = "", name = "wksN012EcLcImporte", fieldType = DataType.VARCHAR, length = 12, decimales = 2, format = "")
	private String wksN012EcLcImporte;

	/** The wks N 012 ec lc sdo. */
	@EntityModel(index = 21, value = "", name = "wksN012EcLcSdo", fieldType = DataType.VARCHAR, length = 12, decimales = 2, format = "")
	private String wksN012EcLcSdo;

	/** The wks N 012 ec lc disp. */
	@EntityModel(index = 22, value = "", name = "wksN012EcLcDisp", fieldType = DataType.VARCHAR, length = 12, decimales = 2, format = "")
	private String wksN012EcLcDisp;

	/** The wks N 012 ec sigchcm. */
	@EntityModel(index = 23, value = "", name = "wksN012EcSigchcm", fieldType = DataType.VARCHAR, length = 16, decimales = 0, format = "")
	private String wksN012EcSigchcm;

	/** The wks N 012 ec nummovs. */
	@EntityModel(index = 24, value = "", name = "wksN012EcNummovs", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcNummovs;
	// @EntityModel(index = 25, numOccurs = 5, length = 0 , name = "groupOccurs"
	/** The list occurs. */
	// , fieldType = DataType.GROUP)
	private List<GroupOccurs> listOccurs;

	/**
	 * Sets the filler 3.
	 *
	 * @param parameter
	 *            the new filler 3
	 */
	public void setFiller3(String parameter) {
		filler3 = parameter;
	}

	/**
	 * Gets the filler 3.
	 *
	 * @return filler3
	 */
	public String getFiller3() {
		return filler3;
	}

	/**
	 * Sets the wks N 012 ec result.
	 *
	 * @param parameter
	 *            the new wks N 012 ec result
	 */
	public void setWksN012EcResult(int parameter) {
		wksN012EcResult = parameter;
	}

	/**
	 * Gets the wks N 012 ec result.
	 *
	 * @return wksN012EcResult
	 */
	public int getWksN012EcResult() {
		return wksN012EcResult;
	}

	/**
	 * Sets the wks N 012 ec prod.
	 *
	 * @param parameter
	 *            the new wks N 012 ec prod
	 */
	public void setWksN012EcProd(int parameter) {
		wksN012EcProd = parameter;
	}

	/**
	 * Gets the wks N 012 ec prod.
	 *
	 * @return wksN012EcProd
	 */
	public int getWksN012EcProd() {
		return wksN012EcProd;
	}

	/**
	 * Sets the wks N 012 ec inst.
	 *
	 * @param parameter
	 *            the new wks N 012 ec inst
	 */
	public void setWksN012EcInst(int parameter) {
		wksN012EcInst = parameter;
	}

	/**
	 * Gets the wks N 012 ec inst.
	 *
	 * @return wksN012EcInst
	 */
	public int getWksN012EcInst() {
		return wksN012EcInst;
	}

	/**
	 * Sets the wks N 012 tra dt suc.
	 *
	 * @param parameter
	 *            the new wks N 012 tra dt suc
	 */
	public void setWksN012TraDtSuc(String parameter) {
		wksN012TraDtSuc = parameter;
	}

	/**
	 * Gets the wks N 012 tra dt suc.
	 *
	 * @return wksN012TraDtSuc
	 */
	public String getWksN012TraDtSuc() {
		return wksN012TraDtSuc;
	}

	/**
	 * Sets the wks N 012 tra dt cta.
	 *
	 * @param parameter
	 *            the new wks N 012 tra dt cta
	 */
	public void setWksN012TraDtCta(BigInteger parameter) {
		wksN012TraDtCta = parameter;
	}

	/**
	 * Gets the wks N 012 tra dt cta.
	 *
	 * @return wksN012TraDtCta
	 */
	public BigInteger getWksN012TraDtCta() {
		return wksN012TraDtCta;
	}

	/**
	 * Sets the wks nctl numcte.
	 *
	 * @param parameter
	 *            the new wks nctl numcte
	 */
	public void setWksNctlNumcte(BigInteger parameter) {
		wksNctlNumcte = parameter;
	}

	/**
	 * Gets the wks nctl numcte.
	 *
	 * @return wksNctlNumcte
	 */
	public BigInteger getWksNctlNumcte() {
		return wksNctlNumcte;
	}

	/**
	 * Sets the wks N 012 ec nomcte.
	 *
	 * @param parameter
	 *            the new wks N 012 ec nomcte
	 */
	public void setWksN012EcNomcte(String parameter) {
		wksN012EcNomcte = parameter;
	}

	/**
	 * Gets the wks N 012 ec nomcte.
	 *
	 * @return wksN012EcNomcte
	 */
	public String getWksN012EcNomcte() {
		return wksN012EcNomcte;
	}

	/**
	 * Sets the wks N 012 ec fecha corte.
	 *
	 * @param parameter
	 *            the new wks N 012 ec fecha corte
	 */
	public void setWksN012EcFechaCorte(int parameter) {
		wksN012EcFechaCorte = parameter;
	}

	/**
	 * Gets the wks N 012 ec fecha corte.
	 *
	 * @return wksN012EcFechaCorte
	 */
	public int getWksN012EcFechaCorte() {
		return wksN012EcFechaCorte;
	}

	/**
	 * Sets the wks N 012 ec fecha ultmov.
	 *
	 * @param parameter
	 *            the new wks N 012 ec fecha ultmov
	 */
	public void setWksN012EcFechaUltmov(int parameter) {
		wksN012EcFechaUltmov = parameter;
	}

	/**
	 * Gets the wks N 012 ec fecha ultmov.
	 *
	 * @return wksN012EcFechaUltmov
	 */
	public int getWksN012EcFechaUltmov() {
		return wksN012EcFechaUltmov;
	}

	/**
	 * Sets the wks N 012 ec fecha ini.
	 *
	 * @param parameter
	 *            the new wks N 012 ec fecha ini
	 */
	public void setWksN012EcFechaIni(int parameter) {
		wksN012EcFechaIni = parameter;
	}

	/**
	 * Gets the wks N 012 ec fecha ini.
	 *
	 * @return wksN012EcFechaIni
	 */
	public int getWksN012EcFechaIni() {
		return wksN012EcFechaIni;
	}

	/**
	 * Sets the wks N 012 ec fecha fin.
	 *
	 * @param parameter
	 *            the new wks N 012 ec fecha fin
	 */
	public void setWksN012EcFechaFin(int parameter) {
		wksN012EcFechaFin = parameter;
	}

	/**
	 * Gets the wks N 012 ec fecha fin.
	 *
	 * @return wksN012EcFechaFin
	 */
	public int getWksN012EcFechaFin() {
		return wksN012EcFechaFin;
	}

	/**
	 * Sets the wks N 012 ec sdo inicial.
	 *
	 * @param parameter
	 *            the new wks N 012 ec sdo inicial
	 */
	public void setWksN012EcSdoInicial(String parameter) {
		wksN012EcSdoInicial = parameter;
	}

	/**
	 * Gets the wks N 012 ec sdo inicial.
	 *
	 * @return wksN012EcSdoInicial
	 */
	public String getWksN012EcSdoInicial() {
		return wksN012EcSdoInicial;
	}

	/**
	 * Sets the wks N 012 ec sdo inisigno.
	 *
	 * @param parameter
	 *            the new wks N 012 ec sdo inisigno
	 */
	public void setWksN012EcSdoInisigno(String parameter) {
		wksN012EcSdoInisigno = parameter;
	}

	/**
	 * Gets the wks N 012 ec sdo inisigno.
	 *
	 * @return wksN012EcSdoInisigno
	 */
	public String getWksN012EcSdoInisigno() {
		return wksN012EcSdoInisigno;
	}

	/**
	 * Sets the wks N 012 ec abo num.
	 *
	 * @param parameter
	 *            the new wks N 012 ec abo num
	 */
	public void setWksN012EcAboNum(int parameter) {
		wksN012EcAboNum = parameter;
	}

	/**
	 * Gets the wks N 012 ec abo num.
	 *
	 * @return wksN012EcAboNum
	 */
	public int getWksN012EcAboNum() {
		return wksN012EcAboNum;
	}

	/**
	 * Sets the wks N 012 ec abo importe.
	 *
	 * @param parameter
	 *            the new wks N 012 ec abo importe
	 */
	public void setWksN012EcAboImporte(String parameter) {
		wksN012EcAboImporte = parameter;
	}

	/**
	 * Gets the wks N 012 ec abo importe.
	 *
	 * @return wksN012EcAboImporte
	 */
	public String getWksN012EcAboImporte() {
		return wksN012EcAboImporte;
	}

	/**
	 * Sets the wks N 012 ec car num.
	 *
	 * @param parameter
	 *            the new wks N 012 ec car num
	 */
	public void setWksN012EcCarNum(int parameter) {
		wksN012EcCarNum = parameter;
	}

	/**
	 * Gets the wks N 012 ec car num.
	 *
	 * @return wksN012EcCarNum
	 */
	public int getWksN012EcCarNum() {
		return wksN012EcCarNum;
	}

	/**
	 * Sets the wks N 012 ec car importe.
	 *
	 * @param parameter
	 *            the new wks N 012 ec car importe
	 */
	public void setWksN012EcCarImporte(String parameter) {
		wksN012EcCarImporte = parameter;
	}

	/**
	 * Gets the wks N 012 ec car importe.
	 *
	 * @return wksN012EcCarImporte
	 */
	public String getWksN012EcCarImporte() {
		return wksN012EcCarImporte;
	}

	/**
	 * Sets the wks N 012 ec sdo actual.
	 *
	 * @param parameter
	 *            the new wks N 012 ec sdo actual
	 */
	public void setWksN012EcSdoActual(String parameter) {
		wksN012EcSdoActual = parameter;
	}

	/**
	 * Gets the wks N 012 ec sdo actual.
	 *
	 * @return wksN012EcSdoActual
	 */
	public String getWksN012EcSdoActual() {
		return wksN012EcSdoActual;
	}

	/**
	 * Sets the wks N 012 ec sdo actsigno.
	 *
	 * @param parameter
	 *            the new wks N 012 ec sdo actsigno
	 */
	public void setWksN012EcSdoActsigno(String parameter) {
		wksN012EcSdoActsigno = parameter;
	}

	/**
	 * Gets the wks N 012 ec sdo actsigno.
	 *
	 * @return wksN012EcSdoActsigno
	 */
	public String getWksN012EcSdoActsigno() {
		return wksN012EcSdoActsigno;
	}

	/**
	 * Sets the wks N 012 ec lc importe.
	 *
	 * @param parameter
	 *            the new wks N 012 ec lc importe
	 */
	public void setWksN012EcLcImporte(String parameter) {
		wksN012EcLcImporte = parameter;
	}

	/**
	 * Gets the wks N 012 ec lc importe.
	 *
	 * @return wksN012EcLcImporte
	 */
	public String getWksN012EcLcImporte() {
		return wksN012EcLcImporte;
	}

	/**
	 * Sets the wks N 012 ec lc sdo.
	 *
	 * @param parameter
	 *            the new wks N 012 ec lc sdo
	 */
	public void setWksN012EcLcSdo(String parameter) {
		wksN012EcLcSdo = parameter;
	}

	/**
	 * Gets the wks N 012 ec lc sdo.
	 *
	 * @return wksN012EcLcSdo
	 */
	public String getWksN012EcLcSdo() {
		return wksN012EcLcSdo;
	}

	/**
	 * Sets the wks N 012 ec lc disp.
	 *
	 * @param parameter
	 *            the new wks N 012 ec lc disp
	 */
	public void setWksN012EcLcDisp(String parameter) {
		wksN012EcLcDisp = parameter;
	}

	/**
	 * Gets the wks N 012 ec lc disp.
	 *
	 * @return wksN012EcLcDisp
	 */
	public String getWksN012EcLcDisp() {
		return wksN012EcLcDisp;
	}

	/**
	 * Sets the wks N 012 ec sigchcm.
	 *
	 * @param parameter
	 *            the new wks N 012 ec sigchcm
	 */
	public void setWksN012EcSigchcm(String parameter) {
		wksN012EcSigchcm = parameter;
	}

	/**
	 * Gets the wks N 012 ec sigchcm.
	 *
	 * @return wksN012EcSigchcm
	 */
	public String getWksN012EcSigchcm() {
		return wksN012EcSigchcm;
	}

	/**
	 * Sets the wks N 012 ec nummovs.
	 *
	 * @param parameter
	 *            the new wks N 012 ec nummovs
	 */
	public void setWksN012EcNummovs(int parameter) {
		wksN012EcNummovs = parameter;
	}

	/**
	 * Gets the wks N 012 ec nummovs.
	 *
	 * @return wksN012EcNummovs
	 */
	public int getWksN012EcNummovs() {
		return wksN012EcNummovs;
	}

	/**
	 * Gets the list occurs.
	 *
	 * @return the list occurs
	 */
	public List<GroupOccurs> getListOccurs() {
		return listOccurs;
	}

	/**
	 * Sets the list occurs.
	 *
	 * @param listOccurs
	 *            the new list occurs
	 */
	public void setListOccurs(List<GroupOccurs> listOccurs) {
		this.listOccurs = listOccurs;
	}

	// @EntityModel(index = 25, numOccurs = 5, length = 0 , name = "groupOccurs"
	// , fieldType = DataType.GROUP)

} // ConedoctamaemovdescorOutputOk
