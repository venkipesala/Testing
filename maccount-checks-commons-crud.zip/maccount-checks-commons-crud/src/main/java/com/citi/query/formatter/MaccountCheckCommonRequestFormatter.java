/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckCommonRequestFormatter.java
 * Original Author: Softtek
 * Creation Date: 10/02/2017
 * ---------------------------------------------------------------------------
 */

package com.citi.query.formatter;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.banamex.nga.gemfire.cache.stationame.beans.StationName;
import com.banamex.nga.gemfire.cache.stationame.bo.StationNameContextBo;
import com.citi.query.aggregator.CacheAggregator;
import com.citi.query.contract.MaccountCheckCommonContractRequest;
import com.citi.query.formatter.sa2request.Sa2RequestFormatter;
import com.citi.query.formatter.sa2request.impl.ChecksAfterBalanceMovementsSa2Formatter;
import com.citi.query.formatter.sa2request.impl.ChecksAfterBalanceSa2Formatter;
import com.citi.query.formatter.sa2request.impl.ChecksBeforeBalanceMovementsSa2Formatter;
import com.citi.query.formatter.sa2request.impl.ChecksBeforeBalanceSa2Formatter;
import com.citi.query.formatter.sa2request.impl.MaccountAfterBalanceMovementsSa2Formatter;
import com.citi.query.formatter.sa2request.impl.MaccountAfterBalanceSa2Formatter;
import com.citi.query.formatter.sa2request.impl.MaccountBeforeBalanceMovementsSa2Formatter;
import com.citi.query.formatter.sa2request.impl.MaccountBeforeBalanceSa2Formatter;
import com.citi.query.model.MaccountChecksCommonInput;
import com.citi.query.request.MaccountCheckCommonRequest;
import com.citi.unisys.model.HeaderBnmx;
import com.citi.unisys.model.HeaderSa2;

/**
 * The Class MaccountCheckNextCommonInputFormatter.
 *
 * @author el14811
 * @version 1.0
 */
@Component
public class MaccountCheckCommonRequestFormatter {

	/** station name context bo. */
	@Autowired
	StationNameContextBo stationNameContextBo;

	/** station name. */
	StationName stationName;

	@Autowired
	CacheAggregator serviceCache;

	/** log. */
	private static Logger log = Logger.getLogger(MaccountCheckCommonRequestFormatter.class);

	/**
	 * Format input data model.
	 *
	 * @param request
	 *            the request
	 * @param subcodigo
	 *            the subcodigo
	 * @return the maccount checks common input
	 */
	public MaccountChecksCommonInput formatInputDataModel(MaccountCheckCommonRequest request, int subcodigo) {
		Sa2RequestFormatter sa2RequestFormatter = this.getFormatterSa2(subcodigo);
		return sa2RequestFormatter.formatToInputModel(request);

	}

	/**
	 * Format.
	 *
	 * @param request
	 *            the request
	 * @param subcodigo
	 *            the subcodigo
	 * @return the maccount check next common contract request
	 */
	public MaccountCheckCommonContractRequest format(MaccountCheckCommonRequest request, int subcodigo) {

		MaccountCheckCommonContractRequest contract = new MaccountCheckCommonContractRequest();

		contract.setHeaderBanamex(this.formatHeaderBnmx(request, subcodigo));
		contract.setHeaderSa2(this.formatHeaderSa2(request, subcodigo));
		contract.setInputModel(this.formatInputDataModel(request, subcodigo));

		return contract;
	}

	/**
	 * Format header bnmx.
	 *
	 * @param request
	 *            the request
	 * @param subcodigo
	 *            the subcodigo
	 * @return the header bnmx
	 */
	public HeaderBnmx formatHeaderBnmx(MaccountCheckCommonRequest request, int subcodigo) {
		try{
			Sa2RequestFormatter sa2RequestFormatter = this.getFormatterSa2(subcodigo);
			stationName = serviceCache.getStationNameStructure(request.getCsi(), request.getChannelId());
			request.setBranchNumber(Integer.parseInt(stationName.getStationName().substring(1, 5)));
			request.setCashCode(Integer.parseInt(stationName.getStationName().substring(6)));
			//return sa2RequestFormatter.formatHeaderBnmx(request, stationName);
			return sa2RequestFormatter.formatHeaderBnmx(request, stationName);
		}finally{			
			log.info("Releasing StationName: " + stationName.getStationName());
			serviceCache.freeStationName(stationName);
		}
	}

	/**
	 * Format header sa 2.
	 *
	 * @param request
	 *            request
	 * @param subcodigo
	 *            the subcodigo
	 * @return header sa 2
	 */
	public HeaderSa2 formatHeaderSa2(MaccountCheckCommonRequest request, int subcodigo) {
		return this.getFormatterSa2(subcodigo).formatHeaderSa2(request);

	}

	/**
	 * Gets the formatter sa 2.
	 *
	 * @param subcodigo
	 *            the subcodigo
	 * @return the formatter sa 2
	 */
	public Sa2RequestFormatter getFormatterSa2(int subcodigo) {
		switch (subcodigo) {
		case 781:
			return new MaccountBeforeBalanceSa2Formatter();
		case 780:
			return new ChecksBeforeBalanceSa2Formatter();
		case 791:
			return new MaccountAfterBalanceSa2Formatter();
		case 790:
			return new ChecksAfterBalanceSa2Formatter();
		case 801:
			return new MaccountBeforeBalanceMovementsSa2Formatter();
		case 800:
			return new ChecksBeforeBalanceMovementsSa2Formatter();
		case 811:
			return new MaccountAfterBalanceMovementsSa2Formatter();
		case 810:
			return new ChecksAfterBalanceMovementsSa2Formatter();
		default:
			return null;
		}

	}

	/**
	 * Gets the station name.
	 *
	 * @return station name
	 */
	public String getStationName() {

		stationName = stationNameContextBo.getStationNameEnable("Y", "A");
		log.info(stationName.getStationName());
		return stationName.getStationName();
	}

}
