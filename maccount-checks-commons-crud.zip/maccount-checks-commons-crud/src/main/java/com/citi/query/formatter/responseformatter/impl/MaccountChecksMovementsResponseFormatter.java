/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksMovementsResponseFormatter.java
 * Original Author: Softtek
 * Creation Date: 10/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.formatter.responseformatter.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.citi.query.formatter.MaccountCheckMovementsOcurrsFormatter;
import com.citi.query.formatter.responseformatter.CommonResponseFormatter;
import com.citi.query.model.GroupOccurs;
import com.citi.query.model.MaccounChecksMovementsOutputOk;
import com.citi.query.response.InnerOcurrs;
import com.citi.query.response.MaccountCheckMovementsResponse;

/**
 * The Class MaccountChecksMovementsResponseFormatter.
 */
public class MaccountChecksMovementsResponseFormatter implements CommonResponseFormatter {

	/* (non-Javadoc)
	 * @see com.citi.query.formatter.responseformatter.CommonResponseFormatter#formatToResponse(java.lang.Object)
	 */
	@Override
	public MaccountCheckMovementsResponse formatToResponse(Object maccountChecksCommonOutputOk) {
		MaccountCheckMovementsResponse maccountCheckMovementsResponse = new MaccountCheckMovementsResponse();
		MaccountCheckMovementsOcurrsFormatter occursFormatter = new MaccountCheckMovementsOcurrsFormatter();
		
		MaccounChecksMovementsOutputOk movementsOutput = (MaccounChecksMovementsOutputOk)maccountChecksCommonOutputOk;
		List<GroupOccurs> listGroupOccurs = movementsOutput.getOutputDetail();
		List<InnerOcurrs> listInnerOccurs = new ArrayList<>();
		maccountCheckMovementsResponse.setAccountNumber(movementsOutput.getWksN012TraDtCta());
		maccountCheckMovementsResponse.setBranchID(movementsOutput.getWksN012TraDtSuc());
		maccountCheckMovementsResponse.setInstrumentID(movementsOutput.getWksN012EcInst());
		maccountCheckMovementsResponse.setNextMovement(movementsOutput.getWksN012EcSigchcm());
		maccountCheckMovementsResponse.setProductID(movementsOutput.getWksN012EcProd());
		maccountCheckMovementsResponse.setQuantityNumber(movementsOutput.getWksN012EcNummovs());
		maccountCheckMovementsResponse.setResultZeros(movementsOutput.getWksN012EcResult());
		maccountCheckMovementsResponse.setSuffix(movementsOutput.getFiller3());
		for(GroupOccurs groupOccurrs: listGroupOccurs){
			InnerOcurrs inner = occursFormatter.formatToResponse(groupOccurrs);
			listInnerOccurs.add(inner);
		}
		maccountCheckMovementsResponse.setGpogroupOccurs(listInnerOccurs);
		
		return maccountCheckMovementsResponse;

	}
	
	private Double getMount(String strToMatch) {
		Double numImporte = 0d;
		if (strToMatch.trim().length() > 0) {
//			strToMatch = strToMatch.substring(0, strToMatch.length() - 2) + "."
//					+ strToMatch.substring(strToMatch.length() - 2);
			Pattern p = Pattern.compile("^\\s*[0-9]{1,6}.[0-9]{1,2}$");
			Matcher m = p.matcher(strToMatch);
			
			if (m.matches()) {
				numImporte = new Double(strToMatch);
			} 
		}
		return numImporte;
	}
	

}
