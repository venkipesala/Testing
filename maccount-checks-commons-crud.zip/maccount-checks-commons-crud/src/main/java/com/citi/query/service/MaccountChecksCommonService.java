/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksCommonService.java
 * Original Author: Softtek
 * Creation Date: 1/03/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.query.aggregator.MaccountChecksCommonRequestAggregator;
import com.citi.query.aggregator.MaccountChecksCommonResponseAggregator;
import com.citi.query.contract.MaccountCheckCommonContractRequest;
import com.citi.query.contract.MaccountChecksCommonsResponseContract;
import com.citi.query.exception.JracRequestAggregatorException;
import com.citi.query.exception.MaccountChecksCommonException;
import com.citi.query.formatter.MaccountCheckCommonRequestFormatter;
import com.citi.query.formatter.responseformatter.CommonResponseFormatter;
import com.citi.query.request.MaccountCheckCommonRequest;
import com.citi.query.validator.MaccountCheckCommonValidatorRequest;
import com.citi.unisys.utils.UnisysResultException;
import com.softtek.legacy.framework.model.DataElementFormatException;
import com.softtek.legacy.framework.parser.ParserException;

/**
 * The Class MaccountChecksCommonService.
 */
@Service
public class MaccountChecksCommonService {
	/** request formatter. */
	@Autowired
	MaccountCheckCommonRequestFormatter requestFormatter;

	/** response formatter. */
	// @Autowired
	CommonResponseFormatter responseFormatter;

	/** The request aggregator. */
	@Autowired
	MaccountChecksCommonRequestAggregator requestAggregator;

	/** response aggregator. */
	@Autowired
	MaccountChecksCommonResponseAggregator responseAggregator;

	/** The validator request. */
	@Autowired
	MaccountCheckCommonValidatorRequest validatorRequest;

	/**
	 * Query.
	 * <p>
	 * Execute the Multiple Government Payment query based on the request data.
	 * </p>
	 *
	 * @param request
	 *            request
	 * @return multiple government query response
	 * @throws DataElementFormatException
	 *             data element format exception.
	 * @throws ParserException
	 *             parser exception.
	 * @throws JracRequestAggregatorException
	 *             the jrac request aggregator exception
	 * @throws UnisysResultException
	 *             the unisys result exception
	 * @throws MaccountChecksCommonException
	 *             the maccount checks common exception
	 */
	public MaccountChecksCommonsResponseContract query(MaccountCheckCommonRequest request) throws DataElementFormatException, ParserException,
			JracRequestAggregatorException, UnisysResultException, MaccountChecksCommonException {

		validatorRequest.validate(request);

		/*
		 * This instruction builds the request contract that is composed of
		 * Header, Header Extended, Header Sa2 and Data request.
		 */
		MaccountCheckCommonContractRequest contractRequest = requestFormatter.format(request, request.getSubcode());

		/*
		 * This instruction creates an instance of an Aggregator that will be
		 * responsible of execute the Unisys query.
		 */
		requestAggregator.setContract(contractRequest);

		/*
		 * This instruction gets the response contract through the request
		 * aggregator.
		 */
		 MaccountChecksCommonsResponseContract contractResponse = responseAggregator
				.getContractResponse(requestAggregator.executeQuery(), request.getOptionNumber());
		 return contractResponse;
//		switch (request.getOptionNumber()) {
//		case 41:
//
//			return new MaccountChecksAfterBalanceResponseFormatter()
//					.formatToResponse(contractResponse.getMaccountChecksCommonsResponse());
//
//		case 42:
//			return new MaccountChecksBeforeBalanceResponseFormatter()
//					.formatToResponse(contractResponse.getMaccountChecksCommonsResponse());
//
//		case 43:
//			return new MaccountChecksMovementsResponseFormatter()
//					.formatToResponse(contractResponse.getMaccountChecksCommonsResponse());
//		default:
//			return null;
//		}

	}

}
