/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: ConMovCtaMaeContError.java
 * Original Author: ENLM
 * Creation Date: 31/01/2017
 * ---------------------------------------------------------------------------
 */

package com.citi.query.model;
import com.softtek.legacy.framework.model.DataElement.DataType;
import com.softtek.legacy.framework.model.EntityModel;


/**
 *  <code>ConMovCtaMaeContError</code>.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountChecksCommonError {
	
	/** filler 4. */
	@EntityModel(index = 0, value = "", name = "filler4", fieldType = DataType.VARCHAR, length = 6, decimales = 0, format = "")
	private String filler4;
	
	/** wks N 012 ec result. */
	@EntityModel(index = 1, value = "", name = "wksN012EcResult", fieldType = DataType.INTEGER, length = 2, decimales = 0, format = "")
	private int wksN012EcResult;

	/**
	 * Set the filler 4.
	 *
	 * @param parameter  filler 4
	 */
	public void setFiller4( String parameter ) {
		filler4 = parameter;
	}

	/**
	 * Gets the filler 4.
	 *
	 * @return filler4
	 */
	public String getFiller4() {
		return filler4;
	}

	/**
	 * Set the wks N 012 ec result.
	 *
	 * @param parameter  wks N 012 ec result
	 */
	public void setWksN012EcResult( int parameter ) {
		wksN012EcResult = parameter;
	}

	/**
	 * Gets the wks N 012 ec result.
	 *
	 * @return wksN012EcResult
	 */
	public int getWksN012EcResult() {
		return wksN012EcResult;
	}

} // ConmovctamaecontError
