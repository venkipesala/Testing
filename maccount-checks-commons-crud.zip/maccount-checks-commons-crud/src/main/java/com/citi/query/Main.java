package com.citi.query;

import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * <code>Main</code>.
 *
 * @author luise.diaz
 * @version 1.0
 */
@SpringBootApplication
@Configuration
@EnableDiscoveryClient
@EnableAutoConfiguration
@ComponentScan
@ComponentScan({"com.banamex.nga"})
@EnableSwagger2
@EnableCircuitBreaker
public class Main {

    /**
     * News api.
     *
     * @return docket
     */
    @Bean
    public Docket newsApi() {

        return new Docket(DocumentationType.SWAGGER_2).groupName("query")
            .apiInfo(apiInfo()).select().paths(regex("/Accounts/V1/*.*")).build();
    }
    

    /**
     * Api info.
     *
     * @return api info
     */
    private ApiInfo apiInfo() {

        return new ApiInfoBuilder().title("Master Account and Checks")
            .description("Master Account and Checks query")
            .termsOfServiceUrl("").contact("softtek.com").license("")
            .licenseUrl("").version("1.0").build();
    }

    /**
     * Execution initiation.
     *
     * @param args
     *            arguments
     */
    public static void main(String[] args) {

        SpringApplication.run(Main.class, args);
    }
}
