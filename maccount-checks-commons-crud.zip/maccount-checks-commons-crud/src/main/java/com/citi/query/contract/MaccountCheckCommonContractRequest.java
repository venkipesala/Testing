/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckCommonContractRequest.java
 * Original Author: ENLM
 * Creation Date: 1/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.contract;

import com.citi.query.model.MaccountChecksCommonInput;
import com.citi.unisys.model.HeaderBnmx;
import com.citi.unisys.model.HeaderSa2;

/**
 * The Class MaccountCheckNextCommonContractRequest.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckCommonContractRequest {

	/** The header banamex. */
	private HeaderBnmx headerBanamex;
	
	/** The header sa 2. */
	private HeaderSa2 headerSa2;
	
	/** The input model. */
	private MaccountChecksCommonInput inputModel;

	/**
	 * Gets the header banamex.
	 *
	 * @return the header banamex
	 */
	public HeaderBnmx getHeaderBanamex() {
		return headerBanamex;
	}

	/**
	 * Sets the header banamex.
	 *
	 * @param headerBanamex the new header banamex
	 */
	public void setHeaderBanamex(HeaderBnmx headerBanamex) {
		this.headerBanamex = headerBanamex;
	}

	/**
	 * Gets the header sa 2.
	 *
	 * @return the header sa 2
	 */
	public HeaderSa2 getHeaderSa2() {
		return headerSa2;
	}

	/**
	 * Sets the header sa 2.
	 *
	 * @param headerSa2 the new header sa 2
	 */
	public void setHeaderSa2(HeaderSa2 headerSa2) {
		this.headerSa2 = headerSa2;
	}

	/**
	 * Gets the input model.
	 *
	 * @return the input model
	 */
	public MaccountChecksCommonInput getInputModel() {
		return inputModel;
	}

	/**
	 * Sets the input model.
	 *
	 * @param inputModel the new input model
	 */
	public void setInputModel(MaccountChecksCommonInput inputModel) {
		this.inputModel = inputModel;
	}

}
