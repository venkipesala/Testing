package com.citi.query.aggregator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.banamex.nga.ebanking.jrac.transporter.Connection;
import com.citi.query.contract.MaccountCheckCommonContractRequest;
import com.citi.query.exception.JracRequestAggregatorException;
import com.softtek.legacy.framework.model.DataElementFormatException;
import com.softtek.legacy.framework.parser.ParserException;
import com.softtek.legacy.framework.util.BufferBuilder;

@Component
public class MaccountChecksCommonRequestAggregator {

	@Autowired
	Connection connection;

	/** contract. */
	private MaccountCheckCommonContractRequest contract;

	/** log. */
	private static Logger log = Logger.getLogger(MaccountChecksCommonRequestAggregator.class);

	/**
	 * CONSTRUCTOR
	 * 
	 * @param contractParameter
	 */
	public MaccountChecksCommonRequestAggregator(MaccountCheckCommonContractRequest contractParameter) {
		this.contract = contractParameter;
	}

	public MaccountChecksCommonRequestAggregator() {
		/**
		 * to use with autowired
		 */
	}

	/**
	 * @return the contract
	 */
	public MaccountCheckCommonContractRequest getContract() {

		return contract;
	}

	/**
	 * @param contract
	 *            the contract to set
	 */
	public void setContract(MaccountCheckCommonContractRequest contract) {

		this.contract = contract;
	}

	/**
	 * Execute unisys query
	 * 
	 * @return
	 * @throws JracRequestAggregatorException
	 */
	public String executeQuery() throws JracRequestAggregatorException {

		String responseBuffer;

		try {
			String requestBuffer = "H10000" + this.createInputBuffer();
			responseBuffer = connection.requestUnisys(requestBuffer, "");
			if (responseBuffer.contains("Failure"))
                throw new JracRequestAggregatorException(
                    "JRAC_UNISYS EXCEPTION RECEIVED");
			
			if(responseBuffer.contains("timed out"))
                throw new JracRequestAggregatorException(
                    "Jrac unisys exception received: IOException reading data from COMS: Read timed out");
	

			
			log.info("BUFFER RESPONSE: [" + responseBuffer + "]");
			return responseBuffer.substring(6);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new JracRequestAggregatorException(e.getMessage());
		}
	}

	/**
	 * Creates the input buffer.
	 *
	 * @return string
	 * @throws DataElementFormatException
	 *             data element format exception.
	 * @throws ParserException
	 *             parser exception.
	 */
	protected String createInputBuffer() throws DataElementFormatException, ParserException {

		StringBuilder requestBuffer = new StringBuilder();
		requestBuffer.append(this.createBufferFromEntity(contract.getHeaderBanamex()));
		requestBuffer.append(this.createBufferFromEntity(contract.getHeaderSa2()));
		requestBuffer.append(this.createBufferFromEntity(contract.getInputModel()));

		log.info("BUFFER REQUEST: [" + requestBuffer.toString() + "]");

		return requestBuffer.toString();
	}

	/**
	 * Creates the buffer from entity.
	 *
	 * @param entity
	 *            entity
	 * @return string
	 * @throws DataElementFormatException
	 *             data element format exception.
	 * @throws ParserException
	 *             parser exception.
	 */
	private String createBufferFromEntity(Object entity) throws DataElementFormatException, ParserException {

		BufferBuilder bufferBuilder = new BufferBuilder(entity);
		bufferBuilder.build();

		return bufferBuilder.getBuffer().toString();
	}

}
