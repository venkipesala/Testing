/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CacheAggregator.java
 * Original Author: Softtek
 * Creation Date: 15/012/2016
 * ---------------------------------------------------------------------------
 */
package com.citi.query.aggregator;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.banamex.nga.ebanking.common.utils.Utils;
import com.banamex.nga.gemfire.cache.customer.beans.Customer;
import com.banamex.nga.gemfire.cache.customer.bo.CustomerContextBo;
import com.banamex.nga.gemfire.cache.stationame.beans.StationName;
import com.banamex.nga.gemfire.cache.stationame.bo.StationNameContextBo;
import com.banamex.nga.gemfire.cache.txreference.beans.TxReference;
import com.banamex.nga.gemfire.cache.txreference.bo.TxReferenceBo;

/**
 * <code>CacheAggregator</code>.
 *
 * @author sg05070
 * @version 1.0
 */
@Component
public class CacheAggregator {

    /** customer context bo. */
    @Autowired
    CustomerContextBo customerContextBo;

    /** tx reference bo. */
    @Autowired
    TxReferenceBo txReferenceBo;

    /** station name context bo. */
    @Autowired
    StationNameContextBo stationNameContextBo;

    /** utils. */
    private Utils utils = new Utils();

    /** The constant log. */
    private static final Logger log = Logger.getLogger(CacheAggregator.class);

    /**
     * Gets the service id.
     *
     * @param customerId
     *            customer id
     * @return service id
     */
    public Long getServiceId(String customerId) {

        Long serviceId = 0L;
        Customer customer =
            customerContextBo.getCustomer(utils.padLeftZeros(customerId, 12));

        if (customer != null) {

            serviceId = Long.parseLong(customer.getCustomerServiceType());
            
            log.info("ServiceId [" + serviceId + "] CSI ["
                + customer.getCustomerCsi() + " - "
                + customer.getCustomerName());
            log.info("Exec number: " + customer.getExecutiveNumber());
            log.info("Primary executive: " + customer.getPrimaryExecutiveNumber());

        }

        return serviceId;
    }

    /**
     * Gets the customer.
     *
     * @param customerId
     *            customer id
     * @return customer
     */
    public Customer getCustomer(String customerId) {

        Customer customer =
            customerContextBo.getCustomer(utils.padLeftZeros(customerId, 12));

        return customer;
    }

    /**
     * Gets the executive number.
     *
     * @param customerId
     *            customer id
     * @return executive number
     */
    public String getExecutiveNumber(String customerId) {

        String executiveNumber =
            this.getCustomer(customerId).getExecutiveNumber();
        executiveNumber = (executiveNumber == null) ? "0" : executiveNumber;

        return executiveNumber;
    }

    /**
     * Gets the reference number.
     *
     * @return reference number
     */
    public String getReferenceNumber() {

        TxReference numberTx = txReferenceBo.getTxReference(new Date());
        log.info(numberTx.getReferenceNum());

        return numberTx.getReferenceNum();
    }

    /**
     * Gets the station name structure.
     *
     * @return station name structure
     */
    public StationName getStationNameStructure(long csi, long channelId) {

        StationName stationName = stationNameContextBo.getStationNameAvailable(
            utils.padLeftZeros(String.valueOf(csi), 2),
            utils.padLeftZeros(String.valueOf(channelId), 2));
        
        log.info(stationName.getStationName());
        return stationName;
    }

    /**
     * Free station name.
     *
     * @param stationName
     *            station name
     */
    public void freeStationName(StationName stationName) {

        stationNameContextBo.setStationNameEnable(stationName);
    }
}
