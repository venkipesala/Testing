/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksCommonController.java
 * Original Author: Softtek
 * Creation Date: 1/03/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.controller;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.citi.query.contract.MaccountChecksCommonsResponseContract;
import com.citi.query.exception.JracRequestAggregatorException;
import com.citi.query.exception.MaccountChecksCommonException;
import com.citi.query.request.MaccountCheckCommonRequest;
import com.citi.query.service.MaccountChecksCommonService;
import com.citi.unisys.utils.UnisysResultException;
import com.softtek.legacy.framework.model.DataElementFormatException;
import com.softtek.legacy.framework.parser.ParserException;

import io.swagger.annotations.ApiOperation;

/**
 * The Class MaccountChecksCommonController.
 */
@RestController
public class MaccountChecksCommonController {

	    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		/** service. */
	    @Autowired
	    MaccountChecksCommonService service;

	    /** The constant log. */
	    private static final Logger log =
	        Logger.getLogger(MaccountChecksCommonController.class);


	    /**
    	 * Execute maccount checks.
    	 *
    	 * @param request the request
    	 * @return the response entity
    	 */
    	@ApiOperation(value = "010610 - Master Account and Checks",
	        response = Object.class)
	    @RequestMapping(value = "/Accounts/V1/MaccountChecks",
	        method = RequestMethod.POST)
	    public ResponseEntity<Object> executeMaccountChecks(
	        @RequestBody MaccountCheckCommonRequest request)  {

    		MaccountChecksCommonsResponseContract response = null;
	        try {
	            response = service.query(request);
	        } catch (MaccountChecksCommonException e) {
	            log.error(e);
	            return new ResponseEntity<>(e.getMessage(),   HttpStatus.BAD_REQUEST);
	        } catch (DataElementFormatException e) {
	            log.error(e);
	            return new ResponseEntity<>(e.getMessage(),   HttpStatus.BAD_REQUEST);
			} catch (ParserException e) {
	            log.error(e);
	            return new ResponseEntity<>(e.getMessage(),   HttpStatus.BAD_REQUEST);
			} catch (JracRequestAggregatorException e) {
	            log.error(e);
	            return new ResponseEntity<>(e.getMessage(),   HttpStatus.BAD_REQUEST);
			} catch (UnisysResultException e) {
	            log.error(e);
	            return new ResponseEntity<>(e.getMessage(),   HttpStatus.BAD_REQUEST);
			}
	        return new ResponseEntity<>(response, HttpStatus.OK);
	    }
	
		    		

	
}
