/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksCommonException.java
 * Original Author: Softtek
 * Creation Date: 2/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.exception;

import com.citi.query.model.MaccountChecksCommonError;

/**
 * The Class MaccountChecksCommonException.
 */
public class MaccountChecksCommonException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	/** The query sua payment status error. */
	private transient MaccountChecksCommonError maccountChecksCommonError;

	/** The error code. */
	private int errorCode;

	/**
	 * Instantiates a new query sua payment status exception.
	 *
	 * @param maccountChecksCommonError
	 *            the maccount checks common error
	 */
	public MaccountChecksCommonException(MaccountChecksCommonError maccountChecksCommonError) {
		this.setMaccountChecksCommonError(maccountChecksCommonError);

	}

	/**
	 * Instantiates a new maccount checks common exception.
	 *
	 * @param errorCode
	 *            the error code
	 * @param errorMessage
	 *            the error message
	 */
	public MaccountChecksCommonException(int errorCode, String errorMessage) {
		super(errorMessage);
		this.setErrorCode(errorCode);
	}

	/**
	 * Gets the error code.
	 *
	 * @return the error code
	 */
	public int getErrorCode() {
		return errorCode;
	}

	/**
	 * Sets the error code.
	 *
	 * @param errorCode
	 *            the new error code
	 */
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * Gets the maccount checks common error.
	 *
	 * @return the maccount checks common error
	 */
	public MaccountChecksCommonError getMaccountChecksCommonError() {
		return maccountChecksCommonError;
	}

	/**
	 * Sets the maccount checks common error.
	 *
	 * @param maccountChecksCommonError
	 *            the new maccount checks common error
	 */
	public void setMaccountChecksCommonError(MaccountChecksCommonError maccountChecksCommonError) {
		this.maccountChecksCommonError = maccountChecksCommonError;
	}

}
