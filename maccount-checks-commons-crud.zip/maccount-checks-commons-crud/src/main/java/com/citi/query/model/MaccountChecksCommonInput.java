/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: ConMovCtaMaeContInput.java
 * Original Author: ENLM
 * Creation Date: 31/01/2017
 * ---------------------------------------------------------------------------
 */

package com.citi.query.model;
import java.math.BigInteger;

import com.softtek.legacy.framework.model.DataElement.DataType;
import com.softtek.legacy.framework.model.EntityModel;

/**
 *  <code>ConMovCtaMaeContInput</code>.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountChecksCommonInput {
	
	/** wks N 012 ec codchcm. */
	@EntityModel(index = 0, value = "", name = "wksN012EcCodchcm", fieldType = DataType.VARCHAR, length = 6, decimales = 0, format = "")
	private String wksN012EcCodchcm;
	
	/** wks N 012 ec prod. */
	@EntityModel(index = 1, value = "", name = "wksN012EcProd", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcProd;
	
	/** wks N 012 ec inst. */
	@EntityModel(index = 2, value = "", name = "wksN012EcInst", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcInst;
	
	/** wks N 012 solgrl suc. */
	@EntityModel(index = 3, value = "", name = "wksN012SolgrlSuc", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012SolgrlSuc;
	
	/** wks N 012 solgrl cta. */
	@EntityModel(index = 4, value = "", name = "wksN012SolgrlCta", fieldType = DataType.BIGINTEGER, length = 12, decimales = 0, format = "")
	private BigInteger wksN012SolgrlCta;
	
	/** wks N 012 ec opcion. */
	@EntityModel(index = 5, value = "", name = "wksN012EcOpcion", fieldType = DataType.INTEGER, length = 2, decimales = 0, format = "")
	private int wksN012EcOpcion;
	
	/** wks N 012 ec nummovs. */
	@EntityModel(index = 6, value = "", name = "wksN012EcNummovs", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcNummovs;
	
	/** wks N 012 ec sigchcm. */
	@EntityModel(index = 7, value = "", name = "wksN012EcSigchcm", fieldType = DataType.VARCHAR, length = 16, decimales = 0, format = "")
	private String wksN012EcSigchcm;
	
	/** filler 1. */
	@EntityModel(index = 8, value = "", name = "filler1", fieldType = DataType.VARCHAR, length = 12, decimales = 0, format = "")
	private String filler1;
	
	/** filler 2. */
	@EntityModel(index = 9, value = "", name = "filler2", fieldType = DataType.VARCHAR, length = 2, decimales = 0, format = "")
	private String filler2;

	/**
	 * Set the wks N 012 ec codchcm.
	 *
	 * @param parameter  wks N 012 ec codchcm
	 */
	public void setWksN012EcCodchcm( String parameter ) {
		wksN012EcCodchcm = parameter;
	}

	/**
	 * Gets the wks N 012 ec codchcm.
	 *
	 * @return wksN012EcCodchcm
	 */
	public String getWksN012EcCodchcm() {
		return wksN012EcCodchcm;
	}

	/**
	 * Set the wks N 012 ec prod.
	 *
	 * @param parameter  wks N 012 ec prod
	 */
	public void setWksN012EcProd( int parameter ) {
		wksN012EcProd = parameter;
	}

	/**
	 * Gets the wks N 012 ec prod.
	 *
	 * @return wksN012EcProd
	 */
	public int getWksN012EcProd() {
		return wksN012EcProd;
	}

	/**
	 * Set the wks N 012 ec inst.
	 *
	 * @param parameter  wks N 012 ec inst
	 */
	public void setWksN012EcInst( int parameter ) {
		wksN012EcInst = parameter;
	}

	/**
	 * Gets the wks N 012 ec inst.
	 *
	 * @return wksN012EcInst
	 */
	public int getWksN012EcInst() {
		return wksN012EcInst;
	}

	/**
	 * Set the wks N 012 solgrl suc.
	 *
	 * @param parameter  wks N 012 solgrl suc
	 */
	public void setWksN012SolgrlSuc( int parameter ) {
		wksN012SolgrlSuc = parameter;
	}

	/**
	 * Gets the wks N 012 solgrl suc.
	 *
	 * @return wksN012SolgrlSuc
	 */
	public int getWksN012SolgrlSuc() {
		return wksN012SolgrlSuc;
	}

	/**
	 * Set the wks N 012 solgrl cta.
	 *
	 * @param parameter  wks N 012 solgrl cta
	 */
	public void setWksN012SolgrlCta( BigInteger parameter ) {
		wksN012SolgrlCta = parameter;
	}

	/**
	 * Gets the wks N 012 solgrl cta.
	 *
	 * @return wksN012SolgrlCta
	 */
	public BigInteger getWksN012SolgrlCta() {
		return wksN012SolgrlCta;
	}

	/**
	 * Set the wks N 012 ec opcion.
	 *
	 * @param parameter  wks N 012 ec opcion
	 */
	public void setWksN012EcOpcion( int parameter ) {
		wksN012EcOpcion = parameter;
	}

	/**
	 * Gets the wks N 012 ec opcion.
	 *
	 * @return wksN012EcOpcion
	 */
	public int getWksN012EcOpcion() {
		return wksN012EcOpcion;
	}

	/**
	 * Set the wks N 012 ec nummovs.
	 *
	 * @param parameter  wks N 012 ec nummovs
	 */
	public void setWksN012EcNummovs( int parameter ) {
		wksN012EcNummovs = parameter;
	}

	/**
	 * Gets the wks N 012 ec nummovs.
	 *
	 * @return wksN012EcNummovs
	 */
	public int getWksN012EcNummovs() {
		return wksN012EcNummovs;
	}

	/**
	 * Set the wks N 012 ec sigchcm.
	 *
	 * @param parameter  wks N 012 ec sigchcm
	 */
	public void setWksN012EcSigchcm( String parameter ) {
		wksN012EcSigchcm = parameter;
	}

	/**
	 * Gets the wks N 012 ec sigchcm.
	 *
	 * @return wksN012EcSigchcm
	 */
	public String getWksN012EcSigchcm() {
		return wksN012EcSigchcm;
	}

	/**
	 * Set the filler 1.
	 *
	 * @param parameter  filler 1
	 */
	public void setFiller1( String parameter ) {
		filler1 = parameter;
	}

	/**
	 * Gets the filler 1.
	 *
	 * @return filler1
	 */
	public String getFiller1() {
		return filler1;
	}

	/**
	 * Set the filler 2.
	 *
	 * @param parameter  filler 2
	 */
	public void setFiller2( String parameter ) {
		filler2 = parameter;
	}

	/**
	 * Gets the filler 2.
	 *
	 * @return filler2
	 */
	public String getFiller2() {
		return filler2;
	}

} // ConmovctamaecontInput
