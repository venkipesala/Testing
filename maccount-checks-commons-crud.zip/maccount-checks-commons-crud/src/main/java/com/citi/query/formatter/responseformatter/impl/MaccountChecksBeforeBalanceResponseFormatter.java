/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksBeforeBalanceResponseFormatter.java
 * Original Author: Softtek
 * Creation Date: 10/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.formatter.responseformatter.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.citi.query.formatter.MaccountCheckMovementsOcurrsFormatter;
import com.citi.query.formatter.responseformatter.CommonResponseFormatter;
import com.citi.query.model.GroupOccurs;
import com.citi.query.model.MaccountCheckBeforeBalanceOutputOk;
import com.citi.query.response.InnerOcurrs;
import com.citi.query.response.MaccountCheckBeforeBalanceResponse;

/**
 * The Class MaccountChecksBeforeBalanceResponseFormatter.
 */
public class MaccountChecksBeforeBalanceResponseFormatter implements CommonResponseFormatter{
	
	/* (non-Javadoc)
	 * @see com.citi.query.formatter.responseformatter.CommonResponseFormatter#formatToResponse(java.lang.Object)
	 */
	@Override
	public MaccountCheckBeforeBalanceResponse formatToResponse(Object maccountChecksCommonOutputOk) {
		MaccountCheckBeforeBalanceResponse maccountCheckMovementsResponse = new MaccountCheckBeforeBalanceResponse();
		MaccountCheckMovementsOcurrsFormatter occursFormatter = new MaccountCheckMovementsOcurrsFormatter();
		
		MaccountCheckBeforeBalanceOutputOk movementsOutput = (MaccountCheckBeforeBalanceOutputOk)maccountChecksCommonOutputOk;
		List<GroupOccurs> listGroupOccurs = movementsOutput.getOutputDetail();
		List<InnerOcurrs> listInnerOccurs = new ArrayList<>();
		maccountCheckMovementsResponse.setAccountNumber(movementsOutput.getWksN012TraDtCta());
		maccountCheckMovementsResponse.setBranchID(movementsOutput.getWksN012TraDtSuc());
		maccountCheckMovementsResponse.setInstrumentID(movementsOutput.getWksN012EcInst());
		maccountCheckMovementsResponse.setNextMovement(movementsOutput.getWksN012EcSigchcm());
		maccountCheckMovementsResponse.setProductID(movementsOutput.getWksN012EcProd());
		maccountCheckMovementsResponse.setQuantityNumber(movementsOutput.getWksN012EcNummovs());
		maccountCheckMovementsResponse.setResultZeros(movementsOutput.getWksN012EcResult());
		maccountCheckMovementsResponse.setSuffix(movementsOutput.getFillero1());
		
		maccountCheckMovementsResponse.setBalanceAmount(movementsOutput.getWksN012EcSdoActual());
		maccountCheckMovementsResponse.setBalanceStartAmount(movementsOutput.getWksN012EcSdoInicial());
		maccountCheckMovementsResponse.setChargeOffAmount(movementsOutput.getWksN012EcCarImporte());
		maccountCheckMovementsResponse.setCreditAvailableAmount(this.getMount(movementsOutput.getWksN012EcLcDisp()));
		maccountCheckMovementsResponse.setCreditUsedAmount(this.getMount(movementsOutput.getWksN012EcLcSdo()));
		maccountCheckMovementsResponse.setCustomerId(movementsOutput.getWksNctlNumcte());
		maccountCheckMovementsResponse.setCustomerName(movementsOutput.getWksN012EcNomcte());
		maccountCheckMovementsResponse.setCutoffDay(movementsOutput.getWksN012EcFechaCorte());
		maccountCheckMovementsResponse.setDepositDueAmount(movementsOutput.getWksN012EcAboImporte());
		maccountCheckMovementsResponse.setEntrySequenceNumber(movementsOutput.getWksN012EcAboNum());
		maccountCheckMovementsResponse.setFinancialCreditLineAmount(this.getMount(movementsOutput.getWksN012EcLcImporte()));
		maccountCheckMovementsResponse.setLastAccessDate(movementsOutput.getWksN012EcFechaUltmov());
		maccountCheckMovementsResponse.setOutSequenceNumber(movementsOutput.getWksN012EcCarNum());
		maccountCheckMovementsResponse.setSignBalanceAmount(movementsOutput.getWksN012EcSdoActsigno());
		maccountCheckMovementsResponse.setSignBalanceStartAmount(movementsOutput.getWksN012EcSdoInisigno());
		maccountCheckMovementsResponse.setStartDate(movementsOutput.getWksN012EcFechaIni());
		maccountCheckMovementsResponse.setStopDate(movementsOutput.getWksN012EcFechaFin());
		
		maccountCheckMovementsResponse.setAnnualPercentageCycle(movementsOutput.getWksN012EcCicloRendim());
		maccountCheckMovementsResponse.setAnnualPercentageYield(movementsOutput.getWksN012EcCicloRendBruto());
		maccountCheckMovementsResponse.setAuthorizedUserWaiverDurationNumber(movementsOutput.getWksN012EcCheqExentos());
		maccountCheckMovementsResponse.setDaysOftheCycle(movementsOutput.getWksN012EcCicloDias());
		maccountCheckMovementsResponse.setCycleAverageBalanceAmount(movementsOutput.getWksN012EcCicloSdoProm());
		maccountCheckMovementsResponse.setDaysOftheYear(movementsOutput.getWksN012EcYearDias());
		maccountCheckMovementsResponse.setYearAverageBalanceAmount(movementsOutput.getWksN012EcYearSdoProm());
		maccountCheckMovementsResponse.setInterestPayCycleDay(movementsOutput.getWksN012EcCicloInteres());
		maccountCheckMovementsResponse.setInterestPayCycleYear(movementsOutput.getWksN012EcYearInteres());
		maccountCheckMovementsResponse.setPeriodRate(movementsOutput.getWksN012EcYearRendim());
		maccountCheckMovementsResponse.setDestinationCountryTaxAmount(movementsOutput.getWksN012EcCicloTax());
		maccountCheckMovementsResponse.setDeliveryReferenceNumber(movementsOutput.getWksN012EcCheqGirados());	
		
		for(GroupOccurs groupOccurrs: listGroupOccurs){
			InnerOcurrs inner = occursFormatter.formatToResponse(groupOccurrs);
			listInnerOccurs.add(inner);
		}
		maccountCheckMovementsResponse.setGpogroupOccurs(listInnerOccurs);
		
		return maccountCheckMovementsResponse;

	}
	
	
	private Double getMount(String strToMatch) {
		Double numImporte = 0d;
		if (strToMatch.trim().length() > 0) {
//			strToMatch = strToMatch.substring(0, strToMatch.length() - 2) + "."
//					+ strToMatch.substring(strToMatch.length() - 2);
			Pattern p = Pattern.compile("^\\s*[0-9]{1,6}.[0-9]{1,2}$");
			Matcher m = p.matcher(strToMatch);
			
			if (m.matches()) {
				numImporte = new Double(strToMatch);
			} 
		}
		return numImporte;
	}
	

}
