/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckMovementsOutputFormatter.java
 * Original Author: Softtek
 * Creation Date: 10/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.formatter;




import com.citi.query.model.MaccounChecksMovementsOutputOk;
import com.citi.query.response.MaccountCheckMovementsResponse;

import ma.glasnost.orika.BoundMapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * The Class MaccountCheckNextMovementsOutputFormatter.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckMovementsOutputFormatter {

	/** The Constant MAPPER_FACTORY. */
	private static final MapperFactory MAPPER_FACTORY = new DefaultMapperFactory.Builder().build();

	
	/** The mediator. */
	private BoundMapperFacade<MaccounChecksMovementsOutputOk, MaccountCheckMovementsResponse> mediator;

	/**
	 * Instantiates a new maccount check next movements output formatter.
	 */
	public MaccountCheckMovementsOutputFormatter() {

		MAPPER_FACTORY.classMap(MaccounChecksMovementsOutputOk.class, MaccountCheckMovementsResponse.class)
				.field("filler3", "suffix")
				.field("wksN012EcResult", "resultZeros")
				.field("wksN012EcProd", "productID")
				.field("wksN012EcInst", "instrumentID")
				.field("wksN012TraDtSuc", "branchID")
				.field("wksN012TraDtCta", "accountNumber")
				.field("wksN012EcSigchcm", "nextMovement")
				.field("wksN012EcNummovs", "quantityNumber")
				.register();
		this.mediator = MAPPER_FACTORY.getMapperFacade(MaccounChecksMovementsOutputOk.class,
				MaccountCheckMovementsResponse.class);
	}

	/**
	 * Format to response.
	 *
	 * @param conMovCtaMaeContOutputOk the con mov cta mae cont output ok
	 * @return the maccount check next movements response
	 */
	public MaccountCheckMovementsResponse formatToResponse(MaccounChecksMovementsOutputOk conMovCtaMaeContOutputOk) {

		return this.mediator.map(conMovCtaMaeContOutputOk);

	}
	

}
