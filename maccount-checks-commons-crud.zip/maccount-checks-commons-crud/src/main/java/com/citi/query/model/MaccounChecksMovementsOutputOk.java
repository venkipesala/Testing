/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: ConMovCtaMaeContOutputOk.java
 * Original Author: ENLM
 * Creation Date: 31/01/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.model;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.softtek.legacy.framework.model.DataElement.DataType;
import com.softtek.legacy.framework.model.EntityModel;

/**
 *  <code>ConMovCtaMaeContOutputOk</code>.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccounChecksMovementsOutputOk {
	
	/** filler 3. */
	@EntityModel(index = 0, value = "", name = "filler3", fieldType = DataType.VARCHAR, length = 6, decimales = 0, format = "")
	private String filler3;
	
	/** wks N 012 ec result. */
	@EntityModel(index = 1, value = "", name = "wksN012EcResult", fieldType = DataType.INTEGER, length = 2, decimales = 0, format = "")
	private int wksN012EcResult;
	
	/** wks N 012 ec prod. */
	@EntityModel(index = 2, value = "", name = "wksN012EcProd", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcProd;
	
	/** wks N 012 ec inst. */
	@EntityModel(index = 3, value = "", name = "wksN012EcInst", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcInst;
	
	/** wks N 012 tra dt suc. */
	@EntityModel(index = 4, value = "", name = "wksN012TraDtSuc", fieldType = DataType.VARCHAR, length = 4, decimales = 0, format = "")
	private String wksN012TraDtSuc;
	
	/** wks N 012 tra dt cta. */
	@EntityModel(index = 5, value = "", name = "wksN012TraDtCta", fieldType = DataType.BIGINTEGER, length = 12, decimales = 0, format = "")
	private BigInteger wksN012TraDtCta;
	
	/** wks N 012 ec sigchcm. */
	@EntityModel(index = 6, value = "", name = "wksN012EcSigchcm", fieldType = DataType.VARCHAR, length = 16, decimales = 0, format = "")
	private String wksN012EcSigchcm;
	
	/** wks N 012 ec nummovs. */
	@EntityModel(index = 7, value = "", name = "wksN012EcNummovs", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcNummovs;

	/**
	 * Set the filler 3.
	 *
	 * @param parameter  filler 3
	 */
	public void setFiller3(String parameter) {
		filler3 = parameter;
	}

	/**
	 * Gets the filler 3.
	 *
	 * @return filler3
	 */
	public String getFiller3() {
		return filler3;
	}

	/**
	 * Set the wks N 012 ec result.
	 *
	 * @param parameter  wks N 012 ec result
	 */
	public void setWksN012EcResult(int parameter) {
		wksN012EcResult = parameter;
	}

	/**
	 * Gets the wks N 012 ec result.
	 *
	 * @return wksN012EcResult
	 */
	public int getWksN012EcResult() {
		return wksN012EcResult;
	}

	/**
	 * Set the wks N 012 ec prod.
	 *
	 * @param parameter  wks N 012 ec prod
	 */
	public void setWksN012EcProd(int parameter) {
		wksN012EcProd = parameter;
	}

	/**
	 * Gets the wks N 012 ec prod.
	 *
	 * @return wksN012EcProd
	 */
	public int getWksN012EcProd() {
		return wksN012EcProd;
	}

	/**
	 * Set the wks N 012 ec inst.
	 *
	 * @param parameter  wks N 012 ec inst
	 */
	public void setWksN012EcInst(int parameter) {
		wksN012EcInst = parameter;
	}

	/**
	 * Gets the wks N 012 ec inst.
	 *
	 * @return wksN012EcInst
	 */
	public int getWksN012EcInst() {
		return wksN012EcInst;
	}

	/**
	 * Set the wks N 012 tra dt suc.
	 *
	 * @param parameter  wks N 012 tra dt suc
	 */
	public void setWksN012TraDtSuc(String parameter) {
		wksN012TraDtSuc = parameter;
	}

	/**
	 * Gets the wks N 012 tra dt suc.
	 *
	 * @return wksN012TraDtSuc
	 */
	public String getWksN012TraDtSuc() {
		return wksN012TraDtSuc;
	}

	/**
	 * Set the wks N 012 tra dt cta.
	 *
	 * @param parameter  wks N 012 tra dt cta
	 */
	public void setWksN012TraDtCta(BigInteger parameter) {
		wksN012TraDtCta = parameter;
	}

	/**
	 * Gets the wks N 012 tra dt cta.
	 *
	 * @return wksN012TraDtCta
	 */
	public BigInteger getWksN012TraDtCta() {
		return wksN012TraDtCta;
	}

	/**
	 * Set the wks N 012 ec sigchcm.
	 *
	 * @param parameter  wks N 012 ec sigchcm
	 */
	public void setWksN012EcSigchcm(String parameter) {
		wksN012EcSigchcm = parameter;
	}

	/**
	 * Gets the wks N 012 ec sigchcm.
	 *
	 * @return wksN012EcSigchcm
	 */
	public String getWksN012EcSigchcm() {
		return wksN012EcSigchcm;
	}

	/**
	 * Set the wks N 012 ec nummovs.
	 *
	 * @param parameter  wks N 012 ec nummovs
	 */
	public void setWksN012EcNummovs(int parameter) {
		wksN012EcNummovs = parameter;
	}

	/**
	 * Gets the wks N 012 ec nummovs.
	 *
	 * @return wksN012EcNummovs
	 */
	public int getWksN012EcNummovs() {
		return wksN012EcNummovs;
	}

	/** output detail. */
	private List<GroupOccurs> outputDetail = new ArrayList<>();

	/**
	 * Gets the output detail.
	 *
	 * @return output detail
	 */
	public List<GroupOccurs> getOutputDetail() {
		return outputDetail;
	}

	/**
	 * Set the output detail.
	 *
	 * @param outputDetail  output detail
	 */
	public void setOutputDetail(List<GroupOccurs> outputDetail) {
		this.outputDetail = outputDetail;
	}

} // ConmovctamaecontOutputOk
