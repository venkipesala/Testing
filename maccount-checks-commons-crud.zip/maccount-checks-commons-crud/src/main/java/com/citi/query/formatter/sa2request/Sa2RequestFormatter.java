package com.citi.query.formatter.sa2request;

import com.banamex.nga.gemfire.cache.stationame.beans.StationName;
import com.citi.query.model.MaccountChecksCommonInput;
import com.citi.query.request.MaccountCheckCommonRequest;
import com.citi.unisys.model.HeaderBnmx;
import com.citi.unisys.model.HeaderSa2;

public interface Sa2RequestFormatter {
	public MaccountChecksCommonInput formatToInputModel(MaccountCheckCommonRequest maccountCheckMovementsRequest);
	public HeaderBnmx formatHeaderBnmx(MaccountCheckCommonRequest maccountCheckMovementsRequest, StationName stationName);
	public HeaderSa2 formatHeaderSa2(MaccountCheckCommonRequest maccountCheckMovementsRequest);
}
