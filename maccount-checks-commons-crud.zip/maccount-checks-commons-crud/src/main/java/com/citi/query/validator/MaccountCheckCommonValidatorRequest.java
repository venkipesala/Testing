/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckCommonValidatorRequest.java
 * Original Author: ENLM
 * Creation Date: 7/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.validator;

import org.springframework.stereotype.Component;

import com.citi.query.exception.MaccountChecksCommonException;
import com.citi.query.request.MaccountCheckCommonRequest;

/**
 * <code>ValidatorRequest</code>.
 *
 * @author el14811
 * @version 1.0
 */
@Component
public class MaccountCheckCommonValidatorRequest {

	/**
	 * Validate.
	 *
	 * @param request
	 *            request
	 * @throws MaccountChecksCommonException
	 *             maccount checks common exception.
	 */
	public void validate(MaccountCheckCommonRequest request) throws MaccountChecksCommonException {

		if (!isFieldLengthValid(String.valueOf(request.getProductID()), 4))
			throw new MaccountChecksCommonException(25, "ERROR EN EL ID DEL PRODUCTO");

		if (!isFieldLengthValid(String.valueOf(request.getInstrumentID()), 4))
			throw new MaccountChecksCommonException(8, "ERROR EN EL ID DEL INSTRUMENTO");

		if (!isFieldLengthValid(String.valueOf(request.getBranchID()), 4))
			throw new MaccountChecksCommonException(25, "ERROR EN EL ID DEL SUCURSAL");

		if (!isFieldLengthValid(String.valueOf(request.getAccountNumber().toString()), 12))
			throw new MaccountChecksCommonException(25, "ERROR EN EL NUMERO DE CUENTA");

		if (!isFieldLengthValid(String.valueOf(request.getOptionNumber()), 2)
				|| !isFieldRangeValid(request.getOptionNumber(), 41, 43))
			throw new MaccountChecksCommonException(25, "EL NUMERO DE OPCION SOLO PUEDE SER 41, 42 O 43");
	}

	/**
	 * Verify if that field length valid is true.
	 *
	 * @param strParam str param
	 * @param lengthParam length param
	 * @return true, in case the condition is satisfied field length valid
	 */
	private boolean isFieldLengthValid(String strParam, int lengthParam) {

		boolean lretVal = false;
		if ((strParam).toCharArray().length <= lengthParam) {
			lretVal = true;
		}
		return lretVal;
	}

	/**
	 * Verify if that field range valid is true.
	 *
	 * @param intParam int param
	 * @param minVal min val
	 * @param maxVal max val
	 * @return true, in case the condition is satisfied field range valid
	 */
	private boolean isFieldRangeValid(int intParam, int minVal, int maxVal) {

		if (intParam >= minVal && intParam <= maxVal) {
			return true;
		}

		return false;
	}
}