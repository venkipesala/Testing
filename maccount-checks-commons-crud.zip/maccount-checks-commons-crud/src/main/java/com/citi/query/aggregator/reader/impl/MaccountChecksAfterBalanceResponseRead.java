/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksAfterBalanceResponseRead.java
 * Original Author: Softtek
 * Creation Date: 2/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.aggregator.reader.impl;

import java.util.ArrayList;
import java.util.List;

import com.citi.query.aggregator.reader.MaccountChecksCommonResponseRead;
import com.citi.query.model.GroupOccurs;
import com.citi.query.model.MaccountChecksAfterBalanceOutputOk;
import com.citi.query.response.MaccountChecksAfterBalanceResponse;
import com.softtek.legacy.framework.model.DataElementFormatException;
import com.softtek.legacy.framework.parser.ParserException;
import com.softtek.legacy.framework.util.BufferToEntity;

/**
 * The Class MaccountChecksAfterBalanceResponseRead.
 */
public class MaccountChecksAfterBalanceResponseRead implements MaccountChecksCommonResponseRead {


	/* (non-Javadoc)
	 * @see com.citi.query.aggregator.reader.MaccountChecksCommonResponseRead#readResponse(java.lang.String)
	 */
	@Override
	public MaccountChecksAfterBalanceOutputOk readResponse(String bufferOutput)
			throws DataElementFormatException, ParserException {

		int indexOfBufferDetail = 255;

		MaccountChecksAfterBalanceOutputOk outputModel = new MaccountChecksAfterBalanceOutputOk();
		
		getEntityFromBuffer(bufferOutput.substring(0, 255), outputModel);

		List<GroupOccurs> queryDetails = new ArrayList<>();
		GroupOccurs detail;

		for (int occur = 0; occur < 15; occur++) {
			detail = new GroupOccurs();
			queryDetails.add((GroupOccurs) getEntityFromBuffer(
					bufferOutput.substring(indexOfBufferDetail, indexOfBufferDetail + 110), detail));
			indexOfBufferDetail += 110;
		}

		outputModel.setListOccurs(queryDetails);

		return outputModel;

	}


	/**
	 * Gets the entity from buffer.
	 *
	 * @param bufferOutput the buffer output
	 * @param objectModel the object model
	 * @return the entity from buffer
	 * @throws DataElementFormatException the data element format exception
	 * @throws ParserException the parser exception
	 */
	protected Object getEntityFromBuffer(String bufferOutput, Object objectModel)
			throws DataElementFormatException, ParserException {

		if (bufferOutput.trim().isEmpty())
			return objectModel;

		BufferToEntity buffToEntityBnmx = new BufferToEntity(bufferOutput, objectModel);
		buffToEntityBnmx.build();

		return objectModel;
	}
}
