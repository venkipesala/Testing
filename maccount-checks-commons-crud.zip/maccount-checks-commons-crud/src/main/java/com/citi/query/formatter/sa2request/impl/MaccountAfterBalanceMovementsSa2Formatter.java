package com.citi.query.formatter.sa2request.impl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;

import com.banamex.nga.gemfire.cache.stationame.beans.StationName;
import com.citi.query.aggregator.CacheAggregator;
import com.citi.query.formatter.sa2request.Sa2RequestFormatter;
import com.citi.query.model.MaccountChecksCommonInput;
import com.citi.query.request.MaccountCheckCommonRequest;
import com.citi.unisys.model.HeaderBnmx;
import com.citi.unisys.model.HeaderSa2;

public class MaccountAfterBalanceMovementsSa2Formatter implements Sa2RequestFormatter {
    
	@Override
	public MaccountChecksCommonInput formatToInputModel(MaccountCheckCommonRequest maccountCheckMovementsRequest) {
		MaccountChecksCommonInput commonInput = new MaccountChecksCommonInput();
		commonInput.setWksN012EcCodchcm("0MS066");
		commonInput.setWksN012EcProd(maccountCheckMovementsRequest.getProductID());
		commonInput.setWksN012EcInst(maccountCheckMovementsRequest.getInstrumentID());
		commonInput.setWksN012SolgrlSuc(maccountCheckMovementsRequest.getBranchID());
		commonInput.setWksN012SolgrlCta(maccountCheckMovementsRequest.getAccountNumber());
		commonInput.setWksN012EcOpcion(43);
		commonInput.setWksN012EcNummovs(maccountCheckMovementsRequest.getQuantityNumber());
		commonInput.setWksN012EcSigchcm(maccountCheckMovementsRequest.getNextMovement());
		commonInput.setFiller1("            ");
		commonInput.setFiller2("00");
		return commonInput;
	}

	@Override
	public HeaderBnmx formatHeaderBnmx(MaccountCheckCommonRequest maccountCheckMovementsRequest, StationName stationName) {
		HeaderBnmx headerBnmx = new HeaderBnmx();
		headerBnmx.setHdrBnmxPrefijoHeader("F");
		headerBnmx.setHdrBnmxPrefijoAplicacionDestino("0");
		headerBnmx.setHdrBnmxCsiDestino(maccountCheckMovementsRequest.getCsi());
		headerBnmx.setHdrBnmxNumeroEstacion(0);
		headerBnmx.setHdrBnmxTipoTerminal(stationName.getStationName().substring(0,1));
		headerBnmx.setHdrBnmxSucursal(maccountCheckMovementsRequest.getBranchID());
		headerBnmx.setHdrBnmxPrivilegioTerminal(stationName.getStationName().substring(5,6));
		headerBnmx.setHdrBnmxCaja(maccountCheckMovementsRequest.getCashCode());
		headerBnmx.setHdrBnmxCsiOrigen(maccountCheckMovementsRequest.getCsi());
		headerBnmx.setHdrBnmxNodoOrigen(0);
		headerBnmx.setHdrBnmxFacultadoTerminalista("  ");
		headerBnmx.setHdrBnmxPrefijoAplicacionOrigen(" ");
		headerBnmx.setHdrBnmxResultado(2);
		headerBnmx.setHdrBnmxNombreMascara("     ");
		headerBnmx.setHdrBnmxClaveSeguridadOperador("      ");
		headerBnmx.setHdrExtAplicacionDestino(50);
		headerBnmx.setHdrExtModuloDestino(14);
		headerBnmx.setHdrExtAplicacionOrigen(15);
		headerBnmx.setHdrExtModuloOrigen(12);
		return headerBnmx;
	}

	@Override
	public HeaderSa2 formatHeaderSa2(MaccountCheckCommonRequest maccountCheckMovementsRequest) {
		HeaderSa2 headerSa2 = new HeaderSa2();
		headerSa2.setSa2SistemaDestino(50);
		headerSa2.setSa2CodigoServicioDestino(0);
		headerSa2.setSa2SubCodigoServicioDestino(811);
		headerSa2.setSa2SistemaOrigen(15);
		headerSa2.setSa2CodigoServicioOrigen(0);
		headerSa2.setSa2SubCodigoServicioOrigen(811);
		headerSa2.setSa2Direccion(1);
		headerSa2.setSa2LongitudMensaje(278);
		headerSa2.setSa2TiempoEspera(60);
		headerSa2.setSa2ResultadoIca(1);
		headerSa2.setSa2Identificacion(0);
		headerSa2.setSa2Reconocimiento(0);
		headerSa2.setSa2Version("B");
		headerSa2.setSa2Clase(0);
		headerSa2.setSa2Resultado(0);
		headerSa2.setSa2ModoOperacion(1);
		headerSa2.setSa2EntidadOrigen(maccountCheckMovementsRequest.getBranchNumber()); // REVISAR
		headerSa2.setSa2NumeroDeCaja(maccountCheckMovementsRequest.getCashCode());
		headerSa2.setSa2TipoReferenciaTransaccion(0);
		headerSa2.setSa2NumeroDeOperacionTransaccion(8);
		headerSa2.setSa2NumeroDeReferenciaTransaccion(maccountCheckMovementsRequest.getSystemReference());
		headerSa2.setSa2FechaDeGeneracion(this.getLocalDate());
		headerSa2.setSa2HoraDeGeneracion(this.getLocalTime());
		headerSa2.setSa2Modalidad(20);
		headerSa2.setSa2ClaveOperador("          ");
		headerSa2.setSa2VersionMensaje("A");
		return headerSa2;
	}

	/**
	 * Gets the local date.
	 *
	 * @return local date
	 */
	private int getLocalDate() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMdd");
		LocalDate date = LocalDate.now();
		String localDate = date.format(formatter);

		return Integer.parseInt(localDate);
	}

	/**
	 * Gets the local time.
	 *
	 * @return local time
	 */
	private int getLocalTime() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HHmmss");
		LocalTime date = LocalTime.now();
		String localTime = date.format(formatter);
		return Integer.parseInt(localTime);
	}

}
