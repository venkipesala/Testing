/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckMovementsResponse.java
 * Original Author: ENLM
 * Creation Date: 31/01/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.response;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;


/**
 * The Class ConMovCtaMaeContResponse.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckMovementsResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The suffix FR 9055. */
	private String suffix;

	/** The result 00. */
	private int resultZeros;

	/** The product ID. */
	private int productID;

	/** The instrument ID. */
	private int instrumentID;

	/** The branch ID. */
	private String branchID;

	/** The account number. */
	private BigInteger accountNumber;

	/** The next movement. */
	private String nextMovement;

	/** The quantity number. */
	private int quantityNumber;

	/** The gpogroup occurs. */
	private List<InnerOcurrs> gpogroupOccurs = new ArrayList<>();

	/**
	 * Gets the suffix FR 9055.
	 *
	 * @return the suffix FR 9055
	 */
	public String getSuffix() {
		return suffix;
	}

	/**
	 * Sets the suffix FR 9055.
	 *
	 * @param suffix
	 *            the new suffix FR 9055
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	/**
	 * Gets the result 00.
	 *
	 * @return the result 00
	 */
	public int getResultZeros() {
		return resultZeros;
	}

	/**
	 * Sets the result 00.
	 *
	 * @param resultZeros
	 *            the new result 00
	 */
	public void setResultZeros(int resultZeros) {
		this.resultZeros = resultZeros;
	}

	/**
	 * Gets the product ID.
	 *
	 * @return the product ID
	 */
	public int getProductID() {
		return productID;
	}

	/**
	 * Sets the product ID.
	 *
	 * @param productID
	 *            the new product ID
	 */
	public void setProductID(int productID) {
		this.productID = productID;
	}

	/**
	 * Gets the instrument ID.
	 *
	 * @return the instrument ID
	 */
	public int getInstrumentID() {
		return instrumentID;
	}

	/**
	 * Sets the instrument ID.
	 *
	 * @param instrumentID
	 *            the new instrument ID
	 */
	public void setInstrumentID(int instrumentID) {
		this.instrumentID = instrumentID;
	}

	/**
	 * Gets the branch ID.
	 *
	 * @return the branch ID
	 */
	public String getBranchID() {
		return branchID;
	}

	/**
	 * Sets the branch ID.
	 *
	 * @param branchID
	 *            the new branch ID
	 */
	public void setBranchID(String branchID) {
		this.branchID = branchID;
	}

	/**
	 * Gets the account number.
	 *
	 * @return the account number
	 */
	public BigInteger getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber
	 *            the new account number
	 */
	public void setAccountNumber(BigInteger accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Gets the next movement.
	 *
	 * @return the next movement
	 */
	public String getNextMovement() {
		return nextMovement;
	}

	/**
	 * Sets the next movement.
	 *
	 * @param nextMovement
	 *            the new next movement
	 */
	public void setNextMovement(String nextMovement) {
		this.nextMovement = nextMovement;
	}

	/**
	 * Gets the quantity number.
	 *
	 * @return the quantity number
	 */
	public int getQuantityNumber() {
		return quantityNumber;
	}

	/**
	 * Sets the quantity number.
	 *
	 * @param quantityNumber
	 *            the new quantity number
	 */
	public void setQuantityNumber(int quantityNumber) {
		this.quantityNumber = quantityNumber;
	}

	/**
	 * Gets the gpogroup occurs.
	 *
	 * @return the gpogroup occurs
	 */
	public List<InnerOcurrs> getGpogroupOccurs() {
		return gpogroupOccurs;
	}

	/**
	 * Sets the gpogroup occurs.
	 *
	 * @param gpogroupOccurs
	 *            the new gpogroup occurs
	 */
	public void setGpogroupOccurs(List<InnerOcurrs> gpogroupOccurs) {
		this.gpogroupOccurs = gpogroupOccurs;
	}



}