/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckBeforeBalanceResponse.java
 * Original Author: Softtek
 * Creation Date: 31/01/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.response;

import java.io.Serializable;

/**
 *  <code>MaccountCheckBeforeBalanceResponse</code>.
 *
 * @author Vlixes
 * @version 1.0
 */
public class MaccountCheckBeforeBalanceResponse extends MaccountChecksAfterBalanceResponse implements Serializable {

 
	/**
	 * 
	 */
	private static final long serialVersionUID = -6948367841137410664L;

	/** days ofthe cycle. */
	private int 		daysOftheCycle;
	
	/** days ofthe year. */
	private int 		daysOftheYear;
	
	/** cycle average balance amount. */
	private double 		cycleAverageBalanceAmount;
	
	/** year average balance amount. */
	private double 		yearAverageBalanceAmount;
	
	/** days ofthe cycle. */
	private double 		interestPayCycleDay;
	
	/** interest pay cycle year. */
	private double 		interestPayCycleYear;

	/** annual percentage cycle. */
	private double 		annualPercentageCycle;

	
	/** annual percentage yield. */
	private double 		annualPercentageYield;
	
	/** period rate. */
	private double 		periodRate;
	
	/** destination country tax amount. */
	private double 		destinationCountryTaxAmount;
	
	/** delivery reference number. */
	private String 		deliveryReferenceNumber;
	
	/** authorized user waiver duration number. */
	private String 		authorizedUserWaiverDurationNumber;
	

	

	
	/**
	 * Gets the days ofthe year.
	 *
	 * @return days ofthe year
	 */
	public int getDaysOftheYear() {
		return daysOftheYear;
	}
	
	/**
	 * Set the days ofthe year.
	 *
	 * @param daysOftheYear  days ofthe year
	 */
	public void setDaysOftheYear(int daysOftheYear) {
		this.daysOftheYear = daysOftheYear;
	}
	
	/**
	 * Gets the cycle average balance amount.
	 *
	 * @return cycle average balance amount
	 */
	public double getCycleAverageBalanceAmount() {
		return cycleAverageBalanceAmount;
	}
	
	/**
	 * Set the cycle average balance amount.
	 *
	 * @param cycleAverageBalanceAmount  cycle average balance amount
	 */
	public void setCycleAverageBalanceAmount(double cycleAverageBalanceAmount) {
		this.cycleAverageBalanceAmount = cycleAverageBalanceAmount;
	}
	
	/**
	 * Gets the year average balance amount.
	 *
	 * @return year average balance amount
	 */
	public double getYearAverageBalanceAmount() {
		return yearAverageBalanceAmount;
	}
	
	/**
	 * Set the year average balance amount.
	 *
	 * @param yearAverageBalanceAmount  year average balance amount
	 */
	public void setYearAverageBalanceAmount(double yearAverageBalanceAmount) {
		this.yearAverageBalanceAmount = yearAverageBalanceAmount;
	}
	
	/**
	 * Gets the interest pay cycle day.
	 *
	 * @return interest pay cycle day
	 */
	public double getInterestPayCycleDay() {
		return interestPayCycleDay;
	}
	
	/**
	 * Set the interest pay cycle day.
	 *
	 * @param interestPayCycleDay  interest pay cycle day
	 */
	public void setInterestPayCycleDay(double interestPayCycleDay) {
		this.interestPayCycleDay = interestPayCycleDay;
	}
	
	/**
	 * Gets the interest pay cycle year.
	 *
	 * @return interest pay cycle year
	 */
	public double getInterestPayCycleYear() {
		return interestPayCycleYear;
	}
	
	/**
	 * Set the interest pay cycle year.
	 *
	 * @param interestPayCycleYear  interest pay cycle year
	 */
	public void setInterestPayCycleYear(double interestPayCycleYear) {
		this.interestPayCycleYear = interestPayCycleYear;
	}
	
	/**
	 * Gets the annual percentage cycle.
	 *
	 * @return annual percentage cycle
	 */
	public double getAnnualPercentageCycle() {
		return annualPercentageCycle;
	}
	
	/**
	 * Set the annual percentage cycle.
	 *
	 * @param annualPercentageCycle  annual percentage cycle
	 */
	public void setAnnualPercentageCycle(double annualPercentageCycle) {
		this.annualPercentageCycle = annualPercentageCycle;
	}
	
	/**
	 * Gets the annual percentage yield.
	 *
	 * @return annual percentage yield
	 */
	public double getAnnualPercentageYield() {
		return annualPercentageYield;
	}
	
	/**
	 * Set the annual percentage yield.
	 *
	 * @param annualPercentageYield  annual percentage yield
	 */
	public void setAnnualPercentageYield(double annualPercentageYield) {
		this.annualPercentageYield = annualPercentageYield;
	}
	
	/**
	 * Gets the period rate.
	 *
	 * @return period rate
	 */
	public double getPeriodRate() {
		return periodRate;
	}
	
	/**
	 * Set the period rate.
	 *
	 * @param periodRate  period rate
	 */
	public void setPeriodRate(double periodRate) {
		this.periodRate = periodRate;
	}
	
	/**
	 * Gets the destination country tax amount.
	 *
	 * @return destination country tax amount
	 */
	public double getDestinationCountryTaxAmount() {
		return destinationCountryTaxAmount;
	}
	
	/**
	 * Set the destination country tax amount.
	 *
	 * @param destinationCountryTaxAmount  destination country tax amount
	 */
	public void setDestinationCountryTaxAmount(double destinationCountryTaxAmount) {
		this.destinationCountryTaxAmount = destinationCountryTaxAmount;
	}
	
	/**
	 * Gets the delivery reference number.
	 *
	 * @return delivery reference number
	 */
	public String getDeliveryReferenceNumber() {
		return deliveryReferenceNumber;
	}
	
	/**
	 * Set the delivery reference number.
	 *
	 * @param deliveryReferenceNumber  delivery reference number
	 */
	public void setDeliveryReferenceNumber(String deliveryReferenceNumber) {
		this.deliveryReferenceNumber = deliveryReferenceNumber;
	}
	
	/**
	 * Gets the authorized user waiver duration number.
	 *
	 * @return authorized user waiver duration number
	 */
	public String getAuthorizedUserWaiverDurationNumber() {
		return authorizedUserWaiverDurationNumber;
	}
	
	/**
	 * Set the authorized user waiver duration number.
	 *
	 * @param authorizedUserWaiverDurationNumber  authorized user waiver duration number
	 */
	public void setAuthorizedUserWaiverDurationNumber(String authorizedUserWaiverDurationNumber) {
		this.authorizedUserWaiverDurationNumber = authorizedUserWaiverDurationNumber;
	}

	public int getDaysOftheCycle() {
		return daysOftheCycle;
	}

	public void setDaysOftheCycle(int daysOftheCycle) {
		this.daysOftheCycle = daysOftheCycle;
	}


}
