/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksAfterBalanceResponse.java
 * Original Author: Softtek
 * Creation Date: 2/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.response;

import java.io.Serializable;
import java.math.BigInteger;

/**
 * The Class MaccountChecksAfterBalanceResponse.
 */
public class MaccountChecksAfterBalanceResponse extends MaccountCheckMovementsResponse implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The customer id. */
	private BigInteger customerId; // wksNctlNumcte
	
	/** The customer name. */
	private String customerName; // wksN012EcNomcte
	
	/** The cutoff day. */
	private int cutoffDay; // wksN012EcFechaCorte
	
	/** The last access date. */
	private int lastAccessDate; // wksN012EcFechaUltmov
	
	/** The start date. */
	private int startDate; // wksN012EcFechaIni
	
	/** The stop date. */
	private int stopDate; // wksN012EcFechaFin
	
	/** The balance start amount. */
	private double balanceStartAmount; // wksN012EcSdoInicial
	
	/** The sign balance start amount. */
	private String signBalanceStartAmount; // wksN012EcSdoInisigno
	
	/** The entry sequence number. */
	private int entrySequenceNumber; // wksN012EcAboNum
	
	/** The deposit due amount. */
	private double depositDueAmount; // wksN012EcAboImporte
	
	/** The out sequence number. */
	private int outSequenceNumber; // wksN012EcCarNum
	
	/** The charge off amount. */
	private double chargeOffAmount; // wksN012EcCarImporte
	
	/** The balance amount. */
	private double balanceAmount; // wksN012EcSdoActual
	
	/** The sign balance amount. */
	private String signBalanceAmount; // wksN012EcSdoActsigno
	
	/** The financial credit line amount. */
	private double financialCreditLineAmount; // wksN012EcLcImporte
	
	/** The credit used amount. */
	private double creditUsedAmount; // wksN012EcLcSdo
	
	/** The credit available amount. */
	private double creditAvailableAmount; // wksN012EcLcDisp

	/**
	 * Gets the customer id.
	 *
	 * @return the customer id
	 */
	public BigInteger getCustomerId() {
		return customerId;
	}

	/**
	 * Sets the customer id.
	 *
	 * @param customerId the new customer id
	 */
	public void setCustomerId(BigInteger customerId) {
		this.customerId = customerId;
	}

	/**
	 * Gets the customer name.
	 *
	 * @return the customer name
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * Sets the customer name.
	 *
	 * @param customerName the new customer name
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * Gets the cutoff day.
	 *
	 * @return the cutoff day
	 */
	public int getCutoffDay() {
		return cutoffDay;
	}

	/**
	 * Sets the cutoff day.
	 *
	 * @param cutoffDay the new cutoff day
	 */
	public void setCutoffDay(int cutoffDay) {
		this.cutoffDay = cutoffDay;
	}

	/**
	 * Gets the last access date.
	 *
	 * @return the last access date
	 */
	public int getLastAccessDate() {
		return lastAccessDate;
	}

	/**
	 * Sets the last access date.
	 *
	 * @param lastAccessDate the new last access date
	 */
	public void setLastAccessDate(int lastAccessDate) {
		this.lastAccessDate = lastAccessDate;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public int getStartDate() {
		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(int startDate) {
		this.startDate = startDate;
	}

	/**
	 * Gets the stop date.
	 *
	 * @return the stop date
	 */
	public int getStopDate() {
		return stopDate;
	}

	/**
	 * Sets the stop date.
	 *
	 * @param stopDate the new stop date
	 */
	public void setStopDate(int stopDate) {
		this.stopDate = stopDate;
	}

	/**
	 * Gets the balance start amount.
	 *
	 * @return the balance start amount
	 */
	public double getBalanceStartAmount() {
		return balanceStartAmount;
	}

	/**
	 * Sets the balance start amount.
	 *
	 * @param balanceStartAmount the new balance start amount
	 */
	public void setBalanceStartAmount(double balanceStartAmount) {
		this.balanceStartAmount = balanceStartAmount;
	}

	/**
	 * Gets the sign balance start amount.
	 *
	 * @return the sign balance start amount
	 */
	public String getSignBalanceStartAmount() {
		return signBalanceStartAmount;
	}

	/**
	 * Sets the sign balance start amount.
	 *
	 * @param signBalanceStartAmount the new sign balance start amount
	 */
	public void setSignBalanceStartAmount(String signBalanceStartAmount) {
		this.signBalanceStartAmount = signBalanceStartAmount;
	}

	/**
	 * Gets the entry sequence number.
	 *
	 * @return the entry sequence number
	 */
	public int getEntrySequenceNumber() {
		return entrySequenceNumber;
	}

	/**
	 * Sets the entry sequence number.
	 *
	 * @param entrySequenceNumber the new entry sequence number
	 */
	public void setEntrySequenceNumber(int entrySequenceNumber) {
		this.entrySequenceNumber = entrySequenceNumber;
	}

	/**
	 * Gets the deposit due amount.
	 *
	 * @return the deposit due amount
	 */
	public double getDepositDueAmount() {
		return depositDueAmount;
	}

	/**
	 * Sets the deposit due amount.
	 *
	 * @param depositDueAmount the new deposit due amount
	 */
	public void setDepositDueAmount(double depositDueAmount) {
		this.depositDueAmount = depositDueAmount;
	}

	/**
	 * Gets the out sequence number.
	 *
	 * @return the out sequence number
	 */
	public int getOutSequenceNumber() {
		return outSequenceNumber;
	}

	/**
	 * Sets the out sequence number.
	 *
	 * @param outSequenceNumber the new out sequence number
	 */
	public void setOutSequenceNumber(int outSequenceNumber) {
		this.outSequenceNumber = outSequenceNumber;
	}

	/**
	 * Gets the charge off amount.
	 *
	 * @return the charge off amount
	 */
	public double getChargeOffAmount() {
		return chargeOffAmount;
	}

	/**
	 * Sets the charge off amount.
	 *
	 * @param chargeOffAmount the new charge off amount
	 */
	public void setChargeOffAmount(double chargeOffAmount) {
		this.chargeOffAmount = chargeOffAmount;
	}

	/**
	 * Gets the balance amount.
	 *
	 * @return the balance amount
	 */
	public double getBalanceAmount() {
		return balanceAmount;
	}

	/**
	 * Sets the balance amount.
	 *
	 * @param balanceAmount the new balance amount
	 */
	public void setBalanceAmount(double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	/**
	 * Gets the sign balance amount.
	 *
	 * @return the sign balance amount
	 */
	public String getSignBalanceAmount() {
		return signBalanceAmount;
	}

	/**
	 * Sets the sign balance amount.
	 *
	 * @param signBalanceAmount the new sign balance amount
	 */
	public void setSignBalanceAmount(String signBalanceAmount) {
		this.signBalanceAmount = signBalanceAmount;
	}

	/**
	 * Gets the financial credit line amount.
	 *
	 * @return the financial credit line amount
	 */
	public double getFinancialCreditLineAmount() {
		return financialCreditLineAmount;
	}

	/**
	 * Sets the financial credit line amount.
	 *
	 * @param financialCreditLineAmount the new financial credit line amount
	 */
	public void setFinancialCreditLineAmount(double financialCreditLineAmount) {
		this.financialCreditLineAmount = financialCreditLineAmount;
	}

	/**
	 * Gets the credit used amount.
	 *
	 * @return the credit used amount
	 */
	public double getCreditUsedAmount() {
		return creditUsedAmount;
	}

	/**
	 * Sets the credit used amount.
	 *
	 * @param creditUsedAmount the new credit used amount
	 */
	public void setCreditUsedAmount(double creditUsedAmount) {
		this.creditUsedAmount = creditUsedAmount;
	}

	/**
	 * Gets the credit available amount.
	 *
	 * @return the credit available amount
	 */
	public double getCreditAvailableAmount() {
		return creditAvailableAmount;
	}

	/**
	 * Sets the credit available amount.
	 *
	 * @param creditAvailableAmount the new credit available amount
	 */
	public void setCreditAvailableAmount(double creditAvailableAmount) {
		this.creditAvailableAmount = creditAvailableAmount;
	}


}
