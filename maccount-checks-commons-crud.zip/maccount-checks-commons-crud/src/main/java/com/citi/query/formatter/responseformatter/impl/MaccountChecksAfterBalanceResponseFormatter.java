/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksAfterBalanceResponseFormatter.java
 * Original Author: Softtek
 * Creation Date: 10/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.formatter.responseformatter.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.citi.query.formatter.MaccountCheckMovementsOcurrsFormatter;
import com.citi.query.formatter.responseformatter.CommonResponseFormatter;
import com.citi.query.model.GroupOccurs;
import com.citi.query.model.MaccountChecksAfterBalanceOutputOk;
import com.citi.query.response.InnerOcurrs;
import com.citi.query.response.MaccountChecksAfterBalanceResponse;

/**
 * The Class MaccountChecksAfterBalanceResponseFormatter.
 */
public class MaccountChecksAfterBalanceResponseFormatter implements CommonResponseFormatter {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citi.query.formatter.responseformatter.CommonResponseFormatter#
	 * formatToResponse(java.lang.Object)
	 */
	@Override
	public MaccountChecksAfterBalanceResponse formatToResponse(Object maccountChecksCommonOutputOk) {
		MaccountChecksAfterBalanceResponse maccountCheckMovementsResponse = new MaccountChecksAfterBalanceResponse();
		MaccountCheckMovementsOcurrsFormatter occursFormatter = new MaccountCheckMovementsOcurrsFormatter();

		MaccountChecksAfterBalanceOutputOk movementsOutput = (MaccountChecksAfterBalanceOutputOk) maccountChecksCommonOutputOk;
		List<GroupOccurs> listGroupOccurs = movementsOutput.getListOccurs();
		List<InnerOcurrs> listInnerOccurs = new ArrayList<>();
		maccountCheckMovementsResponse.setAccountNumber(movementsOutput.getWksN012TraDtCta());
		maccountCheckMovementsResponse.setBranchID(movementsOutput.getWksN012TraDtSuc());
		maccountCheckMovementsResponse.setInstrumentID(movementsOutput.getWksN012EcInst());
		maccountCheckMovementsResponse.setNextMovement(movementsOutput.getWksN012EcSigchcm());
		maccountCheckMovementsResponse.setProductID(movementsOutput.getWksN012EcProd());
		maccountCheckMovementsResponse.setQuantityNumber(movementsOutput.getWksN012EcNummovs());
		maccountCheckMovementsResponse.setResultZeros(movementsOutput.getWksN012EcResult());
		maccountCheckMovementsResponse.setSuffix(movementsOutput.getFiller3());

		maccountCheckMovementsResponse.setBalanceAmount(this.getMount(movementsOutput.getWksN012EcSdoActual()));
		maccountCheckMovementsResponse.setBalanceStartAmount(this.getMount(movementsOutput.getWksN012EcSdoInicial()));
		maccountCheckMovementsResponse.setChargeOffAmount(this.getMount(movementsOutput.getWksN012EcCarImporte()));
		maccountCheckMovementsResponse.setCreditAvailableAmount(this.getMount(movementsOutput.getWksN012EcLcDisp()));
		maccountCheckMovementsResponse.setCreditUsedAmount(this.getMount(movementsOutput.getWksN012EcLcSdo()));
		maccountCheckMovementsResponse.setCustomerId(movementsOutput.getWksNctlNumcte());
		maccountCheckMovementsResponse.setCustomerName(movementsOutput.getWksN012EcNomcte());
		maccountCheckMovementsResponse.setCutoffDay(movementsOutput.getWksN012EcFechaCorte());
		maccountCheckMovementsResponse.setDepositDueAmount(this.getMount(movementsOutput.getWksN012EcAboImporte()));
		maccountCheckMovementsResponse.setEntrySequenceNumber(movementsOutput.getWksN012EcAboNum());
		maccountCheckMovementsResponse
				.setFinancialCreditLineAmount(this.getMount(movementsOutput.getWksN012EcLcImporte()));
		maccountCheckMovementsResponse.setLastAccessDate(movementsOutput.getWksN012EcFechaUltmov());
		maccountCheckMovementsResponse.setOutSequenceNumber(movementsOutput.getWksN012EcCarNum());
		maccountCheckMovementsResponse.setSignBalanceAmount(movementsOutput.getWksN012EcSdoActsigno());
		maccountCheckMovementsResponse.setSignBalanceStartAmount(movementsOutput.getWksN012EcSdoInisigno());
		maccountCheckMovementsResponse.setStartDate(movementsOutput.getWksN012EcFechaIni());
		maccountCheckMovementsResponse.setStopDate(movementsOutput.getWksN012EcFechaFin());

		for (GroupOccurs groupOccurrs : listGroupOccurs) {
			InnerOcurrs inner = occursFormatter.formatToResponse(groupOccurrs);
			listInnerOccurs.add(inner);
		}
		maccountCheckMovementsResponse.setGpogroupOccurs(listInnerOccurs);

		return maccountCheckMovementsResponse;

	}

	private Double getMount(String strToMatch) {
		Double numImporte = 0d;
		if (strToMatch.trim().length() > 0) {
//			strToMatch = strToMatch.substring(0, strToMatch.length() - 2) + "."
//					+ strToMatch.substring(strToMatch.length() - 2);
			Pattern p = Pattern.compile("^\\s*[0-9]{1,6}.[0-9]{1,2}$");
			Matcher m = p.matcher(strToMatch);
			
			if (m.matches()) {
				numImporte = new Double(strToMatch);
			} 
		}
		return numImporte;
	}

}
