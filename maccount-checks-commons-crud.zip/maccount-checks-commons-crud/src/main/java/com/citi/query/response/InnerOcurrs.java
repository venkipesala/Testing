/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: InnerOcurrs.java
 * Original Author: ENLM
 * Creation Date: 1/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.response;
/**
 * The Class InnerOcurrs.
 *
 * @author el14811
 * @version 1.0
 */
public class InnerOcurrs {

	/** The cycle count. */
	private int cycleCount;
	
	/** The transaction date. */
	private int transactionDate;
	
	/** The sequence number. */
	private int sequenceNumber;
	
	/** The description. */
	private String description;
	
	/** The sign amount. */
	private String signAmount;
	
	/** The transaction amount. */
	private double transactionAmount;
	
	/** The reference number. */
	private String referenceNumber;
	
	/** The authorization number. */
	private int authorizationNumber;
	
	/** The sign amount after. */
	private String signAmountAfter;
	
	/** The transaction amount after. */
	private double transactionAmountAfter;
	
	
	/**
	 * Gets the cycle count.
	 *
	 * @return the cycle count
	 */
	public int getCycleCount() {
		return cycleCount;
	}

	/**
	 * Sets the cycle count.
	 *
	 * @param cycleCount the new cycle count
	 */
	public void setCycleCount(int cycleCount) {
		this.cycleCount = cycleCount;
	}

	/**
	 * Gets the transaction date.
	 *
	 * @return the transaction date
	 */
	public int getTransactionDate() {
		return transactionDate;
	}

	/**
	 * Sets the transaction date.
	 *
	 * @param transactionDate the new transaction date
	 */
	public void setTransactionDate(int transactionDate) {
		this.transactionDate = transactionDate;
	}

	/**
	 * Gets the sequence number.
	 *
	 * @return the sequence number
	 */
	public int getSequenceNumber() {
		return sequenceNumber;
	}

	/**
	 * Sets the sequence number.
	 *
	 * @param sequenceNumber the new sequence number
	 */
	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Gets the sign amount.
	 *
	 * @return the sign amount
	 */
	public String getSignAmount() {
		return signAmount;
	}

	/**
	 * Sets the sign amount.
	 *
	 * @param signAmount the new sign amount
	 */
	public void setSignAmount(String signAmount) {
		this.signAmount = signAmount;
	}

	/**
	 * Gets the transaction amount.
	 *
	 * @return the transaction amount
	 */
	public double getTransactionAmount() {
		return transactionAmount;
	}

	/**
	 * Sets the transaction amount.
	 *
	 * @param transactionAmount the new transaction amount
	 */
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	/**
	 * Gets the reference number.
	 *
	 * @return the reference number
	 */
	public String getReferenceNumber() {
		return referenceNumber;
	}

	/**
	 * Sets the reference number.
	 *
	 * @param referenceNumber the new reference number
	 */
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	/**
	 * Gets the authorization number.
	 *
	 * @return the authorization number
	 */
	public int getAuthorizationNumber() {
		return authorizationNumber;
	}

	/**
	 * Sets the authorization number.
	 *
	 * @param authorizationNumber the new authorization number
	 */
	public void setAuthorizationNumber(int authorizationNumber) {
		this.authorizationNumber = authorizationNumber;
	}

	/**
	 * Gets the sign amount after.
	 *
	 * @return the sign amount after
	 */
	public String getSignAmountAfter() {
		return signAmountAfter;
	}

	/**
	 * Sets the sign amount after.
	 *
	 * @param signAmountAfter the new sign amount after
	 */
	public void setSignAmountAfter(String signAmountAfter) {
		this.signAmountAfter = signAmountAfter;
	}

	/**
	 * Gets the transaction amount after.
	 *
	 * @return the transaction amount after
	 */
	public double getTransactionAmountAfter() {
		return transactionAmountAfter;
	}

	/**
	 * Sets the transaction amount after.
	 *
	 * @param transactionAmountAfter the new transaction amount after
	 */
	public void setTransactionAmountAfter(double transactionAmountAfter) {
		this.transactionAmountAfter = transactionAmountAfter;
	}
	

}
