/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckBeforeBalanceOutputOk.java
 * Original Author: Softtek
 * Creation Date: 31/01/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.model;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.softtek.legacy.framework.model.DataElement.DataType;
import com.softtek.legacy.framework.model.EntityModel;

/**
 *  <code>MaccountCheckBeforeBalanceOutputOk</code>.
 *
 * @author Vlixes
 * @version 1.0
 */
public class MaccountCheckBeforeBalanceOutputOk {
	
	/** fillero 1. */
	@EntityModel(index = 0, value = "", name = "fillero1", fieldType = DataType.VARCHAR, length = 6, decimales = 0, format = "")
	private String fillero1;
	
	/** wks N 012 ec result. */
	@EntityModel(index = 1, value = "", name = "wksN012EcResult", fieldType = DataType.INTEGER, length = 2, decimales = 0, format = "")
	private int wksN012EcResult;
	
	/** wks N 012 ec prod. */
	@EntityModel(index = 2, value = "", name = "wksN012EcProd", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcProd;
	
	/** wks N 012 ec inst. */
	@EntityModel(index = 3, value = "", name = "wksN012EcInst", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcInst;
	
	/** wks N 012 tra dt suc. */
	@EntityModel(index = 4, value = "", name = "wksN012TraDtSuc", fieldType = DataType.VARCHAR, length = 4, decimales = 0, format = "")
	private String wksN012TraDtSuc;
	
	/** wks N 012 tra dt cta. */
	@EntityModel(index = 5, value = "", name = "wksN012TraDtCta", fieldType = DataType.BIGINTEGER, length = 12, decimales = 0, format = "")
	private BigInteger wksN012TraDtCta;
	
	/** wks nctl numcte. */
	@EntityModel(index = 6, value = "", name = "wksNctlNumcte", fieldType = DataType.BIGINTEGER, length = 12, decimales = 0, format = "")
	private BigInteger wksNctlNumcte;
	
	/** wks N 012 ec nomcte. */
	@EntityModel(index = 7, value = "", name = "wksN012EcNomcte", fieldType = DataType.VARCHAR, length = 55, decimales = 0, format = "")
	private String wksN012EcNomcte;
	
	/** wks N 012 ec fecha corte. */
	@EntityModel(index = 8, value = "", name = "wksN012EcFechaCorte", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcFechaCorte;
	
	/** wks N 012 ec fecha ultmov. */
	@EntityModel(index = 9, value = "", name = "wksN012EcFechaUltmov", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcFechaUltmov;
	
	/** wks N 012 ec fecha ini. */
	@EntityModel(index = 10, value = "", name = "wksN012EcFechaIni", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcFechaIni;
	
	/** wks N 012 ec fecha fin. */
	@EntityModel(index = 11, value = "", name = "wksN012EcFechaFin", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcFechaFin;
	
	/** wks N 012 ec sdo inicial. */
	@EntityModel(index = 12, value = "", name = "wksN012EcSdoInicial", fieldType = DataType.DOUBLE, length = 12, decimales = 2, format = "")
	private double wksN012EcSdoInicial;
	
	/** wks N 012 ec sdo inisigno. */
	@EntityModel(index = 13, value = "", name = "wksN012EcSdoInisigno", fieldType = DataType.VARCHAR, length = 1, decimales = 0, format = "")
	private String wksN012EcSdoInisigno;
	
	/** wks N 012 ec abo num. */
	@EntityModel(index = 14, value = "", name = "wksN012EcAboNum", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcAboNum;
	
	/** wks N 012 ec abo importe. */
	@EntityModel(index = 15, value = "", name = "wksN012EcAboImporte", fieldType = DataType.DOUBLE, length = 12, decimales = 2, format = "")
	private double wksN012EcAboImporte;
	
	/** wks N 012 ec car num. */
	@EntityModel(index = 16, value = "", name = "wksN012EcCarNum", fieldType = DataType.INTEGER, length = 6, decimales = 0, format = "")
	private int wksN012EcCarNum;
	
	/** wks N 012 ec car importe. */
	@EntityModel(index = 17, value = "", name = "wksN012EcCarImporte", fieldType = DataType.DOUBLE, length = 12, decimales = 2, format = "")
	private double wksN012EcCarImporte;
	
	/** wks N 012 ec sdo actual. */
	@EntityModel(index = 18, value = "", name = "wksN012EcSdoActual", fieldType = DataType.DOUBLE, length = 12, decimales = 2, format = "")
	private double wksN012EcSdoActual;
	
	/** wks N 012 ec sdo actsigno. */
	@EntityModel(index = 19, value = "", name = "wksN012EcSdoActsigno", fieldType = DataType.VARCHAR, length = 1, decimales = 0, format = "")
	private String wksN012EcSdoActsigno;
	
	/** wks N 012 ec lc importe. */
	@EntityModel(index = 20, value = "", name = "wksN012EcLcImporte", fieldType = DataType.VARCHAR, length = 12, decimales = 2, format = "")
	private String wksN012EcLcImporte;
	
	/** wks N 012 ec lc sdo. */
	@EntityModel(index = 21, value = "", name = "wksN012EcLcSdo", fieldType = DataType.VARCHAR, length = 12, decimales = 2, format = "")
	private String wksN012EcLcSdo;
	
	/** wks N 012 ec lc disp. */
	@EntityModel(index = 22, value = "", name = "wksN012EcLcDisp", fieldType = DataType.VARCHAR, length = 12, decimales = 2, format = "")
	private String wksN012EcLcDisp;
	
	/** wks N 012 ec ciclo dias. */
	@EntityModel(index = 23, value = "", name = "wksN012EcCicloDias", fieldType = DataType.INTEGER, length = 2, decimales = 0, format = "")
	private int wksN012EcCicloDias;
	
	/** wks N 012 ec year dias. */
	@EntityModel(index = 24, value = "", name = "wksN012EcYearDias", fieldType = DataType.INTEGER, length = 3, decimales = 0, format = "")
	private int wksN012EcYearDias;
	
	/** wks N 012 ec ciclo sdo prom. */
	@EntityModel(index = 25, value = "", name = "wksN012EcCicloSdoProm", fieldType = DataType.DOUBLE, length = 12, decimales = 2, format = "")
	private double wksN012EcCicloSdoProm;
	
	/** wks N 012 ec year sdo prom. */
	@EntityModel(index = 26, value = "", name = "wksN012EcYearSdoProm", fieldType = DataType.DOUBLE, length = 12, decimales = 2, format = "")
	private double wksN012EcYearSdoProm;
	
	/** wks N 012 ec ciclo interes. */
	@EntityModel(index = 27, value = "", name = "wksN012EcCicloInteres", fieldType = DataType.DOUBLE, length = 12, decimales = 2, format = "")
	private double wksN012EcCicloInteres;
	
	/** wks N 012 ec year interes. */
	@EntityModel(index = 28, value = "", name = "wksN012EcYearInteres", fieldType = DataType.DOUBLE, length = 12, decimales = 2, format = "")
	private double wksN012EcYearInteres;
	
	/** wks N 012 ec ciclo rendim. */
	@EntityModel(index = 29, value = "", name = "wksN012EcCicloRendim", fieldType = DataType.DOUBLE, length = 3, decimales = 2, format = "")
	private double wksN012EcCicloRendim;
	
	/** wks N 012 ec ciclo rend bruto. */
	@EntityModel(index = 30, value = "", name = "wksN012EcCicloRendBruto", fieldType = DataType.DOUBLE, length = 3, decimales = 2, format = "")
	private double wksN012EcCicloRendBruto;
	
	/** wks N 012 ec year rendim. */
	@EntityModel(index = 31, value = "", name = "wksN012EcYearRendim", fieldType = DataType.DOUBLE, length = 3, decimales = 2, format = "")
	private double wksN012EcYearRendim;
	
	/** wks N 012 ec ciclo tax. */
	@EntityModel(index = 32, value = "", name = "wksN012EcCicloTax", fieldType = DataType.DOUBLE, length = 12, decimales = 2, format = "")
	private double wksN012EcCicloTax;
	
	/** wks N 012 ec cheq girados. */
	@EntityModel(index = 33, value = "", name = "wksN012EcCheqGirados", fieldType = DataType.VARCHAR, length = 6, decimales = 0, format = "")
	private String wksN012EcCheqGirados;
	
	/** wks N 012 ec cheq exentos. */
	@EntityModel(index = 34, value = "", name = "wksN012EcCheqExentos", fieldType = DataType.VARCHAR, length = 6, decimales = 0, format = "")
	private String wksN012EcCheqExentos;
	
	/** wks N 012 ec sigchcm. */
	@EntityModel(index = 35, value = "", name = "wksN012EcSigchcm", fieldType = DataType.VARCHAR, length = 16, decimales = 0, format = "")
	private String wksN012EcSigchcm;
	
	/** wks N 012 ec nummovs. */
	@EntityModel(index = 36, value = "", name = "wksN012EcNummovs", fieldType = DataType.INTEGER, length = 4, decimales = 0, format = "")
	private int wksN012EcNummovs;

	/**
	 * Set the fillero 1.
	 *
	 * @param parameter  fillero 1
	 */
	public void setFillero1( String parameter ) {
		fillero1 = parameter;
	}

	/**
	 * Gets the fillero 1.
	 *
	 * @return fillero1
	 */
	public String getFillero1() {
		return fillero1;
	}

	/**
	 * Set the wks N 012 ec result.
	 *
	 * @param parameter  wks N 012 ec result
	 */
	public void setWksN012EcResult( int parameter ) {
		wksN012EcResult = parameter;
	}

	/**
	 * Gets the wks N 012 ec result.
	 *
	 * @return wksN012EcResult
	 */
	public int getWksN012EcResult() {
		return wksN012EcResult;
	}

	/**
	 * Set the wks N 012 ec prod.
	 *
	 * @param parameter  wks N 012 ec prod
	 */
	public void setWksN012EcProd( int parameter ) {
		wksN012EcProd = parameter;
	}

	/**
	 * Gets the wks N 012 ec prod.
	 *
	 * @return wksN012EcProd
	 */
	public int getWksN012EcProd() {
		return wksN012EcProd;
	}

	/**
	 * Set the wks N 012 ec inst.
	 *
	 * @param parameter  wks N 012 ec inst
	 */
	public void setWksN012EcInst( int parameter ) {
		wksN012EcInst = parameter;
	}

	/**
	 * Gets the wks N 012 ec inst.
	 *
	 * @return wksN012EcInst
	 */
	public int getWksN012EcInst() {
		return wksN012EcInst;
	}

	/**
	 * Set the wks N 012 tra dt suc.
	 *
	 * @param parameter  wks N 012 tra dt suc
	 */
	public void setWksN012TraDtSuc( String parameter ) {
		wksN012TraDtSuc = parameter;
	}

	/**
	 * Gets the wks N 012 tra dt suc.
	 *
	 * @return wksN012TraDtSuc
	 */
	public String getWksN012TraDtSuc() {
		return wksN012TraDtSuc;
	}

	/**
	 * Set the wks N 012 tra dt cta.
	 *
	 * @param parameter  wks N 012 tra dt cta
	 */
	public void setWksN012TraDtCta( BigInteger parameter ) {
		wksN012TraDtCta = parameter;
	}

	/**
	 * Gets the wks N 012 tra dt cta.
	 *
	 * @return wksN012TraDtCta
	 */
	public BigInteger getWksN012TraDtCta() {
		return wksN012TraDtCta;
	}

	/**
	 * Set the wks nctl numcte.
	 *
	 * @param parameter  wks nctl numcte
	 */
	public void setWksNctlNumcte( BigInteger parameter ) {
		wksNctlNumcte = parameter;
	}

	/**
	 * Gets the wks nctl numcte.
	 *
	 * @return wksNctlNumcte
	 */
	public BigInteger getWksNctlNumcte() {
		return wksNctlNumcte;
	}

	/**
	 * Set the wks N 012 ec nomcte.
	 *
	 * @param parameter  wks N 012 ec nomcte
	 */
	public void setWksN012EcNomcte( String parameter ) {
		wksN012EcNomcte = parameter;
	}

	/**
	 * Gets the wks N 012 ec nomcte.
	 *
	 * @return wksN012EcNomcte
	 */
	public String getWksN012EcNomcte() {
		return wksN012EcNomcte;
	}

	/**
	 * Set the wks N 012 ec fecha corte.
	 *
	 * @param parameter  wks N 012 ec fecha corte
	 */
	public void setWksN012EcFechaCorte( int parameter ) {
		wksN012EcFechaCorte = parameter;
	}

	/**
	 * Gets the wks N 012 ec fecha corte.
	 *
	 * @return wksN012EcFechaCorte
	 */
	public int getWksN012EcFechaCorte() {
		return wksN012EcFechaCorte;
	}

	/**
	 * Set the wks N 012 ec fecha ultmov.
	 *
	 * @param parameter  wks N 012 ec fecha ultmov
	 */
	public void setWksN012EcFechaUltmov( int parameter ) {
		wksN012EcFechaUltmov = parameter;
	}

	/**
	 * Gets the wks N 012 ec fecha ultmov.
	 *
	 * @return wksN012EcFechaUltmov
	 */
	public int getWksN012EcFechaUltmov() {
		return wksN012EcFechaUltmov;
	}

	/**
	 * Set the wks N 012 ec fecha ini.
	 *
	 * @param parameter  wks N 012 ec fecha ini
	 */
	public void setWksN012EcFechaIni( int parameter ) {
		wksN012EcFechaIni = parameter;
	}

	/**
	 * Gets the wks N 012 ec fecha ini.
	 *
	 * @return wksN012EcFechaIni
	 */
	public int getWksN012EcFechaIni() {
		return wksN012EcFechaIni;
	}

	/**
	 * Set the wks N 012 ec fecha fin.
	 *
	 * @param parameter  wks N 012 ec fecha fin
	 */
	public void setWksN012EcFechaFin( int parameter ) {
		wksN012EcFechaFin = parameter;
	}

	/**
	 * Gets the wks N 012 ec fecha fin.
	 *
	 * @return wksN012EcFechaFin
	 */
	public int getWksN012EcFechaFin() {
		return wksN012EcFechaFin;
	}

	/**
	 * Set the wks N 012 ec sdo inicial.
	 *
	 * @param parameter  wks N 012 ec sdo inicial
	 */
	public void setWksN012EcSdoInicial( double parameter ) {
		wksN012EcSdoInicial = parameter;
	}

	/**
	 * Gets the wks N 012 ec sdo inicial.
	 *
	 * @return wksN012EcSdoInicial
	 */
	public double getWksN012EcSdoInicial() {
		return wksN012EcSdoInicial;
	}

	/**
	 * Set the wks N 012 ec sdo inisigno.
	 *
	 * @param parameter  wks N 012 ec sdo inisigno
	 */
	public void setWksN012EcSdoInisigno( String parameter ) {
		wksN012EcSdoInisigno = parameter;
	}

	/**
	 * Gets the wks N 012 ec sdo inisigno.
	 *
	 * @return wksN012EcSdoInisigno
	 */
	public String getWksN012EcSdoInisigno() {
		return wksN012EcSdoInisigno;
	}

	/**
	 * Set the wks N 012 ec abo num.
	 *
	 * @param parameter  wks N 012 ec abo num
	 */
	public void setWksN012EcAboNum( int parameter ) {
		wksN012EcAboNum = parameter;
	}

	/**
	 * Gets the wks N 012 ec abo num.
	 *
	 * @return wksN012EcAboNum
	 */
	public int getWksN012EcAboNum() {
		return wksN012EcAboNum;
	}

	/**
	 * Set the wks N 012 ec abo importe.
	 *
	 * @param parameter  wks N 012 ec abo importe
	 */
	public void setWksN012EcAboImporte( double parameter ) {
		wksN012EcAboImporte = parameter;
	}

	/**
	 * Gets the wks N 012 ec abo importe.
	 *
	 * @return wksN012EcAboImporte
	 */
	public double getWksN012EcAboImporte() {
		return wksN012EcAboImporte;
	}

	/**
	 * Set the wks N 012 ec car num.
	 *
	 * @param parameter  wks N 012 ec car num
	 */
	public void setWksN012EcCarNum( int parameter ) {
		wksN012EcCarNum = parameter;
	}

	/**
	 * Gets the wks N 012 ec car num.
	 *
	 * @return wksN012EcCarNum
	 */
	public int getWksN012EcCarNum() {
		return wksN012EcCarNum;
	}

	/**
	 * Set the wks N 012 ec car importe.
	 *
	 * @param parameter  wks N 012 ec car importe
	 */
	public void setWksN012EcCarImporte( double parameter ) {
		wksN012EcCarImporte = parameter;
	}

	/**
	 * Gets the wks N 012 ec car importe.
	 *
	 * @return wksN012EcCarImporte
	 */
	public double getWksN012EcCarImporte() {
		return wksN012EcCarImporte;
	}

	/**
	 * Set the wks N 012 ec sdo actual.
	 *
	 * @param parameter  wks N 012 ec sdo actual
	 */
	public void setWksN012EcSdoActual( double parameter ) {
		wksN012EcSdoActual = parameter;
	}

	/**
	 * Gets the wks N 012 ec sdo actual.
	 *
	 * @return wksN012EcSdoActual
	 */
	public double getWksN012EcSdoActual() {
		return wksN012EcSdoActual;
	}

	/**
	 * Set the wks N 012 ec sdo actsigno.
	 *
	 * @param parameter  wks N 012 ec sdo actsigno
	 */
	public void setWksN012EcSdoActsigno( String parameter ) {
		wksN012EcSdoActsigno = parameter;
	}

	/**
	 * Gets the wks N 012 ec sdo actsigno.
	 *
	 * @return wksN012EcSdoActsigno
	 */
	public String getWksN012EcSdoActsigno() {
		return wksN012EcSdoActsigno;
	}

	/**
	 * Set the wks N 012 ec lc importe.
	 *
	 * @param parameter  wks N 012 ec lc importe
	 */
	public void setWksN012EcLcImporte( String parameter ) {
		wksN012EcLcImporte = parameter;
	}

	/**
	 * Gets the wks N 012 ec lc importe.
	 *
	 * @return wksN012EcLcImporte
	 */
	public String getWksN012EcLcImporte() {
		return wksN012EcLcImporte;
	}

	/**
	 * Set the wks N 012 ec lc sdo.
	 *
	 * @param parameter  wks N 012 ec lc sdo
	 */
	public void setWksN012EcLcSdo( String parameter ) {
		wksN012EcLcSdo = parameter;
	}

	/**
	 * Gets the wks N 012 ec lc sdo.
	 *
	 * @return wksN012EcLcSdo
	 */
	public String getWksN012EcLcSdo() {
		return wksN012EcLcSdo;
	}

	/**
	 * Set the wks N 012 ec lc disp.
	 *
	 * @param parameter  wks N 012 ec lc disp
	 */
	public void setWksN012EcLcDisp( String parameter ) {
		wksN012EcLcDisp = parameter;
	}

	/**
	 * Gets the wks N 012 ec lc disp.
	 *
	 * @return wksN012EcLcDisp
	 */
	public String getWksN012EcLcDisp() {
		return wksN012EcLcDisp;
	}

	/**
	 * Set the wks N 012 ec ciclo dias.
	 *
	 * @param parameter  wks N 012 ec ciclo dias
	 */
	public void setWksN012EcCicloDias( int parameter ) {
		wksN012EcCicloDias = parameter;
	}

	/**
	 * Gets the wks N 012 ec ciclo dias.
	 *
	 * @return wksN012EcCicloDias
	 */
	public int getWksN012EcCicloDias() {
		return wksN012EcCicloDias;
	}

	/**
	 * Set the wks N 012 ec year dias.
	 *
	 * @param parameter  wks N 012 ec year dias
	 */
	public void setWksN012EcYearDias( int parameter ) {
		wksN012EcYearDias = parameter;
	}

	/**
	 * Gets the wks N 012 ec year dias.
	 *
	 * @return wksN012EcYearDias
	 */
	public int getWksN012EcYearDias() {
		return wksN012EcYearDias;
	}

	/**
	 * Set the wks N 012 ec ciclo sdo prom.
	 *
	 * @param parameter  wks N 012 ec ciclo sdo prom
	 */
	public void setWksN012EcCicloSdoProm( double parameter ) {
		wksN012EcCicloSdoProm = parameter;
	}

	/**
	 * Gets the wks N 012 ec ciclo sdo prom.
	 *
	 * @return wksN012EcCicloSdoProm
	 */
	public double getWksN012EcCicloSdoProm() {
		return wksN012EcCicloSdoProm;
	}

	/**
	 * Set the wks N 012 ec year sdo prom.
	 *
	 * @param parameter  wks N 012 ec year sdo prom
	 */
	public void setWksN012EcYearSdoProm( double parameter ) {
		wksN012EcYearSdoProm = parameter;
	}

	/**
	 * Gets the wks N 012 ec year sdo prom.
	 *
	 * @return wksN012EcYearSdoProm
	 */
	public double getWksN012EcYearSdoProm() {
		return wksN012EcYearSdoProm;
	}

	/**
	 * Set the wks N 012 ec ciclo interes.
	 *
	 * @param parameter  wks N 012 ec ciclo interes
	 */
	public void setWksN012EcCicloInteres( double parameter ) {
		wksN012EcCicloInteres = parameter;
	}

	/**
	 * Gets the wks N 012 ec ciclo interes.
	 *
	 * @return wksN012EcCicloInteres
	 */
	public double getWksN012EcCicloInteres() {
		return wksN012EcCicloInteres;
	}

	/**
	 * Set the wks N 012 ec year interes.
	 *
	 * @param parameter  wks N 012 ec year interes
	 */
	public void setWksN012EcYearInteres( double parameter ) {
		wksN012EcYearInteres = parameter;
	}

	/**
	 * Gets the wks N 012 ec year interes.
	 *
	 * @return wksN012EcYearInteres
	 */
	public double getWksN012EcYearInteres() {
		return wksN012EcYearInteres;
	}

	/**
	 * Set the wks N 012 ec ciclo rendim.
	 *
	 * @param parameter  wks N 012 ec ciclo rendim
	 */
	public void setWksN012EcCicloRendim( double parameter ) {
		wksN012EcCicloRendim = parameter;
	}

	/**
	 * Gets the wks N 012 ec ciclo rendim.
	 *
	 * @return wksN012EcCicloRendim
	 */
	public double getWksN012EcCicloRendim() {
		return wksN012EcCicloRendim;
	}

	/**
	 * Set the wks N 012 ec ciclo rend bruto.
	 *
	 * @param parameter  wks N 012 ec ciclo rend bruto
	 */
	public void setWksN012EcCicloRendBruto( double parameter ) {
		wksN012EcCicloRendBruto = parameter;
	}

	/**
	 * Gets the wks N 012 ec ciclo rend bruto.
	 *
	 * @return wksN012EcCicloRendBruto
	 */
	public double getWksN012EcCicloRendBruto() {
		return wksN012EcCicloRendBruto;
	}

	/**
	 * Set the wks N 012 ec year rendim.
	 *
	 * @param parameter  wks N 012 ec year rendim
	 */
	public void setWksN012EcYearRendim( double parameter ) {
		wksN012EcYearRendim = parameter;
	}

	/**
	 * Gets the wks N 012 ec year rendim.
	 *
	 * @return wksN012EcYearRendim
	 */
	public double getWksN012EcYearRendim() {
		return wksN012EcYearRendim;
	}

	/**
	 * Set the wks N 012 ec ciclo tax.
	 *
	 * @param parameter  wks N 012 ec ciclo tax
	 */
	public void setWksN012EcCicloTax( double parameter ) {
		wksN012EcCicloTax = parameter;
	}

	/**
	 * Gets the wks N 012 ec ciclo tax.
	 *
	 * @return wksN012EcCicloTax
	 */
	public double getWksN012EcCicloTax() {
		return wksN012EcCicloTax;
	}

	/**
	 * Set the wks N 012 ec cheq girados.
	 *
	 * @param parameter  wks N 012 ec cheq girados
	 */
	public void setWksN012EcCheqGirados( String parameter ) {
		wksN012EcCheqGirados = parameter;
	}

	/**
	 * Gets the wks N 012 ec cheq girados.
	 *
	 * @return wksN012EcCheqGirados
	 */
	public String getWksN012EcCheqGirados() {
		return wksN012EcCheqGirados;
	}

	/**
	 * Set the wks N 012 ec cheq exentos.
	 *
	 * @param parameter  wks N 012 ec cheq exentos
	 */
	public void setWksN012EcCheqExentos( String parameter ) {
		wksN012EcCheqExentos = parameter;
	}

	/**
	 * Gets the wks N 012 ec cheq exentos.
	 *
	 * @return wksN012EcCheqExentos
	 */
	public String getWksN012EcCheqExentos() {
		return wksN012EcCheqExentos;
	}

	/**
	 * Set the wks N 012 ec sigchcm.
	 *
	 * @param parameter  wks N 012 ec sigchcm
	 */
	public void setWksN012EcSigchcm( String parameter ) {
		wksN012EcSigchcm = parameter;
	}

	/**
	 * Gets the wks N 012 ec sigchcm.
	 *
	 * @return wksN012EcSigchcm
	 */
	public String getWksN012EcSigchcm() {
		return wksN012EcSigchcm;
	}

	/**
	 * Set the wks N 012 ec nummovs.
	 *
	 * @param parameter  wks N 012 ec nummovs
	 */
	public void setWksN012EcNummovs( int parameter ) {
		wksN012EcNummovs = parameter;
	}

	/**
	 * Gets the wks N 012 ec nummovs.
	 *
	 * @return wksN012EcNummovs
	 */
	public int getWksN012EcNummovs() {
		return wksN012EcNummovs;
	}
	
	/** output detail. */
	private List<GroupOccurs> outputDetail = new ArrayList<>();

	/**
	 * Gets the output detail.
	 *
	 * @return output detail
	 */
	public List<GroupOccurs> getOutputDetail() {
		return outputDetail;
	}

	/**
	 * Set the output detail.
	 *
	 * @param outputDetail  output detail
	 */
	public void setOutputDetail(List<GroupOccurs> outputDetail) {
		this.outputDetail = outputDetail;
	}
} // Consmultmovtosimpfissa2OutputOk
