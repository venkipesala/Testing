/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckMovementsException.java
 * Original Author: ENLM
 * Creation Date: 1/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.exception;

import com.citi.query.model.MaccountChecksCommonError;

/**
 *  <code>MaccountCheckMovementsException</code>.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckMovementsException extends Exception {

	/** The constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** query error. */
	private transient MaccountChecksCommonError queryError;

	/**
	 * Creates a new instance of maccount check movements exception.
	 *
	 * @param queryError query error
	 */
	public MaccountCheckMovementsException(MaccountChecksCommonError queryError) {
		super(queryError.getFiller4());
		this.setQueryError(queryError);

	}

	/**
	 * Gets the query error.
	 *
	 * @return query error
	 */
	public MaccountChecksCommonError getQueryError() {
		return queryError;
	}

	/**
	 * Set the query error.
	 *
	 * @param queryError  query error
	 */
	public void setQueryError(MaccountChecksCommonError queryError) {
		this.queryError = queryError;
	}

}
