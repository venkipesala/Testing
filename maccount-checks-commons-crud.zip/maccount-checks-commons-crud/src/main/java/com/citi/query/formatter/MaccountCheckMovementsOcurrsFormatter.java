/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckMovementsOcurrsFormatter.java
 * Original Author: Softtek
 * Creation Date: 10/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.formatter;

import com.citi.query.model.GroupOccurs;
import com.citi.query.response.InnerOcurrs;

import ma.glasnost.orika.BoundMapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * The Class MaccountCheckNextMovementsOcurrsFormatter.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckMovementsOcurrsFormatter {
	
	/** The Constant MAPPER_FACTORY. */
	private static final MapperFactory MAPPER_FACTORY = new DefaultMapperFactory.Builder().build();

	/** The mediator. */
	private BoundMapperFacade<GroupOccurs,InnerOcurrs> mediator;

	/**
	 * Instantiates a new maccount check next movements ocurrs formatter.
	 */
	public MaccountCheckMovementsOcurrsFormatter() {
		
		MAPPER_FACTORY.classMap(GroupOccurs.class, InnerOcurrs.class)
				.field("wksN012EcMovCiclo", "cycleCount")
				.field("wksN012EcMovFecha", "transactionDate")
				.field("wksN012EcMovSig", "sequenceNumber")
				.field("wksN012EcMovConcept", "description")
				.field("wksN012EcMovSigno", "signAmount")
				.field("wksN012EcMovImporte", "transactionAmount")
				.field("wksN012EcReferenciaNum", "referenceNumber")
				.field("wksN012EcNumAut", "authorizationNumber")
				.field("wksN012EcMovSignoImp", "signAmountAfter")
				.field("wksN012EcMovImpDesTrx", "transactionAmountAfter")
				.register();
		
		
		this.mediator = MAPPER_FACTORY.getMapperFacade(GroupOccurs.class,InnerOcurrs.class);
	}
	
	/**
	 * Format to response.
	 *
	 * @param queryOutputOk the query output ok
	 * @return the inner ocurrs
	 */
	public InnerOcurrs formatToResponse(GroupOccurs queryOutputOk) {

		return this.mediator.map(queryOutputOk);

	}
}
