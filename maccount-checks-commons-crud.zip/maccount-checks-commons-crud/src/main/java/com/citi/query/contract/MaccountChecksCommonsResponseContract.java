/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksCommonsResponseContract.java
 * Original Author: Softtek
 * Creation Date: 2/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.contract;

import java.io.Serializable;

import com.citi.query.model.MaccountChecksCommonError;
import com.citi.query.response.MaccountCheckBeforeBalanceResponse;
import com.citi.query.response.MaccountCheckMovementsResponse;
import com.citi.query.response.MaccountChecksAfterBalanceResponse;
import com.citi.unisys.model.HeaderBnmx;
import com.citi.unisys.model.HeaderSa2;

/**
 * The Class MaccountChecksCommonsResponseContract.
 */
public class MaccountChecksCommonsResponseContract implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6951923336635121162L;

	/** The header bnmx. */
	private HeaderBnmx headerBnmx;

	/** The header sa 2. */
	private HeaderSa2 headerSa2;

	/** The commun error. */
	private MaccountChecksCommonError communError;

	/** The maccount checks commons response. */
//	private Object maccountChecksCommonsResponse;
	
	private MaccountCheckBeforeBalanceResponse beforeResponse;
	
	private MaccountCheckMovementsResponse movementsResponse;
	
	private MaccountChecksAfterBalanceResponse afterResponse;

	/**
	 * Gets the header bnmx.
	 *
	 * @return the header bnmx
	 */
	public HeaderBnmx getHeaderBnmx() {
		return headerBnmx;
	}

	/**
	 * Sets the header bnmx.
	 *
	 * @param headerBnmx
	 *            the new header bnmx
	 */
	public void setHeaderBnmx(HeaderBnmx headerBnmx) {
		this.headerBnmx = headerBnmx;
	}

	/**
	 * Gets the header sa 2.
	 *
	 * @return the header sa 2
	 */
	public HeaderSa2 getHeaderSa2() {
		return headerSa2;
	}

	/**
	 * Sets the header sa 2.
	 *
	 * @param headerSa2
	 *            the new header sa 2
	 */
	public void setHeaderSa2(HeaderSa2 headerSa2) {
		this.headerSa2 = headerSa2;
	}

	/**
	 * Gets the maccount checks commons response.
	 *
	 * @return the maccount checks commons response
	 */
//	public Object getMaccountChecksCommonsResponse() {
//		return maccountChecksCommonsResponse;
//	}

	/**
	 * Sets the maccount checks commons response.
	 *
	 * @param maccountChecksCommonsResponse
	 *            the new maccount checks commons response
	 */
//	public void setMaccountChecksCommonsResponse(Object maccountChecksCommonsResponse) {
//		this.maccountChecksCommonsResponse = maccountChecksCommonsResponse;
//	}

	/**
	 * Gets the commun error.
	 *
	 * @return the commun error
	 */
	public MaccountChecksCommonError getCommunError() {
		return communError;
	}

	/**
	 * Sets the commun error.
	 *
	 * @param communError
	 *            the new commun error
	 */
	public void setCommunError(MaccountChecksCommonError communError) {
		this.communError = communError;
	}

	public MaccountCheckBeforeBalanceResponse getBeforeResponse() {
		return beforeResponse;
	}

	public void setBeforeResponse(MaccountCheckBeforeBalanceResponse beforeResponse) {
		this.beforeResponse = beforeResponse;
	}

	public MaccountCheckMovementsResponse getMovementsResponse() {
		return movementsResponse;
	}

	public void setMovementsResponse(MaccountCheckMovementsResponse movementsResponse) {
		this.movementsResponse = movementsResponse;
	}

	public MaccountChecksAfterBalanceResponse getAfterResponse() {
		return afterResponse;
	}

	public void setAfterResponse(MaccountChecksAfterBalanceResponse afterResponse) {
		this.afterResponse = afterResponse;
	}

}
