/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckCommonRequest.java
 * Original Author: Softtek
 * Creation Date: 15/02/2017
 * ---------------------------------------------------------------------------
 */

package com.citi.query.request;

import java.math.BigInteger;


/**
 * The Class ConMovCtaMaeContRequest.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckCommonRequest {
		
	/** The csi. */
	private int csi;
	
	/** The branch number. */
	private int branchNumber;
	
	/** The cash code. */
	private int cashCode;
	
	/** The system reference. */
	private int systemReference;
	
	/** The reference type. */
	private int referenceType;
	
	/** The product ID. */
	private int productID;
	
	/** The instrument ID. */
	private int instrumentID;
	
	/** The branch ID. */
	private int branchID;
	
	/** The account number. */
	private BigInteger accountNumber;
	
	/** The option 43. */
	private int optionNumber;
	                    
	/** The quantity number. */
	private int  quantityNumber;
	
	/** The next movement. */
	private String nextMovement;
	
	/** The subcode. */
	private int subcode;
	
	/** The channel id **/
	private int channelId;
	
	/**
	 * Gets the product ID.
	 *
	 * @return the product ID
	 */
	public int getProductID() {
		return productID;
	}

	/**
	 * Sets the product ID.
	 *
	 * @param productID the new product ID
	 */
	public void setProductID(int productID) {
		this.productID = productID;
	}

	/**
	 * Gets the instrument ID.
	 *
	 * @return the instrument ID
	 */
	public int getInstrumentID() {
		return instrumentID;
	}

	/**
	 * Sets the instrument ID.
	 *
	 * @param instrumentID the new instrument ID
	 */
	public void setInstrumentID(int instrumentID) {
		this.instrumentID = instrumentID;
	}

	/**
	 * Gets the branch ID.
	 *
	 * @return the branch ID
	 */
	public int getBranchID() {
		return branchID;
	}

	/**
	 * Sets the branch ID.
	 *
	 * @param branchID the new branch ID
	 */
	public void setBranchID(int branchID) {
		this.branchID = branchID;
	}

	/**
	 * Gets the account number.
	 *
	 * @return the account number
	 */
	public BigInteger getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the new account number
	 */
	public void setAccountNumber(BigInteger accountNumber) {
		this.accountNumber = accountNumber;
	}


	/**
	 * Gets the quantity number.
	 *
	 * @return the quantity number
	 */
	public int getQuantityNumber() {
		return quantityNumber;
	}

	/**
	 * Sets the quantity number.
	 *
	 * @param quantityNumber the new quantity number
	 */
	public void setQuantityNumber(int quantityNumber) {
		this.quantityNumber = quantityNumber;
	}

	/**
	 * Gets the next movement.
	 *
	 * @return the next movement
	 */
	public String getNextMovement() {
		return nextMovement;
	}

	/**
	 * Sets the next movement.
	 *
	 * @param nextMovement the new next movement
	 */
	public void setNextMovement(String nextMovement) {
		this.nextMovement = nextMovement;
	}


		  
	/**
	 * Gets the csi.
	 *
	 * @return the csi
	 */
	public int getCsi() {
		return csi;
	}

	/**
	 * Sets the csi.
	 *
	 * @param csi the new csi
	 */
	public void setCsi(int csi) {
		this.csi = csi;
	}

	/**
	 * Gets the branch number.
	 *
	 * @return the branch number
	 */
	public int getBranchNumber() {
		return branchNumber;
	}

	/**
	 * Sets the branch number.
	 *
	 * @param branchNumber the new branch number
	 */
	public void setBranchNumber(int branchNumber) {
		this.branchNumber = branchNumber;
	}

	/**
	 * Gets the cash code.
	 *
	 * @return the cash code
	 */
	public int getCashCode() {
		return cashCode;
	}

	/**
	 * Sets the cash code.
	 *
	 * @param cashCode the new cash code
	 */
	public void setCashCode(int cashCode) {
		this.cashCode = cashCode;
	}


	/**
	 * Gets the system reference.
	 *
	 * @return the system reference
	 */
	public int getSystemReference() {
		return systemReference;
	}

	/**
	 * Sets the system reference.
	 *
	 * @param systemReference the new system reference
	 */
	public void setSystemReference(int systemReference) {
		this.systemReference = systemReference;
	}

	/**
	 * Gets the reference type.
	 *
	 * @return the reference type
	 */
	public int getReferenceType() {
		return referenceType;
	}

	/**
	 * Sets the reference type.
	 *
	 * @param referenceType the new reference type
	 */
	public void setReferenceType(int referenceType) {
		this.referenceType = referenceType;
	}
	
	
	/**
	 * Gets the option number.
	 *
	 * @return the option number
	 */
	public int getOptionNumber() {
		return optionNumber;
	}

	/**
	 * Sets the option number.
	 *
	 * @param optionNumber the new option number
	 */
	public void setOptionNumber(int optionNumber) {
		this.optionNumber = optionNumber;
	}

	/**
	 * Gets the subcode.
	 *
	 * @return the subcode
	 */
	public int getSubcode() {
		return subcode;
	}

	/**
	 * Sets the subcode.
	 *
	 * @param subcode the new subcode
	 */
	public void setSubcode(int subcode) {
		this.subcode = subcode;
	}

	public int getChannelId() {
		return channelId;
	}

	public void setChannelId(int channelId) {
		this.channelId = channelId;
	}

}
