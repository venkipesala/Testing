/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksCommonResponseRead.java
 * Original Author: Softtek
 * Creation Date: 2/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.aggregator.reader;

import com.softtek.legacy.framework.model.DataElementFormatException;
import com.softtek.legacy.framework.parser.ParserException;

/**
 * The Interface MaccountChecksCommonResponseRead.
 */
@FunctionalInterface
public interface MaccountChecksCommonResponseRead {
	
	/**
	 * Read response.
	 *
	 * @param bufferOutput the buffer output
	 * @return the object
	 * @throws DataElementFormatException the data element format exception
	 * @throws ParserException the parser exception
	 */
	public Object readResponse(String bufferOutput) throws DataElementFormatException, ParserException;
}
