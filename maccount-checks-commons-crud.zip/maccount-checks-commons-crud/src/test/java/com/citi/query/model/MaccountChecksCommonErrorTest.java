/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksCommonErrorTest.java
 * Original Author: ENLM
 * Creation Date: 1/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.model;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.softtek.legacy.framework.model.DataElementFormatException;
import com.softtek.legacy.framework.parser.ParserException;
import com.softtek.legacy.framework.util.BufferToEntity;
import com.softtek.legacy.framework.util.Builder;

/**
 * The Class ConMovCtaMaeContErrorTest.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountChecksCommonErrorTest {
	
	/** The con mov cta mae cont error. */
	MaccountChecksCommonError conMovCtaMaeContError = new MaccountChecksCommonError();
	
	 
	
	/**
	 * Inits the data.
	 */
	@Before
	public void initData() {
		conMovCtaMaeContError.setWksN012EcResult(12);
		conMovCtaMaeContError.setFiller4("ERROR ");	
	}

	
	/**
	 * Should get error model values from buffer.
	 *
	 * @throws DataElementFormatException the data element format exception
	 * @throws ParserException the parser exception
	 */
	@Test
    public void shouldGetErrorModelValuesFromBuffer() throws DataElementFormatException, ParserException{
		
		String mensajeError = "ERROR 12";
		        
		MaccountChecksCommonError responseError = new MaccountChecksCommonError();

        Builder buf2Ent = new BufferToEntity(mensajeError, responseError);
        buf2Ent.build();
        
        assertEquals(conMovCtaMaeContError.getWksN012EcResult(), responseError.getWksN012EcResult());
        assertEquals(conMovCtaMaeContError.getFiller4() , responseError.getFiller4());
    }
}
