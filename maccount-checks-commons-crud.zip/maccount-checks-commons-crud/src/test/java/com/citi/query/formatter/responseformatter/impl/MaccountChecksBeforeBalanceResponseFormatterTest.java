package com.citi.query.formatter.responseformatter.impl;

import static org.junit.Assert.assertNotNull;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.model.GroupOccurs;
import com.citi.query.model.MaccountCheckBeforeBalanceOutputOk;

public class MaccountChecksBeforeBalanceResponseFormatterTest {
	MaccountCheckBeforeBalanceOutputOk beforeOutput = new MaccountCheckBeforeBalanceOutputOk();
	MaccountChecksBeforeBalanceResponseFormatter responseFormatter = new MaccountChecksBeforeBalanceResponseFormatter();
	
	@Before
	public void initData(){
		beforeOutput.setFillero1("Fill");
		beforeOutput.setWksN012EcAboImporte(2.2);
		beforeOutput.setWksN012EcAboNum(3);
		beforeOutput.setWksN012EcCarImporte(4.4);
		beforeOutput.setWksN012EcCarNum(5);
		beforeOutput.setWksN012EcCheqExentos("6");
		beforeOutput.setWksN012EcCheqGirados("7");
		beforeOutput.setWksN012EcCicloDias(8);
		beforeOutput.setWksN012EcCicloInteres(9.9);
		beforeOutput.setWksN012EcCicloRendBruto(10.10);
		beforeOutput.setWksN012EcCicloRendim(11.11);
		beforeOutput.setWksN012EcCicloSdoProm(12.12);
		beforeOutput.setWksN012EcCicloTax(13.13);
		beforeOutput.setWksN012EcFechaCorte(14);
		beforeOutput.setWksN012EcFechaFin(15);
		beforeOutput.setWksN012EcFechaIni(16);
		beforeOutput.setWksN012EcFechaUltmov(17);
		beforeOutput.setWksN012EcInst(18);
		beforeOutput.setWksN012EcLcDisp("19.19");
		beforeOutput.setWksN012EcLcImporte("20.20");
		beforeOutput.setWksN012EcLcSdo("21");
		beforeOutput.setWksN012EcNomcte("nom");
		beforeOutput.setWksN012EcNummovs(15);
		beforeOutput.setWksN012EcProd(22);
		beforeOutput.setWksN012EcResult(23);
		beforeOutput.setWksN012EcSdoActsigno("-");
		beforeOutput.setWksN012EcSdoActual(25.25);
		beforeOutput.setWksN012EcSdoInicial(26.26);
		beforeOutput.setWksN012EcSigchcm("+");
		beforeOutput.setWksN012EcYearDias(28);
		beforeOutput.setWksN012EcYearInteres(29);
		beforeOutput.setWksN012EcYearRendim(30);
		beforeOutput.setWksN012EcYearSdoProm(31);
		beforeOutput.setWksN012TraDtCta(BigInteger.valueOf(32));
		beforeOutput.setWksN012TraDtSuc("33");
		beforeOutput.setWksNctlNumcte(BigInteger.valueOf(34));
		
		List<GroupOccurs> listOccurs = new ArrayList<>();
		for(int x = 0; x < 15; x++){
			GroupOccurs occurs = new GroupOccurs();
			occurs.setWksN012EcMovCiclo(1);
			occurs.setWksN012EcMovConcept("2");
			occurs.setWksN012EcMovCiclo(3);
			occurs.setWksN012EcMovImpDesTrx(4.4);
			occurs.setWksN012EcMovImporte(5.5);
			occurs.setWksN012EcMovSig(6);
			occurs.setWksN012EcMovSigno("7");
			occurs.setWksN012EcMovSignoImp("8");
			occurs.setWksN012EcNumAut(9);
			occurs.setWksN012EcReferenciaNum("10");
			listOccurs.add(occurs);
		}
		beforeOutput.setOutputDetail(listOccurs);
		
	}
	
	@Test
	public void shouldVerifyFormatToResponse(){
		assertNotNull(responseFormatter.formatToResponse(beforeOutput));
	}
}
