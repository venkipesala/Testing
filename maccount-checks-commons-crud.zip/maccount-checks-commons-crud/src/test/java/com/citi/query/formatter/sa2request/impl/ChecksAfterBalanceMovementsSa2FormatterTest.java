package com.citi.query.formatter.sa2request.impl;

import static org.junit.Assert.assertNotNull;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

import com.banamex.nga.gemfire.cache.stationame.beans.StationName;
import com.citi.query.formatter.sa2request.Sa2RequestFormatter;
import com.citi.query.request.MaccountCheckCommonRequest;

public class ChecksAfterBalanceMovementsSa2FormatterTest {
	
	Sa2RequestFormatter balanceFormatter = new ChecksAfterBalanceMovementsSa2Formatter();
	MaccountCheckCommonRequest request = new MaccountCheckCommonRequest();
	StationName stationName;

	@Before
	public void initData() {

		request.setAccountNumber(BigInteger.valueOf(1));
		request.setBranchID(2);
		request.setBranchNumber(3);
		request.setCashCode(4);
		request.setCsi(5);
		request.setInstrumentID(8);
		request.setNextMovement("Next");
		request.setOptionNumber(10);
		request.setProductID(11);
		request.setQuantityNumber(12);
		request.setReferenceType(13);
		request.setSystemReference(17);

	}

	@Test
	public void shoud() {
		assertNotNull(balanceFormatter.formatHeaderBnmx(request, stationName));
		assertNotNull(balanceFormatter.formatHeaderSa2(request));
		assertNotNull(balanceFormatter.formatToInputModel(request));

	}

}
