/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckMovementsOcurrsFormatterTest.java
 * Original Author: ENLM
 * Creation Date: 1/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.formatter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.model.GroupOccurs;
import com.citi.query.response.InnerOcurrs;

/**
 *  <code>MaccountCheckMovementsOcurrsFormatterTest</code>.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckMovementsOcurrsFormatterTest {

	/** query formatter. */
	MaccountCheckMovementsOcurrsFormatter queryFormatter = new MaccountCheckMovementsOcurrsFormatter();
	
	/** model output ok. */
	MaccountCheckMovementsOutputFormatter modelOutputOk = new MaccountCheckMovementsOutputFormatter();

	/** gpo occurs. */
	GroupOccurs gpoOccurs = new GroupOccurs();

	/**
	 * Inits the data.
	 */
	@Before
	public void initData() {

		gpoOccurs.setWksN012EcMovCiclo(1);
		gpoOccurs.setWksN012EcMovFecha(160830);
		gpoOccurs.setWksN012EcMovSig(00000011);
		gpoOccurs.setWksN012EcMovConcept("DEPOSITO P/TRASPASO°°°°°°°°°°°°°°°°°°°°");
		gpoOccurs.setWksN012EcMovSigno(" ");
		gpoOccurs.setWksN012EcMovImporte(9000);
		gpoOccurs.setWksN012EcReferenciaNum("0000000000000000");
		gpoOccurs.setWksN012EcNumAut(1194);
		gpoOccurs.setWksN012EcMovSignoImp(" ");
		gpoOccurs.setWksN012EcMovImpDesTrx(9000);

	}

	/**
	 * Should verify con mov cta mae cont ocurrs formatter.
	 */
	@Test
	public void shouldVerifyConMovCtaMaeContOcurrsFormatter() {

		InnerOcurrs innerOccurs = queryFormatter.formatToResponse(gpoOccurs);
		assertEquals(1, innerOccurs.getCycleCount());
		assertEquals(160830, innerOccurs.getTransactionDate());
		assertEquals(00000011, innerOccurs.getSequenceNumber());
		assertEquals("DEPOSITO P/TRASPASO°°°°°°°°°°°°°°°°°°°°", innerOccurs.getDescription());
		assertEquals(" ", innerOccurs.getSignAmount());
		assertTrue(Math.abs(9000- innerOccurs.getTransactionAmount()) == 0);
		assertEquals("0000000000000000", innerOccurs.getReferenceNumber());
		assertEquals(1194, innerOccurs.getAuthorizationNumber());
		assertEquals(" ", innerOccurs.getSignAmountAfter());
		assertTrue(Math.abs(9000- innerOccurs.getTransactionAmountAfter()) == 0);
	}

}
