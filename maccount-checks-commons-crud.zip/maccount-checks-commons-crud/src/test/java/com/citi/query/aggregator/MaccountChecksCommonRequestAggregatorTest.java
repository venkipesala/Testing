package com.citi.query.aggregator;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.contract.MaccountCheckCommonContractRequest;
import com.citi.query.formatter.MaccountCheckCommonRequestFormatter;
import com.citi.query.request.MaccountCheckCommonRequest;
import com.softtek.legacy.framework.model.DataElementFormatException;
import com.softtek.legacy.framework.parser.ParserException;

public class MaccountChecksCommonRequestAggregatorTest {
	

	/** contract. */
	MaccountCheckCommonContractRequest contract;
	

	
	MaccountCheckCommonRequest request =
            new MaccountCheckCommonRequest();
	
//	@Mock
	MaccountCheckCommonRequestFormatter requestFormatter = new MaccountCheckCommonRequestFormatter();
	
	/** input aggregator. */
	
	MaccountChecksCommonRequestAggregator inputAggregator;

	/**
     * Initial data.
     */
    @Before
    public void initialData() {
    	 


    	
    	request.setAccountNumber(BigInteger.valueOf(415263745008L));
    	request.setBranchID(1);
    	request.setInstrumentID(4);
    	request.setNextMovement("Next");
    	request.setOptionNumber(41);
    	request.setProductID(7);
    	request.setQuantityNumber(15);
    	request.setReferenceType(8);
    	request.setSystemReference(10);
        request.setCsi(10);
        request.setBranchNumber(870);
        request.setCashCode(71);
        
//        MockitoAnnotations.initMocks(this);
//        when(requestFormatter.getStationName()).thenReturn("Y0850A63");
        contract =  requestFormatter.format(request, 811);
        inputAggregator = new MaccountChecksCommonRequestAggregator(contract);
    }

	/**
	 * Should generate input model buffer request to unisys.
	 *
	 * @throws DataElementFormatException
	 *             data element format exception.
	 * @throws ParserException
	 *             parser exception.
	 */
	@Test
	public void shouldGenerateInputModelBufferRequestToUnisys() throws Throwable {

		String bufferResult = inputAggregator.createInputBuffer();
		String bufferHeaderBnmx = bufferResult.substring(0, 48);
		String bufferHeaderSa2 = bufferResult.substring(47, 100);
		String bufferData = bufferResult.substring(125);

		String headerBnmxExpected = "F0100000Y0870D711000   02           005014001512";
		String headerSa2Expected = "2005000811001500811102780006001000B0010870A7108000010";
		String inputDataExpected = "0MS066000700040001415263745008430015Next                        00";

		assertEquals(191, bufferResult.length());
		assertEquals(headerBnmxExpected, bufferHeaderBnmx);
		assertEquals(headerSa2Expected, bufferHeaderSa2);
		assertEquals(inputDataExpected, bufferData);
	}
}
