package com.citi.query.contract;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.model.MaccountChecksCommonError;

public class MaccountChecksCommonsResponseContractTest {
	MaccountChecksCommonError commonError = new MaccountChecksCommonError();
	MaccountChecksCommonsResponseContract responseContract = new MaccountChecksCommonsResponseContract();
	
	@Before
	public void initData(){
		commonError.setFiller4("Fill");
		commonError.setWksN012EcResult(2);
		responseContract.setCommunError(commonError);
	}
	
	@Test
	public void shouldVerifyCommonError(){
		assertEquals("Fill", responseContract.getCommunError().getFiller4());
		assertEquals(2, responseContract.getCommunError().getWksN012EcResult());
		
	}

}
