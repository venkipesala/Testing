/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckMovementsOutputFormatterTest.java
 * Original Author: ENLM
 * Creation Date: 1/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.formatter;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.model.MaccounChecksMovementsOutputOk;
import com.citi.query.response.MaccountCheckMovementsResponse;
import com.citi.unisys.model.HeaderBnmx;
import com.citi.unisys.model.HeaderSa2;

/**
 *  <code>MaccountCheckMovementsOutputFormatterTest</code>.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckMovementsOutputFormatterTest {

	/** query formatter. */
	MaccountCheckMovementsOutputFormatter queryFormatter = new MaccountCheckMovementsOutputFormatter();
	
	/** query output. */
	MaccounChecksMovementsOutputOk queryOutput = new MaccounChecksMovementsOutputOk();

    /** header bnmx. */
    HeaderBnmx headerBnmx = new HeaderBnmx();
    
    /** header sa 2. */
    HeaderSa2 headerSa2 = new HeaderSa2();
	
    /**
     * Inits the data.
     */
    @Before
    public void initData() {

        queryOutput.setFiller3("A");;
        queryOutput.setWksN012EcResult(2);
        queryOutput.setWksN012EcProd(1);
        queryOutput.setWksN012EcInst(0);
        queryOutput.setWksN012TraDtSuc("    ");
        queryOutput.setWksN012TraDtCta(BigInteger.valueOf(234567));
        queryOutput.setWksN012EcSigchcm("B");
        queryOutput.setWksN012EcNummovs(4);
 

    }

    /**
     * Should verify query con mov cta mae cont response formatter.
     */
    @Test
    public void shouldVerifyQueryConMovCtaMaeContResponseFormatter() {

    	MaccountCheckMovementsResponse queryResponse = new MaccountCheckMovementsResponse();

        queryResponse = queryFormatter.formatToResponse(queryOutput);

        assertEquals("A", queryResponse.getSuffix());
        assertEquals(2, queryResponse.getResultZeros());
        assertEquals(1, queryResponse.getProductID());
        assertEquals(0, queryResponse.getInstrumentID());
        assertEquals("    ", queryResponse.getBranchID());
        assertEquals(BigInteger.valueOf(234567), queryResponse.getAccountNumber());
        assertEquals("B", queryResponse.getNextMovement());
        assertEquals(4, queryResponse.getQuantityNumber());
    }
}
