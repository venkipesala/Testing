package com.citi.query.validator;

import static org.junit.Assert.assertTrue;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.exception.MaccountChecksCommonException;
import com.citi.query.request.MaccountCheckCommonRequest;


public class MaccountCheckCommonValidatorRequestTest {

	MaccountCheckCommonRequest request = new MaccountCheckCommonRequest();
		
	@Before
	public void initData(){
		request.setAccountNumber(new BigInteger("009050469752"));
		request.setBranchID(4567);
		request.setProductID(4597);
		request.setInstrumentID(7890);
		request.setOptionNumber(41);	
	}

	
	@Test
	public void shouldVerifyValidate(){
		
		MaccountCheckCommonValidatorRequest validator = new MaccountCheckCommonValidatorRequest();
		
		
		 boolean thrown = false;
		
	 	  try {
	 		 validator.validate(request);
		 	    thrown = true;
		 
		 	  } catch (MaccountChecksCommonException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		 	  assertTrue(thrown);	
		
		
	}
	
	@Test
	public void shouldVerifyValidateExeption(){
		
		MaccountCheckCommonValidatorRequest validator = new MaccountCheckCommonValidatorRequest();
		
		request.setOptionNumber(545);
		 boolean thrown = false;
		
	 	  try {
	 		 validator.validate(request);
		 
		 	  } catch (MaccountChecksCommonException e) {
			 	    thrown = true;
			}
	
		 	  assertTrue(thrown);	
		
		
	}
	
	
}
	
	
	
	
		
