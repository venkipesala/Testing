package com.citi.query.response;


import static org.junit.Assert.assertEquals;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class MaccountCheckBeforeBalanceResponseTest {
	MaccountCheckBeforeBalanceResponse response = new MaccountCheckBeforeBalanceResponse();
	
	@Before
	public void initialData() {
		response.setSuffix("FR906");
		response.setResultZeros(60);
		response.setProductID(0066);
		response.setInstrumentID(4);
		response.setBranchID("    ");
		response.setAccountNumber(new BigInteger("512567690000"));

		response.setCustomerId(new BigInteger("000033664238"));
		response.setCustomerName("HECTOR EFREN LOZANO GONZALEZ");
		response.setCutoffDay(150704);
		response.setLastAccessDate(150722);
		response.setStartDate(150701);
		response.setStopDate(150704);
		response.setBalanceStartAmount(000000820394.59d);
		response.setSignBalanceStartAmount("S");
		response.setEntrySequenceNumber(000161);
		response.setDepositDueAmount(000000013193.00d);
		response.setOutSequenceNumber(000012);
		response.setChargeOffAmount(000000000584.80d);
		response.setBalanceAmount(000000834020.21d);
		response.setSignBalanceAmount("S");
		response.setFinancialCreditLineAmount(123456789012.34d);
		response.setCreditUsedAmount(123456789012.34d);
		response.setCreditAvailableAmount(123456789012.34d);
		response.setDaysOftheCycle(30);
		response.setDaysOftheYear(185);
		response.setCycleAverageBalanceAmount(000000947839.21d);
		response.setYearAverageBalanceAmount(000001059099.56d);
		response.setInterestPayCycleDay(00000000101742);
		response.setInterestPayCycleYear(000000008569.99d);
		response.setAnnualPercentageCycle(001.28d);
		response.setAnnualPercentageYield(001.80d);
		response.setPeriodRate(000.80d);
		response.setDestinationCountryTaxAmount(00000000040434);
		response.setDeliveryReferenceNumber("123456");
		response.setAuthorizedUserWaiverDurationNumber("654321");

		response.setNextMovement("0015063000000051");
		response.setQuantityNumber(0015);	

		InnerOcurrs detail = new InnerOcurrs();
				detail.setCycleCount(00);
				detail.setTransactionDate(150605);
				detail.setSequenceNumber(00000011);
				detail.setDescription("DEPOSITO P/TRASPASO°°°°°°°°°°°");
				detail.setSignAmount("S");
				detail.setTransactionAmount(00000000010000);
				detail.setReferenceNumber("0000000000000000");
				detail.setAuthorizationNumber(1128);
				detail.setSignAmountAfter("S");
				detail.setTransactionAmountAfter(000000820494.59d);
		List<InnerOcurrs> listDetail = new ArrayList<>();
		listDetail.add(detail);
		response.setGpogroupOccurs(listDetail);	
	
	}
	
	@Test
	public void shouldGetResponseValues(){

		assertEquals("FR906", response.getSuffix());

		assertEquals(60,response.getResultZeros());
		assertEquals(0066,	response.getProductID());
		assertEquals(4,	response.getInstrumentID());
		assertEquals("    ",	response.getBranchID());
		assertEquals(new BigInteger("512567690000"),	response.getAccountNumber());
			
		assertEquals(new BigInteger("000033664238"),	response.getCustomerId());
		assertEquals("HECTOR EFREN LOZANO GONZALEZ",	response.getCustomerName());
		assertEquals(150704,	response.getCutoffDay());
		assertEquals(150722,	response.getLastAccessDate());
		assertEquals(150701,	response.getStartDate());
		assertEquals(150704,	response.getStopDate());
		assertEquals(000000820394.59d,	response.getBalanceStartAmount(),0);
		assertEquals("S",	response.getSignBalanceStartAmount());
		assertEquals(000161,	response.getEntrySequenceNumber());
		assertEquals(000000013193.00d,	response.getDepositDueAmount(),0);
		assertEquals(000012,	response.getOutSequenceNumber());
		assertEquals(000000000584.80d,	response.getChargeOffAmount(),0);
		assertEquals(000000834020.21d,	response.getBalanceAmount(),0);
		assertEquals("S",	response.getSignBalanceAmount());
		assertEquals(123456789012.34d,	response.getFinancialCreditLineAmount(),0);
		assertEquals(123456789012.34d,	response.getCreditUsedAmount(),0);
		assertEquals(123456789012.34d,	response.getCreditAvailableAmount(),0);
		assertEquals(30,	response.getDaysOftheCycle());
		assertEquals(185,	response.getDaysOftheYear());
		assertEquals(000000947839.21d,	response.getCycleAverageBalanceAmount(),0);
		assertEquals(000001059099.56d,	response.getYearAverageBalanceAmount(),0);
		assertEquals(00000000101742,	response.getInterestPayCycleDay(),0);
		assertEquals(000000008569.99d,	response.getInterestPayCycleYear(),0);
		assertEquals(001.28d,	response.getAnnualPercentageCycle(),0);
		assertEquals(001.80d,	response.getAnnualPercentageYield(),0);
		assertEquals(000.80d,	response.getPeriodRate(),0);
		assertEquals(00000000040434,	response.getDestinationCountryTaxAmount(),0);
		assertEquals("123456",	response.getDeliveryReferenceNumber());
		assertEquals("654321",	response.getAuthorizedUserWaiverDurationNumber());
			
		assertEquals("0015063000000051",	response.getNextMovement());
		assertEquals(0015,	response.getQuantityNumber());			
	}	
}
