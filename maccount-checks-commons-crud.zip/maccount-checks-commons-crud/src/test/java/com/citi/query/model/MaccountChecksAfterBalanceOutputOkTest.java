package com.citi.query.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigInteger;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

public class MaccountChecksAfterBalanceOutputOkTest {
	
	private MaccountChecksAfterBalanceOutputOk afterOutput = new MaccountChecksAfterBalanceOutputOk();
	
	@Before
	public void initData(){
		afterOutput.setFiller3("filler3");
		afterOutput.setWksN012EcAboImporte("1.1");
		afterOutput.setWksN012EcAboNum(2);
		afterOutput.setWksN012EcCarImporte("3.3");
		afterOutput.setWksN012EcCarNum(4);
		afterOutput.setWksN012EcFechaCorte(5);
		afterOutput.setWksN012EcFechaFin(6);
		afterOutput.setWksN012EcFechaIni(7);
		afterOutput.setWksN012EcFechaUltmov(8);
		afterOutput.setWksN012EcInst(9);
		afterOutput.setWksN012EcLcDisp("10.10");
		afterOutput.setWksN012EcLcImporte("11.11");
		afterOutput.setWksN012EcLcSdo("12.12");
		afterOutput.setWksN012EcNomcte("13");
		afterOutput.setWksN012EcNummovs(14);
		
		afterOutput.setWksN012EcProd(15);
		afterOutput.setWksN012EcResult(16);
		afterOutput.setWksN012EcSdoActsigno("17");
		afterOutput.setWksN012EcSdoActual("18.18");
		afterOutput.setWksN012EcSdoInicial("19.19");
		afterOutput.setWksN012EcSdoInisigno("20");
		afterOutput.setWksN012EcSigchcm("21");
		afterOutput.setWksN012TraDtCta(BigInteger.valueOf(22));
		afterOutput.setWksN012TraDtSuc("23");
		afterOutput.setWksNctlNumcte(BigInteger.valueOf(24));
		afterOutput.setListOccurs(new ArrayList<>());
		
		
		
	}
	
	@Test
	public void shouldVerifyAfterCutOutputOk(){
		assertEquals("filler3", afterOutput.getFiller3());
		assertEquals("1.1", afterOutput.getWksN012EcAboImporte());
		assertEquals(2, afterOutput.getWksN012EcAboNum());
		assertEquals("3.3", afterOutput.getWksN012EcCarImporte());
		assertEquals(4, afterOutput.getWksN012EcCarNum());
		assertEquals(5, afterOutput.getWksN012EcFechaCorte());
		assertEquals(6, afterOutput.getWksN012EcFechaFin());
		assertEquals(7, afterOutput.getWksN012EcFechaIni());
		assertEquals(8, afterOutput.getWksN012EcFechaUltmov());
		assertEquals(9, afterOutput.getWksN012EcInst());
		assertEquals("10.10", afterOutput.getWksN012EcLcDisp());
		assertEquals("11.11", afterOutput.getWksN012EcLcImporte());
		assertEquals("12.12", afterOutput.getWksN012EcLcSdo());
		assertEquals("13", afterOutput.getWksN012EcNomcte());
		assertEquals(14, afterOutput.getWksN012EcNummovs());
		assertEquals(15, afterOutput.getWksN012EcProd());
		assertEquals(16, afterOutput.getWksN012EcResult());
		assertEquals("17", afterOutput.getWksN012EcSdoActsigno());
		assertEquals("18.18", afterOutput.getWksN012EcSdoActual());
		assertEquals("19.19", afterOutput.getWksN012EcSdoInicial());
		assertEquals("20", afterOutput.getWksN012EcSdoInisigno());
		assertEquals("21", afterOutput.getWksN012EcSigchcm());
		assertEquals(BigInteger.valueOf(22), afterOutput.getWksN012TraDtCta());
		assertEquals("23", afterOutput.getWksN012TraDtSuc());
		assertEquals(BigInteger.valueOf(24), afterOutput.getWksNctlNumcte());
		assertNotNull(afterOutput.getListOccurs());
		
		
		
	}

}
