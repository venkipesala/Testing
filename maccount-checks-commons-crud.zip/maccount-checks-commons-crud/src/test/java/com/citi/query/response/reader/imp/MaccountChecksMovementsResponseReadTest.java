package com.citi.query.response.reader.imp;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.aggregator.reader.impl.MaccountChecksBeforeBalanceResponseRead;
import com.citi.query.aggregator.reader.impl.MaccountChecksMovementsResponseRead;
import com.citi.query.contract.MaccountChecksCommonsResponseContract;
import com.softtek.legacy.framework.model.DataElementFormatException;
import com.softtek.legacy.framework.parser.ParserException;

public class MaccountChecksMovementsResponseReadTest {
	private MaccountChecksCommonsResponseContract commonResponseContract = new MaccountChecksCommonsResponseContract();
	private MaccountChecksMovementsResponseRead responseRead;
	String bufferOutput;
	
	@Before
	public void initData(){

		bufferOutput = "FR905500660000080000009319100545°°°°°°°°°°°°°°°°00150116083000000011DEPOSITO P/TRASPASO°°°°°°°°°°°°°°°°°°°°  00000000009000000000000000000000001194 000000000090000116083000000021RETIRO POR RASPASO                      -00000000000100P TER 000000000000001358 000000000089000116083000000031RETIRO POR RASPASO°°°°                  -00000000000100P TER 000000000000001358°000000000088000116083000000031RETIRO POR RASPASO°°°°°°°°°°            -00000000000100P°TER 000000000000001358 000000000087000116083000000051RETIRO POR RASPASO°°°°°°°°°°°°°°°°      -00000000000100P TER 000000000000001358 000000000086000116083000000061RETIRO POR°RASPASO°°°°°°°°°°°°°°°°°°°°°°-00000000000100P TER 000000000000001358 000000000085000116083000000071RETIRO POR RASPASO                      -00000000000100P TER 000000000000001358 000000000084000116083000000081RETIRO POR RASPASO°°°°°                 -00000000000100P TER 000000000000001358 000000000083000116083000000091RETIRO POR RASPASO°°°°°°°°°°°           -00000000000100P TER 000000000000001358 000000000082000116083000000101RETIRO POR RASPASO°°°°°°°°°°°°°°°°°     -00000000000100P TER 000000000000001358 000000000081000116083000000111RETIRO POR RASPASO                      -00000000000100P TER 000000000000001358 000000000080000116083000000121RETIRO POR RASPASO                      -00000000000100P TER 000000000000001358 000000000079000116083000000131RETIRO POR RASPASO°°°°°°                -00000000000100P TER 000000000000001358 000000000078000116083000000141RETIRO POR RASPASO°°°°°°°°°°°°          -00000000000100P TER 000000000000001358 000000000077000116083000000151RETIRO°POR RASPASO°°°°°°°°°°°°°°°°°°    -00000000000100P TER 000000000000001358 00000000007600";

	}
	
	@Test
	public void shouldVerifyReadResponse() throws DataElementFormatException, ParserException{
		
		responseRead = new MaccountChecksMovementsResponseRead();
//		commonResponseContract.setMaccountChecksCommonsResponse(responseRead.readResponse(bufferOutput));
//		assertNotNull(commonResponseContract.getMaccountChecksCommonsResponse());
		
	}
}
