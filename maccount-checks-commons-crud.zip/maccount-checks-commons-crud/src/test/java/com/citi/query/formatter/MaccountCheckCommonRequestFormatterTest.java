/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckCommonInputFormatterTest.java
 * Original Author: ENLM
 * Creation Date: 1/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.formatter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.banamex.nga.gemfire.cache.stationame.beans.StationName;
import com.citi.query.aggregator.CacheAggregator;
import com.citi.query.model.MaccountChecksCommonInput;
import com.citi.query.request.MaccountCheckCommonRequest;
import com.citi.unisys.model.HeaderBnmx;
import com.citi.unisys.model.HeaderSa2;

/**
 * <code>MaccountCheckCommonInputFormatterTest</code>.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckCommonRequestFormatterTest {
	@Mock
	StationName stationName = new StationName();
	@Mock
	CacheAggregator serviceCache = new CacheAggregator();

	/** request. */
	@InjectMocks
	MaccountCheckCommonRequest request = new MaccountCheckCommonRequest();

	/** formatter. */
	MaccountCheckCommonRequestFormatter formatter = new MaccountCheckCommonRequestFormatter();

	/**
	 * Initial data.
	 */
	@Before
	public void initialData() {


		request.setProductID(10);
		request.setInstrumentID(02);
		request.setBranchID(79);
		request.setAccountNumber(BigInteger.valueOf(142380748));
		request.setOptionNumber(80);
		request.setQuantityNumber(23);
		request.setNextMovement("000000123");
		request.setCsi(15);
		request.setBranchNumber(1);
		request.setSystemReference(4);
		request.setCashCode(2);
		MockitoAnnotations.initMocks(this);

	}

	/**
	 * Should verify con mov cta mae cont request formatter.
	 */
	@Test
	public void shouldVerifyConMovCtaMaeContRequestFormatter() {

		MaccountChecksCommonInput queryInput = formatter.formatInputDataModel(request, 811);

		assertNotNull(queryInput.getWksN012EcCodchcm());
		assertNotNull(queryInput.getWksN012EcProd());
		assertNotNull(queryInput.getWksN012EcInst());
		assertNotNull(queryInput.getWksN012SolgrlSuc());
		assertNotNull(queryInput.getWksN012SolgrlCta());
		assertNotNull(queryInput.getWksN012EcOpcion());
		assertNotNull(queryInput.getWksN012EcNummovs());
		assertNotNull(queryInput.getWksN012EcSigchcm());
		assertNotNull(queryInput.getFiller1());
		assertNotNull(queryInput.getFiller2());

	}

	/**
	 * Should verify header HBMX formatter.
	 */
	@Test
	public void shouldVerifyHeaderHBMXFormatter811() {
		when(stationName.getStationName()).thenReturn("Y0897D");
		when(serviceCache.getStationNameStructure(request.getCsi(), request.getChannelId())).thenReturn(new StationName());
		HeaderBnmx headerBnmx = formatter.formatHeaderBnmx(request, 811);
		assertEquals("F", headerBnmx.getHdrBnmxPrefijoHeader());
		assertEquals("0", headerBnmx.getHdrBnmxPrefijoAplicacionDestino());
		assertEquals(15, headerBnmx.getHdrBnmxCsiDestino());
		assertEquals(0, headerBnmx.getHdrBnmxNumeroEstacion());
		assertEquals("Y", headerBnmx.getHdrBnmxTipoTerminal());
		assertEquals(request.getBranchNumber(), headerBnmx.getHdrBnmxSucursal());
		assertEquals("D", headerBnmx.getHdrBnmxPrivilegioTerminal());
		assertEquals(request.getCashCode(), headerBnmx.getHdrBnmxCaja());
		assertEquals(15, headerBnmx.getHdrBnmxCsiOrigen());
		assertEquals(0, headerBnmx.getHdrBnmxNodoOrigen());
		assertEquals("  ", headerBnmx.getHdrBnmxFacultadoTerminalista());
		assertEquals(" ", headerBnmx.getHdrBnmxPrefijoAplicacionOrigen());
		assertEquals(2, headerBnmx.getHdrBnmxResultado());
		assertEquals("     ", headerBnmx.getHdrBnmxNombreMascara());
		assertEquals("      ", headerBnmx.getHdrBnmxClaveSeguridadOperador());
		assertEquals(50, headerBnmx.getHdrExtAplicacionDestino());
		assertEquals(14, headerBnmx.getHdrExtModuloDestino());
		assertEquals(15, headerBnmx.getHdrExtAplicacionOrigen());
		assertEquals(12, headerBnmx.getHdrExtModuloOrigen());

	}
	
	@Test
	public void shouldVerifyHeaderHBMXFormatter781() {
		when(stationName.getStationName()).thenReturn("Y0897D");
		when(serviceCache.getStationNameStructure(request.getCsi(), request.getChannelId())).thenReturn(new StationName());
		HeaderBnmx headerBnmx = formatter.formatHeaderBnmx(request, 781);
		assertEquals("F", headerBnmx.getHdrBnmxPrefijoHeader());
		assertEquals("0", headerBnmx.getHdrBnmxPrefijoAplicacionDestino());
		assertEquals(15, headerBnmx.getHdrBnmxCsiDestino());
		assertEquals(0, headerBnmx.getHdrBnmxNumeroEstacion());
		assertEquals("Y", headerBnmx.getHdrBnmxTipoTerminal());
		assertEquals(request.getBranchNumber(), headerBnmx.getHdrBnmxSucursal());
		assertEquals("D", headerBnmx.getHdrBnmxPrivilegioTerminal());
		assertEquals(request.getCashCode(), headerBnmx.getHdrBnmxCaja());
		assertEquals(15, headerBnmx.getHdrBnmxCsiOrigen());
		assertEquals(0, headerBnmx.getHdrBnmxNodoOrigen());
		assertEquals("  ", headerBnmx.getHdrBnmxFacultadoTerminalista());
		assertEquals(" ", headerBnmx.getHdrBnmxPrefijoAplicacionOrigen());
		assertEquals(2, headerBnmx.getHdrBnmxResultado());
		assertEquals("     ", headerBnmx.getHdrBnmxNombreMascara());
		assertEquals("      ", headerBnmx.getHdrBnmxClaveSeguridadOperador());
		assertEquals(50, headerBnmx.getHdrExtAplicacionDestino());
		assertEquals(14, headerBnmx.getHdrExtModuloDestino());
		assertEquals(15, headerBnmx.getHdrExtAplicacionOrigen());
		assertEquals(12, headerBnmx.getHdrExtModuloOrigen());

	}
	
	@Test
	public void shouldVerifyHeaderHBMXFormatter780() {
		when(stationName.getStationName()).thenReturn("Y0897D");
		HeaderBnmx headerBnmx = formatter.formatHeaderBnmx(request, 780);
		assertEquals("F", headerBnmx.getHdrBnmxPrefijoHeader());
		assertEquals("0", headerBnmx.getHdrBnmxPrefijoAplicacionDestino());
		assertEquals(15, headerBnmx.getHdrBnmxCsiDestino());
		assertEquals(0, headerBnmx.getHdrBnmxNumeroEstacion());
		assertEquals("Y", headerBnmx.getHdrBnmxTipoTerminal());
		assertEquals(request.getBranchNumber(), headerBnmx.getHdrBnmxSucursal());
		assertEquals("D", headerBnmx.getHdrBnmxPrivilegioTerminal());
		assertEquals(request.getCashCode(), headerBnmx.getHdrBnmxCaja());
		assertEquals(15, headerBnmx.getHdrBnmxCsiOrigen());
		assertEquals(0, headerBnmx.getHdrBnmxNodoOrigen());
		assertEquals("  ", headerBnmx.getHdrBnmxFacultadoTerminalista());
		assertEquals(" ", headerBnmx.getHdrBnmxPrefijoAplicacionOrigen());
		assertEquals(2, headerBnmx.getHdrBnmxResultado());
		assertEquals("     ", headerBnmx.getHdrBnmxNombreMascara());
		assertEquals("      ", headerBnmx.getHdrBnmxClaveSeguridadOperador());
		assertEquals(50, headerBnmx.getHdrExtAplicacionDestino());
		assertEquals(14, headerBnmx.getHdrExtModuloDestino());
		assertEquals(15, headerBnmx.getHdrExtAplicacionOrigen());
		assertEquals(12, headerBnmx.getHdrExtModuloOrigen());

	}
	
	@Test
	public void shouldVerifyHeaderHBMXFormatter791() {
		when(stationName.getStationName()).thenReturn("Y0897D");
		HeaderBnmx headerBnmx = formatter.formatHeaderBnmx(request, 791);
		assertEquals("F", headerBnmx.getHdrBnmxPrefijoHeader());
		assertEquals("0", headerBnmx.getHdrBnmxPrefijoAplicacionDestino());
		assertEquals(15, headerBnmx.getHdrBnmxCsiDestino());
		assertEquals(0, headerBnmx.getHdrBnmxNumeroEstacion());
		assertEquals("Y", headerBnmx.getHdrBnmxTipoTerminal());
		assertEquals(request.getBranchNumber(), headerBnmx.getHdrBnmxSucursal());
		assertEquals("D", headerBnmx.getHdrBnmxPrivilegioTerminal());
		assertEquals(request.getCashCode(), headerBnmx.getHdrBnmxCaja());
		assertEquals(15, headerBnmx.getHdrBnmxCsiOrigen());
		assertEquals(0, headerBnmx.getHdrBnmxNodoOrigen());
		assertEquals("  ", headerBnmx.getHdrBnmxFacultadoTerminalista());
		assertEquals(" ", headerBnmx.getHdrBnmxPrefijoAplicacionOrigen());
		assertEquals(2, headerBnmx.getHdrBnmxResultado());
		assertEquals("     ", headerBnmx.getHdrBnmxNombreMascara());
		assertEquals("      ", headerBnmx.getHdrBnmxClaveSeguridadOperador());
		assertEquals(50, headerBnmx.getHdrExtAplicacionDestino());
		assertEquals(14, headerBnmx.getHdrExtModuloDestino());
		assertEquals(15, headerBnmx.getHdrExtAplicacionOrigen());
		assertEquals(12, headerBnmx.getHdrExtModuloOrigen());

	}
	
	@Test
	public void shouldVerifyHeaderHBMXFormatter790() {
		when(stationName.getStationName()).thenReturn("Y0897D");
		HeaderBnmx headerBnmx = formatter.formatHeaderBnmx(request, 790);
		assertEquals("F", headerBnmx.getHdrBnmxPrefijoHeader());
		assertEquals("0", headerBnmx.getHdrBnmxPrefijoAplicacionDestino());
		assertEquals(15, headerBnmx.getHdrBnmxCsiDestino());
		assertEquals(0, headerBnmx.getHdrBnmxNumeroEstacion());
		assertEquals("Y", headerBnmx.getHdrBnmxTipoTerminal());
		assertEquals(request.getBranchNumber(), headerBnmx.getHdrBnmxSucursal());
		assertEquals("D", headerBnmx.getHdrBnmxPrivilegioTerminal());
		assertEquals(request.getCashCode(), headerBnmx.getHdrBnmxCaja());
		assertEquals(15, headerBnmx.getHdrBnmxCsiOrigen());
		assertEquals(0, headerBnmx.getHdrBnmxNodoOrigen());
		assertEquals("  ", headerBnmx.getHdrBnmxFacultadoTerminalista());
		assertEquals(" ", headerBnmx.getHdrBnmxPrefijoAplicacionOrigen());
		assertEquals(2, headerBnmx.getHdrBnmxResultado());
		assertEquals("     ", headerBnmx.getHdrBnmxNombreMascara());
		assertEquals("      ", headerBnmx.getHdrBnmxClaveSeguridadOperador());
		assertEquals(50, headerBnmx.getHdrExtAplicacionDestino());
		assertEquals(14, headerBnmx.getHdrExtModuloDestino());
		assertEquals(15, headerBnmx.getHdrExtAplicacionOrigen());
		assertEquals(12, headerBnmx.getHdrExtModuloOrigen());

	}
	
	@Test
	public void shouldVerifyHeaderHBMXFormatter801() {
		when(stationName.getStationName()).thenReturn("Y0897D");
		HeaderBnmx headerBnmx = formatter.formatHeaderBnmx(request, 801);
		assertEquals("F", headerBnmx.getHdrBnmxPrefijoHeader());
		assertEquals("0", headerBnmx.getHdrBnmxPrefijoAplicacionDestino());
		assertEquals(15, headerBnmx.getHdrBnmxCsiDestino());
		assertEquals(0, headerBnmx.getHdrBnmxNumeroEstacion());
		assertEquals("Y", headerBnmx.getHdrBnmxTipoTerminal());
		assertEquals(request.getBranchNumber(), headerBnmx.getHdrBnmxSucursal());
		assertEquals("D", headerBnmx.getHdrBnmxPrivilegioTerminal());
		assertEquals(request.getCashCode(), headerBnmx.getHdrBnmxCaja());
		assertEquals(15, headerBnmx.getHdrBnmxCsiOrigen());
		assertEquals(0, headerBnmx.getHdrBnmxNodoOrigen());
		assertEquals("  ", headerBnmx.getHdrBnmxFacultadoTerminalista());
		assertEquals(" ", headerBnmx.getHdrBnmxPrefijoAplicacionOrigen());
		assertEquals(2, headerBnmx.getHdrBnmxResultado());
		assertEquals("     ", headerBnmx.getHdrBnmxNombreMascara());
		assertEquals("      ", headerBnmx.getHdrBnmxClaveSeguridadOperador());
		assertEquals(50, headerBnmx.getHdrExtAplicacionDestino());
		assertEquals(14, headerBnmx.getHdrExtModuloDestino());
		assertEquals(15, headerBnmx.getHdrExtAplicacionOrigen());
		assertEquals(12, headerBnmx.getHdrExtModuloOrigen());

	}
	
	@Test
	public void shouldVerifyHeaderHBMXFormatter800() {
		when(stationName.getStationName()).thenReturn("Y0897D");
		HeaderBnmx headerBnmx = formatter.formatHeaderBnmx(request, 800);
		assertEquals("F", headerBnmx.getHdrBnmxPrefijoHeader());
		assertEquals("0", headerBnmx.getHdrBnmxPrefijoAplicacionDestino());
		assertEquals(15, headerBnmx.getHdrBnmxCsiDestino());
		assertEquals(0, headerBnmx.getHdrBnmxNumeroEstacion());
		assertEquals("Y", headerBnmx.getHdrBnmxTipoTerminal());
		assertEquals(request.getBranchNumber(), headerBnmx.getHdrBnmxSucursal());
		assertEquals("D", headerBnmx.getHdrBnmxPrivilegioTerminal());
		assertEquals(request.getCashCode(), headerBnmx.getHdrBnmxCaja());
		assertEquals(15, headerBnmx.getHdrBnmxCsiOrigen());
		assertEquals(0, headerBnmx.getHdrBnmxNodoOrigen());
		assertEquals("  ", headerBnmx.getHdrBnmxFacultadoTerminalista());
		assertEquals(" ", headerBnmx.getHdrBnmxPrefijoAplicacionOrigen());
		assertEquals(2, headerBnmx.getHdrBnmxResultado());
		assertEquals("     ", headerBnmx.getHdrBnmxNombreMascara());
		assertEquals("      ", headerBnmx.getHdrBnmxClaveSeguridadOperador());
		assertEquals(50, headerBnmx.getHdrExtAplicacionDestino());
		assertEquals(14, headerBnmx.getHdrExtModuloDestino());
		assertEquals(15, headerBnmx.getHdrExtAplicacionOrigen());
		assertEquals(12, headerBnmx.getHdrExtModuloOrigen());

	}
	
	@Test
	public void shouldVerifyHeaderHBMXFormatter810() {
		when(stationName.getStationName()).thenReturn("Y0897D");
		HeaderBnmx headerBnmx = formatter.formatHeaderBnmx(request, 810);
		assertEquals("F", headerBnmx.getHdrBnmxPrefijoHeader());
		assertEquals("0", headerBnmx.getHdrBnmxPrefijoAplicacionDestino());
		assertEquals(15, headerBnmx.getHdrBnmxCsiDestino());
		assertEquals(0, headerBnmx.getHdrBnmxNumeroEstacion());
		assertEquals("Y", headerBnmx.getHdrBnmxTipoTerminal());
		assertEquals(request.getBranchNumber(), headerBnmx.getHdrBnmxSucursal());
		assertEquals("D", headerBnmx.getHdrBnmxPrivilegioTerminal());
		assertEquals(request.getCashCode(), headerBnmx.getHdrBnmxCaja());
		assertEquals(15, headerBnmx.getHdrBnmxCsiOrigen());
		assertEquals(0, headerBnmx.getHdrBnmxNodoOrigen());
		assertEquals("  ", headerBnmx.getHdrBnmxFacultadoTerminalista());
		assertEquals(" ", headerBnmx.getHdrBnmxPrefijoAplicacionOrigen());
		assertEquals(2, headerBnmx.getHdrBnmxResultado());
		assertEquals("     ", headerBnmx.getHdrBnmxNombreMascara());
		assertEquals("      ", headerBnmx.getHdrBnmxClaveSeguridadOperador());
		assertEquals(50, headerBnmx.getHdrExtAplicacionDestino());
		assertEquals(14, headerBnmx.getHdrExtModuloDestino());
		assertEquals(15, headerBnmx.getHdrExtAplicacionOrigen());
		assertEquals(12, headerBnmx.getHdrExtModuloOrigen());

	}
	

	/**
	 * Should verify header sa 2.
	 */
	@Test
	public void shouldVerifyHeaderSa2() {
		when(stationName.getStationName()).thenReturn("Y0897D");
		HeaderSa2 headerSa2 = formatter.formatHeaderSa2(request, 811);
		assertEquals(50, headerSa2.getSa2SistemaDestino());
		assertEquals(0, headerSa2.getSa2CodigoServicioDestino());
		assertEquals(811, headerSa2.getSa2SubCodigoServicioDestino());
		assertEquals(15, headerSa2.getSa2SistemaOrigen());
		assertEquals(0, headerSa2.getSa2CodigoServicioOrigen());
		assertEquals(811, headerSa2.getSa2SubCodigoServicioOrigen());
		assertEquals(1, headerSa2.getSa2Direccion());
		assertEquals(278, headerSa2.getSa2LongitudMensaje());
		assertEquals(60, headerSa2.getSa2TiempoEspera());
		assertEquals(1, headerSa2.getSa2ResultadoIca());
		assertEquals(0, headerSa2.getSa2Identificacion());
		assertEquals(0, headerSa2.getSa2Reconocimiento());
		assertEquals("B", headerSa2.getSa2Version());
		assertEquals(0, headerSa2.getSa2Clase());
		assertEquals(0, headerSa2.getSa2Resultado());
		assertEquals(1, headerSa2.getSa2ModoOperacion());
		assertEquals(1, headerSa2.getSa2EntidadOrigen());
		assertEquals(request.getCashCode(), headerSa2.getSa2NumeroDeCaja());
		assertEquals(request.getReferenceType(), headerSa2.getSa2TipoReferenciaTransaccion());
		assertEquals(8, headerSa2.getSa2NumeroDeOperacionTransaccion());
		assertEquals(request.getSystemReference(), headerSa2.getSa2NumeroDeReferenciaTransaccion());
		assertEquals(20, headerSa2.getSa2Modalidad());
		assertEquals("          ", headerSa2.getSa2ClaveOperador());
		assertEquals("A", headerSa2.getSa2VersionMensaje());

	}

}