/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckMovementsRequestTest.java
 * Original Author: ENLM
 * Creation Date: 31/01/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.request;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.model.MaccountChecksCommonInput;

/**
 *  <code>MaccountCheckMovementsRequestTest</code>.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckCommonRequestTest {
	
	/** query request. */
	MaccountCheckCommonRequest 	queryRequest = new MaccountCheckCommonRequest();
	
	/** query input. */
	MaccountChecksCommonInput queryInput = new MaccountChecksCommonInput();
	
   /**
    * Inits the data.
    */
   @Before
   public void initData(){
	   
	   queryRequest.setProductID(10);
	   queryRequest.setInstrumentID(02);
	   queryRequest.setBranchID(79);
	   queryRequest.setAccountNumber(BigInteger.valueOf(142380748));
	   queryRequest.setOptionNumber(80);
	   queryRequest.setQuantityNumber(23);
	   queryRequest.setNextMovement("000000123");
	   
   }
   
   /**
    * Should get con mov cta mae cont request.
    */
   @Test
   public void shouldGetConMovCtaMaeContRequest(){
	   
	   assertEquals(10, queryRequest.getProductID());
	   assertEquals(02, queryRequest.getInstrumentID());
	   assertEquals(79, queryRequest.getBranchID());
	   assertEquals(BigInteger.valueOf(142380748), queryRequest.getAccountNumber());
	   assertEquals(80, queryRequest.getOptionNumber());
	   assertEquals(23, queryRequest.getQuantityNumber());
	   assertEquals("000000123", queryRequest.getNextMovement());
	   
   }
   
}
