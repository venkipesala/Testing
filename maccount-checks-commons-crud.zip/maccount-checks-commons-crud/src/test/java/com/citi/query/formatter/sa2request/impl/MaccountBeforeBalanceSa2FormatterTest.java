package com.citi.query.formatter.sa2request.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.banamex.nga.gemfire.cache.stationame.beans.StationName;
import com.citi.query.formatter.sa2request.Sa2RequestFormatter;
import com.citi.query.request.MaccountCheckCommonRequest;

public class MaccountBeforeBalanceSa2FormatterTest {
	@Mock
	StationName stationName = new StationName();
	
	@InjectMocks
	Sa2RequestFormatter balanceFormatter = new MaccountBeforeBalanceSa2Formatter();
	MaccountCheckCommonRequest request = new MaccountCheckCommonRequest();

	@Before
	public void initData() {

		request.setAccountNumber(BigInteger.valueOf(1));
		request.setBranchID(2);
		request.setBranchNumber(3);
		request.setCashCode(4);
		request.setCsi(5);
		request.setInstrumentID(8);
		request.setNextMovement("Next");
		request.setOptionNumber(10);
		request.setProductID(11);
		request.setQuantityNumber(12);
		request.setReferenceType(13);
		request.setSystemReference(17);
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void shoud() {
		when(stationName.getStationName()).thenReturn("Y0897D");
		assertNotNull(balanceFormatter.formatHeaderBnmx(request, stationName));
		assertNotNull(balanceFormatter.formatHeaderSa2(request));
		assertNotNull(balanceFormatter.formatToInputModel(request));

	}

}
