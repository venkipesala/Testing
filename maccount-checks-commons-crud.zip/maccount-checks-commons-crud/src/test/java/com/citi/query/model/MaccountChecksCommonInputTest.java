/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountChecksCommonInputTest.java
 * Original Author: ENLM
 * Creation Date: 1/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.model;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

import com.softtek.legacy.framework.model.DataElementFormatException;
import com.softtek.legacy.framework.parser.ParserException;
import com.softtek.legacy.framework.util.BufferBuilder;

/**
 * The Class ConMovCtaMaeContInputTest.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountChecksCommonInputTest {

	/** The con mov cta mae cont input. */
	MaccountChecksCommonInput conMovCtaMaeContInput = new MaccountChecksCommonInput();
	
	
	
	/**
	 * Inits the data.
	 */
	@Before
	public void initData() {

		conMovCtaMaeContInput.setWksN012EcCodchcm("A");
		conMovCtaMaeContInput.setWksN012EcProd(9);
		conMovCtaMaeContInput.setWksN012EcInst(0);
		conMovCtaMaeContInput.setWksN012SolgrlSuc(5);
		conMovCtaMaeContInput.setWksN012SolgrlCta(BigInteger.valueOf(142380748));
		conMovCtaMaeContInput.setWksN012EcOpcion(4);
		conMovCtaMaeContInput.setWksN012EcNummovs(4);
		conMovCtaMaeContInput.setWksN012EcSigchcm("M");
		conMovCtaMaeContInput.setFiller1("S");
		conMovCtaMaeContInput.setFiller2("00");	
	}

	/**
	 * Should verifyconmovctamaecont input.
	 */
	@Test
	public void shouldVerifyconmovctamaecontInput() {
		assertEquals("A",conMovCtaMaeContInput.getWksN012EcCodchcm());
		assertEquals(9, conMovCtaMaeContInput.getWksN012EcProd());
		assertEquals(0, conMovCtaMaeContInput.getWksN012EcInst());
		assertEquals(5, conMovCtaMaeContInput.getWksN012SolgrlSuc());
		assertEquals(BigInteger.valueOf(142380748), conMovCtaMaeContInput.getWksN012SolgrlCta());
		assertEquals(4, conMovCtaMaeContInput.getWksN012EcOpcion());
		assertEquals(4, conMovCtaMaeContInput.getWksN012EcNummovs());
		assertEquals("M", conMovCtaMaeContInput.getWksN012EcSigchcm());
		assertEquals("S", conMovCtaMaeContInput.getFiller1());
		assertEquals("00", conMovCtaMaeContInput.getFiller2());
	}
	
	/**
	 * Should create buffer input request.
	 *
	 * @throws DataElementFormatException the data element format exception
	 * @throws ParserException the parser exception
	 */
	@Test
	public void shouldCreateBufferInputRequest()
			throws DataElementFormatException, ParserException {
		
		String bufferInputExpected = "A     000900000005000142380748040004M               S           00";
		BufferBuilder bufferBuilder = new BufferBuilder(conMovCtaMaeContInput);
		bufferBuilder.build();
		assertEquals(bufferInputExpected, bufferBuilder.getBuffer().toString());
	}
}
