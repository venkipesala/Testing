package com.citi.query.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.response.MaccountChecksAfterBalanceResponse;
import com.citi.query.response.InnerOcurrs;

public class MaccountChecksAfterBalanceResponseTest {
	
	MaccountChecksAfterBalanceResponse afterResponse = new MaccountChecksAfterBalanceResponse();
	
	@Before
	public void initData(){
		afterResponse.setAccountNumber(BigInteger.valueOf(1));
		afterResponse.setBalanceAmount(2.2);
		afterResponse.setBalanceStartAmount(3.3);
		afterResponse.setBranchID("    ");
		afterResponse.setChargeOffAmount(5.5);
		afterResponse.setCreditAvailableAmount(6.6);
		afterResponse.setCreditUsedAmount(7.7);
		afterResponse.setCustomerId(BigInteger.valueOf(8));
		afterResponse.setCustomerName("9");
		afterResponse.setCutoffDay(10);
		afterResponse.setDepositDueAmount(11.11);
		afterResponse.setEntrySequenceNumber(12);
		afterResponse.setFinancialCreditLineAmount(13.13);
		afterResponse.setInstrumentID(14);
		afterResponse.setLastAccessDate(15);
		afterResponse.setNextMovement("16");
		afterResponse.setOutSequenceNumber(17);
		afterResponse.setProductID(18);
		afterResponse.setQuantityNumber(19);
		afterResponse.setResultZeros(20);
		afterResponse.setSignBalanceAmount("21");
		afterResponse.setSignBalanceStartAmount("22");
		afterResponse.setStartDate(23);
		afterResponse.setStopDate(24);
		afterResponse.setSuffix("25");
		List<InnerOcurrs> listaOccurs = new ArrayList<>();
		InnerOcurrs occurs = new InnerOcurrs();
		occurs.setAuthorizationNumber(1);
		occurs.setCycleCount(2);
		occurs.setDescription("3");
		occurs.setReferenceNumber("4");
		occurs.setSequenceNumber(5);
		occurs.setSignAmount("6");
		occurs.setSignAmountAfter("7");
		occurs.setTransactionAmount(8.8);
		occurs.setTransactionAmountAfter(9.9);
		occurs.setTransactionDate(10);
		listaOccurs.add(occurs);
		afterResponse.setGpogroupOccurs(listaOccurs);
		
	}
	
	@Test
	public void shouldVerifyAfterCutResponse(){
		assertEquals(BigInteger.valueOf(1), afterResponse.getAccountNumber());
		assertTrue(Math.abs(afterResponse.getBalanceAmount() - 2.2) == 0);
		assertTrue(Math.abs(afterResponse.getBalanceStartAmount() - 3.3) == 0);
		assertEquals("    ", afterResponse.getBranchID());
		assertTrue(Math.abs(afterResponse.getChargeOffAmount() - 5.5) == 0);
		assertTrue(Math.abs(afterResponse.getCreditAvailableAmount() - 6.6) == 0);
		assertTrue(Math.abs(afterResponse.getCreditUsedAmount() - 7.7) == 0);
		assertEquals(BigInteger.valueOf(8), afterResponse.getCustomerId());
		assertEquals("9", afterResponse.getCustomerName());
		assertEquals(10, afterResponse.getCutoffDay());
		assertTrue(Math.abs(afterResponse.getDepositDueAmount() - 11.11) == 0);
		assertEquals(12, afterResponse.getEntrySequenceNumber());
		assertTrue(Math.abs(afterResponse.getFinancialCreditLineAmount() - 13.13) == 0);
		assertEquals(14, afterResponse.getInstrumentID());
		assertEquals(15, afterResponse.getLastAccessDate());
		assertEquals("16", afterResponse.getNextMovement());
		assertEquals(17, afterResponse.getOutSequenceNumber());
		assertEquals(18, afterResponse.getProductID());
		assertEquals(19, afterResponse.getQuantityNumber());
		assertEquals(20, afterResponse.getResultZeros());
		assertEquals("21", afterResponse.getSignBalanceAmount());
		assertEquals("22", afterResponse.getSignBalanceStartAmount());
		assertEquals(23, afterResponse.getStartDate());
		assertEquals(24, afterResponse.getStopDate());
		assertEquals("25", afterResponse.getSuffix());
		assertNotNull(afterResponse.getGpogroupOccurs());
		
	}

}
