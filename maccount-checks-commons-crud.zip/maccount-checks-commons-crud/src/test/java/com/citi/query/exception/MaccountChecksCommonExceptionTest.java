package com.citi.query.exception;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.model.MaccountChecksCommonError;

public class MaccountChecksCommonExceptionTest {
	MaccountChecksCommonException commonException;
	MaccountChecksCommonException commonException2;
	MaccountChecksCommonError commonError = new MaccountChecksCommonError();
	@Before
	public void initData(){
		commonError.setFiller4("Fill");
		commonError.setWksN012EcResult(2);
		commonException = new MaccountChecksCommonException(commonError);
		commonException.setErrorCode(1);
		commonException2 = new MaccountChecksCommonException(3, "Error");
		
		
	}
	
	@Test
	public void shouldVerifyException(){
		
		assertEquals(1, commonException.getErrorCode());
		assertEquals("Fill", commonException.getMaccountChecksCommonError().getFiller4());
		assertEquals(2, commonException.getMaccountChecksCommonError().getWksN012EcResult());
		assertEquals(3, commonException2.getErrorCode());
	}

}
