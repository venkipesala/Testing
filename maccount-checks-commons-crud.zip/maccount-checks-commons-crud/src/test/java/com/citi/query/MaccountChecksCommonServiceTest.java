package com.citi.query;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.banamex.nga.gemfire.cache.stationame.beans.StationName;
import com.citi.query.aggregator.MaccountChecksCommonRequestAggregator;
import com.citi.query.aggregator.MaccountChecksCommonResponseAggregator;
import com.citi.query.contract.MaccountCheckCommonContractRequest;
import com.citi.query.contract.MaccountChecksCommonsResponseContract;
import com.citi.query.exception.JracRequestAggregatorException;
import com.citi.query.exception.MaccountChecksCommonException;
import com.citi.query.formatter.MaccountCheckCommonRequestFormatter;
import com.citi.query.model.GroupOccurs;
import com.citi.query.model.MaccountCheckBeforeBalanceOutputOk;
import com.citi.query.request.MaccountCheckCommonRequest;
import com.citi.query.response.MaccountCheckBeforeBalanceResponse;
import com.citi.query.service.MaccountChecksCommonService;
import com.citi.query.validator.MaccountCheckCommonValidatorRequest;
import com.citi.unisys.utils.UnisysResultException;
import com.softtek.legacy.framework.model.DataElementFormatException;
import com.softtek.legacy.framework.parser.ParserException;

public class MaccountChecksCommonServiceTest {

	String bufferOK = "F0200000Y0870D620400  002           001512005014001500781005000781221470006002000B01100150620802492515072316324420°°        A FR90660006600081234512567690000000033664238HECTOR EFREN LOZANO GONZALEZ                           15070415072215070115070400000082039459S000161000000013193000000120000000005848000000083402021S123456789012341234567890123412345678901234301850000009478392100000105909956000000001017420000000085699900128001800008000000000040434123456654321001506300000005100150015060500000011DEPOSITO P/TRASPASO°°°°°                S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO°°°°°°°°°°°          S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO°°°°°°°°°°°°°°°°°    S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO°                    S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO°°°°°°°              S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO°°°°°°°°°°°°°        S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO°°°°°°°°°°°°°°°°°°°  S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S000000820494590015060500000011DEPOSITO P/TRASPASO                     S00000000010000000000000000000000001128S00000082049459";
	MaccountCheckCommonRequest queryRequest = new MaccountCheckCommonRequest();
	MaccountCheckCommonRequestFormatter format = new MaccountCheckCommonRequestFormatter();
	MaccountCheckBeforeBalanceResponse beforeContract = new MaccountCheckBeforeBalanceResponse();
	MaccountCheckCommonContractRequest contract = new MaccountCheckCommonContractRequest();
	MaccountCheckBeforeBalanceOutputOk outputOkModel = new MaccountCheckBeforeBalanceOutputOk();
	MaccountChecksCommonsResponseContract contractResponse = new MaccountChecksCommonsResponseContract();

	
	
	@Mock
	StationName stationName = new StationName();
	
	@InjectMocks
	@Mock
	MaccountCheckCommonRequestFormatter requestFormatter = new MaccountCheckCommonRequestFormatter();
	
	@Mock
	MaccountChecksCommonRequestAggregator requestAggregator;

	@Mock
	MaccountChecksCommonResponseAggregator responseAggregator = new MaccountChecksCommonResponseAggregator();

	@Mock
	MaccountCheckCommonValidatorRequest validatorRequest = new MaccountCheckCommonValidatorRequest();

	@InjectMocks
	MaccountChecksCommonService service = new MaccountChecksCommonService();

	@Before
	public void initData() {

		queryRequest.setProductID(1010);
		queryRequest.setInstrumentID(1002);
		queryRequest.setBranchID(1079);
		queryRequest.setAccountNumber(BigInteger.valueOf(142380748912L));
		queryRequest.setOptionNumber(42);
		queryRequest.setQuantityNumber(23);
		queryRequest.setNextMovement("000000123");
		queryRequest.setSubcode(781);
		contract.setHeaderBanamex(format.formatHeaderBnmx(queryRequest, 781));
		contract.setHeaderSa2(format.formatHeaderSa2(queryRequest, 781));
		contract.setInputModel(format.formatInputDataModel(queryRequest, 781));

		requestAggregator = new MaccountChecksCommonRequestAggregator(contract);

		outputOkModel.setFillero1("FR906");
		outputOkModel.setWksN012EcResult(60);
		outputOkModel.setWksN012EcProd(0066);
		outputOkModel.setWksN012EcInst(Integer.parseInt("0008"));
		outputOkModel.setWksN012TraDtSuc("    ");
		outputOkModel.setWksN012TraDtCta(new BigInteger("512567690000"));
		outputOkModel.setWksNctlNumcte(new BigInteger("000033664238"));
		outputOkModel.setWksN012EcNomcte("HECTOR EFREN LOZANO GONZALEZ");
		outputOkModel.setWksN012EcFechaCorte(150704);
		outputOkModel.setWksN012EcFechaUltmov(150722);
		outputOkModel.setWksN012EcFechaIni(150701);
		outputOkModel.setWksN012EcFechaFin(150704);
		outputOkModel.setWksN012EcSdoInicial(820394.59d);
		outputOkModel.setWksN012EcSdoInisigno("S");
		outputOkModel.setWksN012EcAboNum(000161);
		outputOkModel.setWksN012EcAboImporte(13193.00d);
		outputOkModel.setWksN012EcCarNum(000012);
		outputOkModel.setWksN012EcCarImporte(584.80d);
		outputOkModel.setWksN012EcSdoActual(834020.21d);
		outputOkModel.setWksN012EcSdoActsigno("S");
		outputOkModel.setWksN012EcLcImporte("123456789012.34");
		outputOkModel.setWksN012EcLcSdo("123456789012.34");
		outputOkModel.setWksN012EcLcDisp("123456789012.34");
		outputOkModel.setWksN012EcCicloDias(30);
		outputOkModel.setWksN012EcYearDias(185);
		outputOkModel.setWksN012EcCicloSdoProm(947839.21d);
		outputOkModel.setWksN012EcYearSdoProm(1059099.56d);
		outputOkModel.setWksN012EcCicloInteres(00000000101742);
		outputOkModel.setWksN012EcYearInteres(8569.99d);
		outputOkModel.setWksN012EcCicloRendim(1.28d);
		outputOkModel.setWksN012EcCicloRendBruto(1.80);
		outputOkModel.setWksN012EcYearRendim(0.80d);
		outputOkModel.setWksN012EcCicloTax(404.34d);
		outputOkModel.setWksN012EcCheqGirados("123456");
		outputOkModel.setWksN012EcCheqExentos("654321");
		outputOkModel.setWksN012EcSigchcm("0015063000000051");
		outputOkModel.setWksN012EcNummovs(0015);
		List<GroupOccurs> details = new ArrayList<>();
		for (int i = 0; i < 15; i++) {
			GroupOccurs groupDetailOutputOkModel = new GroupOccurs();
			groupDetailOutputOkModel.setWksN012EcMovCiclo(0);
			groupDetailOutputOkModel.setWksN012EcMovFecha(150605);
			groupDetailOutputOkModel.setWksN012EcMovSig(00000011);
			groupDetailOutputOkModel.setWksN012EcMovConcept("DEPOSITO P/TRASPASO°°°°°");
			groupDetailOutputOkModel.setWksN012EcMovSigno("S");
			groupDetailOutputOkModel.setWksN012EcMovImporte(0000000000000000);
			groupDetailOutputOkModel.setWksN012EcReferenciaNum("0000000000000000");
			groupDetailOutputOkModel.setWksN012EcNumAut(Integer.parseInt("00001128"));
			groupDetailOutputOkModel.setWksN012EcMovSignoImp("S");
			groupDetailOutputOkModel.setWksN012EcMovImpDesTrx(820494.59d);
			details.add(groupDetailOutputOkModel);
		}

		outputOkModel.setOutputDetail(details);

		contractResponse.setHeaderBnmx(contract.getHeaderBanamex());
		contractResponse.setHeaderSa2(contract.getHeaderSa2());
//		contractResponse.setMaccountChecksCommonsResponse(outputOkModel);
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void shouldVerify() throws JracRequestAggregatorException, DataElementFormatException, ParserException,
			UnisysResultException, MaccountChecksCommonException {
		when(stationName.getStationName()).thenReturn("Y0897D");
		when(requestFormatter.format(queryRequest, 781)).thenReturn(contract);
		when(requestAggregator.executeQuery()).thenReturn(bufferOK);
		when(responseAggregator.getContractResponse(bufferOK, 42)).thenReturn(contractResponse);

//		MaccountCheckBeforeBalanceResponse response = (MaccountCheckBeforeBalanceResponse) service.query(queryRequest);
//		assertEquals(1234 , response.getBranchID());

	}

}
