/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckMovementsExceptionTest.java
 * Original Author: ENLM
 * Creation Date: 1/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.exception;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.model.MaccountChecksCommonError;
/**
 *  <code>MaccountCheckMovementsExceptionTest</code>.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckMovementsExceptionTest{

	
	/** query error. */
	MaccountChecksCommonError queryError = new MaccountChecksCommonError();
	
	/**
	 * Inits the data.
	 */
	@Before
	public void initData(){
	
		queryError.setWksN012EcResult(900);
		queryError.setFiller4("ERROR, NO EXISTE DECLARACION SOLICITADA°°°°°°     ");
		
		
	}

	/**
	 * Should verify maccount check movements exception.
	 */
	@Test
	public void shouldVerifyMaccountCheckMovementsException(){
		
		MaccountCheckMovementsException queryException = new MaccountCheckMovementsException(queryError);
		assertNotNull(queryException.getQueryError());
		
	}
}
