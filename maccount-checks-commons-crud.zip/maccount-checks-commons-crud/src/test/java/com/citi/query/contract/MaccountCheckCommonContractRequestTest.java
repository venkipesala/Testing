/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckCommonContractRequestTest.java
 * Original Author: ENLM
 * Creation Date: 31/01/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.contract;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.model.MaccountChecksCommonInput;
import com.citi.unisys.model.HeaderBnmx;
import com.citi.unisys.model.HeaderSa2;

/**
 *  <code>MaccountCheckCommonContractRequestTest</code>.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckCommonContractRequestTest {
	
	/** query contract. */
	MaccountCheckCommonContractRequest queryContract =  new MaccountCheckCommonContractRequest();
	
	/** header bnmx. */
	HeaderBnmx headerBnmx = new HeaderBnmx();
	
	/** header sa 2. */
	HeaderSa2 headerSa2 = new HeaderSa2();
	
	/** query input. */
	MaccountChecksCommonInput queryInput = new MaccountChecksCommonInput();
	
	/**
	 * Inits the data.
	 */
	@Before
	public void initData(){
		
		
		queryContract.setHeaderBanamex(headerBnmx);
		queryContract.setHeaderSa2(headerSa2);
		queryContract.setInputModel(queryInput);
	
	}
	
	/**
	 * Should verify consmultmovtosimpfissa 2 contract.
	 */
	@Test
	public void shouldVerifyConsmultmovtosimpfissa2Contract(){
		assertNotNull(queryContract.getHeaderBanamex());
		assertNotNull(queryContract.getHeaderSa2());
		assertNotNull(queryContract.getInputModel());
		
		
	}

	
}
