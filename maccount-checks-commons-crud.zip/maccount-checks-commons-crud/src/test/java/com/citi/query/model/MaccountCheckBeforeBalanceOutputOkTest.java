package com.citi.query.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class MaccountCheckBeforeBalanceOutputOkTest {

	MaccountCheckBeforeBalanceOutputOk outputOkModel = new MaccountCheckBeforeBalanceOutputOk();

	GroupOccurs groupDetailOutputOkModel = new GroupOccurs();

	@Before
	public void initData() {

		outputOkModel.setFillero1("FR906");
		outputOkModel.setWksN012EcResult(60);
		outputOkModel.setWksN012EcProd(0066);
		outputOkModel.setWksN012EcInst(Integer.parseInt("0008"));
		outputOkModel.setWksN012TraDtSuc("1234");
		outputOkModel.setWksN012TraDtCta(new BigInteger("512567690000"));
		outputOkModel.setWksNctlNumcte(new BigInteger("000033664238"));
		outputOkModel.setWksN012EcNomcte("HECTOR EFREN LOZANO GONZALEZ");
		outputOkModel.setWksN012EcFechaCorte(150704);
		outputOkModel.setWksN012EcFechaUltmov(150722);
		outputOkModel.setWksN012EcFechaIni(150701);
		outputOkModel.setWksN012EcFechaFin(150704);
		outputOkModel.setWksN012EcSdoInicial(820394.59d);
		outputOkModel.setWksN012EcSdoInisigno("S");
		outputOkModel.setWksN012EcAboNum(000161);
		outputOkModel.setWksN012EcAboImporte(13193.00d);
		outputOkModel.setWksN012EcCarNum(000012);
		outputOkModel.setWksN012EcCarImporte(584.80d);
		outputOkModel.setWksN012EcSdoActual(834020.21d);
		outputOkModel.setWksN012EcSdoActsigno("S");
		outputOkModel.setWksN012EcLcImporte("123456789012.34");
		outputOkModel.setWksN012EcLcSdo("123456789012.34");
		outputOkModel.setWksN012EcLcDisp("123456789012.34");
		outputOkModel.setWksN012EcCicloDias(30);
		outputOkModel.setWksN012EcYearDias(185);
		outputOkModel.setWksN012EcCicloSdoProm(947839.21d);
		outputOkModel.setWksN012EcYearSdoProm(1059099.56d);
		outputOkModel.setWksN012EcCicloInteres(00000000101742);
		outputOkModel.setWksN012EcYearInteres(8569.99d);
		outputOkModel.setWksN012EcCicloRendim(1.28d);
		outputOkModel.setWksN012EcCicloRendBruto(1.80);
		outputOkModel.setWksN012EcYearRendim(0.80d);
		outputOkModel.setWksN012EcCicloTax(404.34d);
		outputOkModel.setWksN012EcCheqGirados("123456");
		outputOkModel.setWksN012EcCheqExentos("654321");
		outputOkModel.setWksN012EcSigchcm("0015063000000051");
		outputOkModel.setWksN012EcNummovs(0015);
        
				groupDetailOutputOkModel.setWksN012EcMovCiclo(0);
				groupDetailOutputOkModel.setWksN012EcMovFecha(150605);
				groupDetailOutputOkModel.setWksN012EcMovSig(00000011);
				groupDetailOutputOkModel.setWksN012EcMovConcept("DEPOSITO P/TRASPASO°°°°°");
				groupDetailOutputOkModel.setWksN012EcMovSigno("S");
				groupDetailOutputOkModel.setWksN012EcMovImporte(0000000000000000);
				groupDetailOutputOkModel.setWksN012EcReferenciaNum("0000000000000000");
				groupDetailOutputOkModel.setWksN012EcNumAut(Integer.parseInt("00001128"));
				groupDetailOutputOkModel.setWksN012EcMovSignoImp("S");
				groupDetailOutputOkModel.setWksN012EcMovImpDesTrx(820494.59d);
		
		List<GroupOccurs> details = new ArrayList<>();
		details.add(groupDetailOutputOkModel);

		outputOkModel.setOutputDetail(details);
	}

	@Test
	public void shouldGetOutputOkModelValues() {
		
		assertEquals("FR906",	outputOkModel.getFillero1());
		assertEquals(60,	outputOkModel.getWksN012EcResult()	);
		assertEquals(0066,	outputOkModel.getWksN012EcProd()	);
		assertEquals(Integer.parseInt("0008"),	outputOkModel.getWksN012EcInst()	);
		assertEquals("1234",	outputOkModel.getWksN012TraDtSuc()	);
		assertEquals(new BigInteger("512567690000"),	outputOkModel.getWksN012TraDtCta()	);
		assertEquals(new BigInteger("000033664238"),	outputOkModel.getWksNctlNumcte()	);
		assertEquals("HECTOR EFREN LOZANO GONZALEZ",	outputOkModel.getWksN012EcNomcte()	);
		assertEquals(150704,	outputOkModel.getWksN012EcFechaCorte()	);
		assertEquals(150722,	outputOkModel.getWksN012EcFechaUltmov()	);
		assertEquals(150701,	outputOkModel.getWksN012EcFechaIni()	);
		assertEquals(150704,	outputOkModel.getWksN012EcFechaFin()	);
		
		assertEquals(820394.59d,	outputOkModel.getWksN012EcSdoInicial(),0	);
		assertEquals("S",	outputOkModel.getWksN012EcSdoInisigno()	);
		assertEquals(000161,	outputOkModel.getWksN012EcAboNum()	);
		assertEquals(13193.00d,	outputOkModel.getWksN012EcAboImporte(),0	);
		assertEquals(000012,	outputOkModel.getWksN012EcCarNum()	);
		assertEquals(584.80d,	outputOkModel.getWksN012EcCarImporte(),0	);
		assertEquals(834020.21,	outputOkModel.getWksN012EcSdoActual(),0	);
		assertEquals("S",	outputOkModel.getWksN012EcSdoActsigno()	);
		assertEquals("123456789012.34", outputOkModel.getWksN012EcLcImporte());
		assertEquals("123456789012.34",	outputOkModel.getWksN012EcLcSdo());
		assertEquals("123456789012.34",	outputOkModel.getWksN012EcLcDisp()	);
		assertEquals(30,	outputOkModel.getWksN012EcCicloDias()	);
		assertEquals(185,	outputOkModel.getWksN012EcYearDias()	);
		assertEquals(947839.21d,	outputOkModel.getWksN012EcCicloSdoProm(),0	);
		assertEquals(1059099.56d,	outputOkModel.getWksN012EcYearSdoProm(),0	);
		assertEquals(00000000101742,	outputOkModel.getWksN012EcCicloInteres(),0	);
		assertEquals(8569.99d,	outputOkModel.getWksN012EcYearInteres(),0	);
		assertEquals(1.28d,	outputOkModel.getWksN012EcCicloRendim(),0	);
		assertEquals(1.80d,	outputOkModel.getWksN012EcCicloRendBruto(),0);
		assertEquals(0.80d,	outputOkModel.getWksN012EcYearRendim(),0	);

		assertEquals(404.34d,	outputOkModel.getWksN012EcCicloTax(),0	);
		assertEquals("123456",	outputOkModel.getWksN012EcCheqGirados()	);
		assertEquals("654321",	outputOkModel.getWksN012EcCheqExentos()	);
		assertEquals("0015063000000051",	outputOkModel.getWksN012EcSigchcm()	);
		assertEquals(0015,	outputOkModel.getWksN012EcNummovs()	);
		
			 for (GroupOccurs itemOcurr : outputOkModel.getOutputDetail()) {
	        	assertEquals(0,itemOcurr.getWksN012EcMovCiclo());
	        	assertEquals(150605,itemOcurr.getWksN012EcMovFecha());
	        	assertEquals(00000011,itemOcurr.getWksN012EcMovSig());
	        	assertEquals("DEPOSITO P/TRASPASO°°°°°",itemOcurr.getWksN012EcMovConcept());
	        	assertEquals("S",itemOcurr.getWksN012EcMovSigno());
	        	assertEquals(0.00d,itemOcurr.getWksN012EcMovImporte(),0);
	        	assertEquals("0000000000000000",itemOcurr.getWksN012EcReferenciaNum());
	        	assertEquals(Integer.parseInt("00001128"),itemOcurr.getWksN012EcNumAut());
	        	assertEquals("S",itemOcurr.getWksN012EcMovSignoImp());
	        	assertEquals(820494.59d,itemOcurr.getWksN012EcMovImpDesTrx(),0);
	      
			} 
		
	}

	

	
}
