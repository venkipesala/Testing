package com.citi.query.formatter.responseformatter.impl;

import static org.junit.Assert.assertNotNull;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.citi.query.model.GroupOccurs;
import com.citi.query.model.MaccounChecksMovementsOutputOk;

public class MaccountChecksMovementsResponseFormatterTest {
	MaccounChecksMovementsOutputOk beforeOutput = new MaccounChecksMovementsOutputOk();
	MaccountChecksMovementsResponseFormatter responseFormatter = new MaccountChecksMovementsResponseFormatter();
	
	@Before
	public void initData(){
		beforeOutput.setFiller3("Fill");
	

		beforeOutput.setWksN012EcInst(18);

		beforeOutput.setWksN012EcNummovs(15);
		beforeOutput.setWksN012EcProd(22);
		beforeOutput.setWksN012EcResult(23);

		beforeOutput.setWksN012EcSigchcm("+");

		beforeOutput.setWksN012TraDtCta(BigInteger.valueOf(32));
		beforeOutput.setWksN012TraDtSuc("33");

		
		
		List<GroupOccurs> listOccurs = new ArrayList<>();
		for(int x = 0; x < 15; x++){
			GroupOccurs occurs = new GroupOccurs();
			occurs.setWksN012EcMovCiclo(1);
			occurs.setWksN012EcMovConcept("2");
			occurs.setWksN012EcMovCiclo(3);
			occurs.setWksN012EcMovImpDesTrx(4.4);
			occurs.setWksN012EcMovImporte(5.5);
			occurs.setWksN012EcMovSig(6);
			occurs.setWksN012EcMovSigno("7");
			occurs.setWksN012EcMovSignoImp("8");
			occurs.setWksN012EcNumAut(9);
			occurs.setWksN012EcReferenciaNum("10");
			listOccurs.add(occurs);
		}
		beforeOutput.setOutputDetail(listOccurs);
		
		
	}
	
	@Test
	public void shouldVerifyFormatToResponse(){
		assertNotNull(responseFormatter.formatToResponse(beforeOutput));
	}

}
