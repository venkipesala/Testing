/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccounChecksMovementsOutputOkTest.java
 * Original Author: ENLM
 * Creation Date: 1/02/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.model;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

/**
 * The Class ConMovCtaMaeContOutputOkTest.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccounChecksMovementsOutputOkTest {

	/** The output ok model. */
	MaccounChecksMovementsOutputOk outputOkModel = new MaccounChecksMovementsOutputOk();

	/**
	 * Inits the data.
	 */
	@Before
	public void initData() {

		List<GroupOccurs> gpogroupOccurs = new ArrayList<GroupOccurs>();

		GroupOccurs gpoOccurs = new GroupOccurs();

		outputOkModel.setFiller3("AFR9055");
		outputOkModel.setWksN012EcResult(00);
		outputOkModel.setWksN012EcProd(6600);
		outputOkModel.setWksN012EcInst(8);
		outputOkModel.setWksN012TraDtSuc("    ");
		outputOkModel.setWksN012TraDtCta(BigInteger.valueOf(9319100545L));
		outputOkModel.setWksN012EcSigchcm("°°°°°°°°°°°°°°°°");
		outputOkModel.setWksN012EcNummovs(15);

		
		gpoOccurs.setWksN012EcMovCiclo(1);
		gpoOccurs.setWksN012EcMovFecha(160830);
		gpoOccurs.setWksN012EcMovSig(00000011);
		gpoOccurs.setWksN012EcMovConcept("DEPOSITO P/TRASPASO°°°°°°°°°°°°°°°°°°°°");
		gpoOccurs.setWksN012EcMovSigno(" ");
		gpoOccurs.setWksN012EcMovImporte(9000.00);
		gpoOccurs.setWksN012EcReferenciaNum("0000000000000000");
		gpoOccurs.setWksN012EcNumAut(1194);
		gpoOccurs.setWksN012EcMovSignoImp(" ");
		gpoOccurs.setWksN012EcMovImpDesTrx(9000.00);
		
		gpogroupOccurs.add(gpoOccurs);
		
		outputOkModel.setOutputDetail(gpogroupOccurs);		
	}

	/**
	 * Should get output ok model values.
	 */
	@Test
	public void shouldGetOutputOkModelValues() {
		
		assertEquals("AFR9055", outputOkModel.getFiller3());
		assertEquals(00, outputOkModel.getWksN012EcResult());
		assertEquals(6600,outputOkModel.getWksN012EcProd());
		assertEquals(8, outputOkModel.getWksN012EcInst());
		assertEquals("    ", outputOkModel.getWksN012TraDtSuc());
		assertEquals(BigInteger.valueOf(9319100545L), outputOkModel.getWksN012TraDtCta());
		assertEquals("°°°°°°°°°°°°°°°°", outputOkModel.getWksN012EcSigchcm());
		assertEquals(15, outputOkModel.getWksN012EcNummovs());
		 for (GroupOccurs itemOcurr : outputOkModel.getOutputDetail()) {
	        	assertEquals(1,itemOcurr.getWksN012EcMovCiclo());
	        	assertEquals(160830,itemOcurr.getWksN012EcMovFecha());
	        	assertEquals(00000011,itemOcurr.getWksN012EcMovSig());
	        	assertEquals("DEPOSITO P/TRASPASO°°°°°°°°°°°°°°°°°°°°",itemOcurr.getWksN012EcMovConcept());
	        	assertEquals(" ",itemOcurr.getWksN012EcMovSigno());
	        	assertEquals(9000.00d,itemOcurr.getWksN012EcMovImporte(),0);
	     //   	assertTrue(Math.abs(9000- itemOcurr.getWksN012EcMovImporte()) == 0);
	        	assertEquals("0000000000000000",itemOcurr.getWksN012EcReferenciaNum());
	        	assertEquals(1194,itemOcurr.getWksN012EcNumAut());
	        	assertEquals(" ",itemOcurr.getWksN012EcMovSignoImp());
	        	assertEquals(9000.00d,itemOcurr.getWksN012EcMovImpDesTrx(),0);
	     //   	assertTrue(Math.abs(9000 - itemOcurr.getWksN012EcMovImpDesTrx()) == 0);
	      
			} 
		
	}

}
