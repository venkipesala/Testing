/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: MaccountCheckMovementsResponseTest.java
 * Original Author: ENLM
 * Creation Date: 31/01/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.query.response;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

/**
 *  <code>MaccountCheckMovementsResponseTest</code>.
 *
 * @author el14811
 * @version 1.0
 */
public class MaccountCheckMovementsResponseTest {
	
	/** response. */
	MaccountCheckMovementsResponse response = new MaccountCheckMovementsResponse();
	
	/**
	 * Initial data.
	 */
	@Before
	public void initialData() {
		
		response.setSuffix("001");
		response.setResultZeros(2);
		response.setProductID(3);
		response.setInstrumentID(4);
		response.setBranchID("    ");
		response.setAccountNumber(BigInteger.valueOf(345607));
		response.setNextMovement("00000");
		response.setQuantityNumber(6);	
		InnerOcurrs detail = new InnerOcurrs();
		detail.setCycleCount(2);
		detail.setTransactionDate(3);
		detail.setSequenceNumber(4);
		detail.setDescription("3400");
		detail.setSignAmount("000001");
		detail.setTransactionAmount(20.00);
		detail.setReferenceNumber("3450000");
		detail.setAuthorizationNumber(90);
		detail.setSignAmountAfter("7899000");
		detail.setTransactionAmountAfter(70.00);
		List<InnerOcurrs> listDetail = new ArrayList<>();
		listDetail.add(detail);
		response.setGpogroupOccurs(listDetail);	
	}
	
	/**
	 * Should get response values.
	 */
	@Test
	public void shouldGetResponseValues(){
		assertEquals("001", response.getSuffix());
		assertEquals(2, response.getResultZeros());
		assertEquals(3, response.getProductID());
		assertEquals(4, response.getInstrumentID());
		assertEquals("    ", response.getBranchID());
		assertEquals(BigInteger.valueOf(345607), response.getAccountNumber());
		assertEquals("00000", response.getNextMovement());
		assertEquals(6, response.getQuantityNumber());
		InnerOcurrs detail = response.getGpogroupOccurs().get(0);
		assertEquals(2, detail.getCycleCount());
		assertEquals(3, detail.getTransactionDate());
		assertEquals(4, detail.getSequenceNumber());
		assertEquals("3400", detail.getDescription());
		assertEquals("000001", detail.getSignAmount());
		assertTrue(Math.abs(20.00- detail.getTransactionAmount()) == 0);
		assertEquals("3450000", detail.getReferenceNumber());
		assertEquals(90, detail.getAuthorizationNumber());
		assertEquals("7899000", detail.getSignAmountAfter());
		assertTrue(Math.abs(70.00- detail.getTransactionAmountAfter()) == 0);
	}	
}
