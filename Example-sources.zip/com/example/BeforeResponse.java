
package com.example;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "accountNumber",
    "annualPercentageCycle",
    "annualPercentageYield",
    "authorizedUserWaiverDurationNumber",
    "balanceAmount",
    "balanceStartAmount",
    "branchID",
    "chargeOffAmount",
    "creditAvailableAmount",
    "creditUsedAmount",
    "customerId",
    "customerName",
    "cutoffDay",
    "cycleAverageBalanceAmount",
    "daysOftheCycle",
    "daysOftheYear",
    "deliveryReferenceNumber",
    "depositDueAmount",
    "destinationCountryTaxAmount",
    "entrySequenceNumber",
    "financialCreditLineAmount",
    "gpogroupOccurs",
    "instrumentID",
    "interestPayCycleDay",
    "interestPayCycleYear",
    "lastAccessDate",
    "nextMovement",
    "outSequenceNumber",
    "periodRate",
    "productID",
    "quantityNumber",
    "resultZeros",
    "signBalanceAmount",
    "signBalanceStartAmount",
    "startDate",
    "stopDate",
    "suffix",
    "yearAverageBalanceAmount"
})
public class BeforeResponse implements Serializable
{

    @JsonProperty("accountNumber")
    private Integer accountNumber;
    @JsonProperty("annualPercentageCycle")
    private Double annualPercentageCycle;
    @JsonProperty("annualPercentageYield")
    private Double annualPercentageYield;
    @JsonProperty("authorizedUserWaiverDurationNumber")
    private Integer authorizedUserWaiverDurationNumber;
    @JsonProperty("balanceAmount")
    private Double balanceAmount;
    @JsonProperty("balanceStartAmount")
    private Double balanceStartAmount;
    @JsonProperty("branchID")
    private Integer branchID;
    @JsonProperty("chargeOffAmount")
    private Integer chargeOffAmount;
    @JsonProperty("creditAvailableAmount")
    private Integer creditAvailableAmount;
    @JsonProperty("creditUsedAmount")
    private Integer creditUsedAmount;
    @JsonProperty("customerId")
    private Integer customerId;
    @JsonProperty("customerName")
    private String customerName;
    @JsonProperty("cutoffDay")
    private Integer cutoffDay;
    @JsonProperty("cycleAverageBalanceAmount")
    private Double cycleAverageBalanceAmount;
    @JsonProperty("daysOftheCycle")
    private Integer daysOftheCycle;
    @JsonProperty("daysOftheYear")
    private Integer daysOftheYear;
    @JsonProperty("deliveryReferenceNumber")
    private Integer deliveryReferenceNumber;
    @JsonProperty("depositDueAmount")
    private Integer depositDueAmount;
    @JsonProperty("destinationCountryTaxAmount")
    private Double destinationCountryTaxAmount;
    @JsonProperty("entrySequenceNumber")
    private Integer entrySequenceNumber;
    @JsonProperty("financialCreditLineAmount")
    private Integer financialCreditLineAmount;
    @JsonProperty("gpogroupOccurs")
    private List<GpogroupOccur> gpogroupOccurs = null;
    @JsonProperty("instrumentID")
    private Integer instrumentID;
    @JsonProperty("interestPayCycleDay")
    private Double interestPayCycleDay;
    @JsonProperty("interestPayCycleYear")
    private Double interestPayCycleYear;
    @JsonProperty("lastAccessDate")
    private Integer lastAccessDate;
    @JsonProperty("nextMovement")
    private String nextMovement;
    @JsonProperty("outSequenceNumber")
    private Integer outSequenceNumber;
    @JsonProperty("periodRate")
    private Double periodRate;
    @JsonProperty("productID")
    private Integer productID;
    @JsonProperty("quantityNumber")
    private Integer quantityNumber;
    @JsonProperty("resultZeros")
    private Integer resultZeros;
    @JsonProperty("signBalanceAmount")
    private String signBalanceAmount;
    @JsonProperty("signBalanceStartAmount")
    private String signBalanceStartAmount;
    @JsonProperty("startDate")
    private Integer startDate;
    @JsonProperty("stopDate")
    private Integer stopDate;
    @JsonProperty("suffix")
    private String suffix;
    @JsonProperty("yearAverageBalanceAmount")
    private Double yearAverageBalanceAmount;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 1854809977740271983L;

    @JsonProperty("accountNumber")
    public Integer getAccountNumber() {
        return accountNumber;
    }

    @JsonProperty("accountNumber")
    public void setAccountNumber(Integer accountNumber) {
        this.accountNumber = accountNumber;
    }

    @JsonProperty("annualPercentageCycle")
    public Double getAnnualPercentageCycle() {
        return annualPercentageCycle;
    }

    @JsonProperty("annualPercentageCycle")
    public void setAnnualPercentageCycle(Double annualPercentageCycle) {
        this.annualPercentageCycle = annualPercentageCycle;
    }

    @JsonProperty("annualPercentageYield")
    public Double getAnnualPercentageYield() {
        return annualPercentageYield;
    }

    @JsonProperty("annualPercentageYield")
    public void setAnnualPercentageYield(Double annualPercentageYield) {
        this.annualPercentageYield = annualPercentageYield;
    }

    @JsonProperty("authorizedUserWaiverDurationNumber")
    public Integer getAuthorizedUserWaiverDurationNumber() {
        return authorizedUserWaiverDurationNumber;
    }

    @JsonProperty("authorizedUserWaiverDurationNumber")
    public void setAuthorizedUserWaiverDurationNumber(Integer authorizedUserWaiverDurationNumber) {
        this.authorizedUserWaiverDurationNumber = authorizedUserWaiverDurationNumber;
    }

    @JsonProperty("balanceAmount")
    public Double getBalanceAmount() {
        return balanceAmount;
    }

    @JsonProperty("balanceAmount")
    public void setBalanceAmount(Double balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    @JsonProperty("balanceStartAmount")
    public Double getBalanceStartAmount() {
        return balanceStartAmount;
    }

    @JsonProperty("balanceStartAmount")
    public void setBalanceStartAmount(Double balanceStartAmount) {
        this.balanceStartAmount = balanceStartAmount;
    }

    @JsonProperty("branchID")
    public Integer getBranchID() {
        return branchID;
    }

    @JsonProperty("branchID")
    public void setBranchID(Integer branchID) {
        this.branchID = branchID;
    }

    @JsonProperty("chargeOffAmount")
    public Integer getChargeOffAmount() {
        return chargeOffAmount;
    }

    @JsonProperty("chargeOffAmount")
    public void setChargeOffAmount(Integer chargeOffAmount) {
        this.chargeOffAmount = chargeOffAmount;
    }

    @JsonProperty("creditAvailableAmount")
    public Integer getCreditAvailableAmount() {
        return creditAvailableAmount;
    }

    @JsonProperty("creditAvailableAmount")
    public void setCreditAvailableAmount(Integer creditAvailableAmount) {
        this.creditAvailableAmount = creditAvailableAmount;
    }

    @JsonProperty("creditUsedAmount")
    public Integer getCreditUsedAmount() {
        return creditUsedAmount;
    }

    @JsonProperty("creditUsedAmount")
    public void setCreditUsedAmount(Integer creditUsedAmount) {
        this.creditUsedAmount = creditUsedAmount;
    }

    @JsonProperty("customerId")
    public Integer getCustomerId() {
        return customerId;
    }

    @JsonProperty("customerId")
    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    @JsonProperty("customerName")
    public String getCustomerName() {
        return customerName;
    }

    @JsonProperty("customerName")
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    @JsonProperty("cutoffDay")
    public Integer getCutoffDay() {
        return cutoffDay;
    }

    @JsonProperty("cutoffDay")
    public void setCutoffDay(Integer cutoffDay) {
        this.cutoffDay = cutoffDay;
    }

    @JsonProperty("cycleAverageBalanceAmount")
    public Double getCycleAverageBalanceAmount() {
        return cycleAverageBalanceAmount;
    }

    @JsonProperty("cycleAverageBalanceAmount")
    public void setCycleAverageBalanceAmount(Double cycleAverageBalanceAmount) {
        this.cycleAverageBalanceAmount = cycleAverageBalanceAmount;
    }

    @JsonProperty("daysOftheCycle")
    public Integer getDaysOftheCycle() {
        return daysOftheCycle;
    }

    @JsonProperty("daysOftheCycle")
    public void setDaysOftheCycle(Integer daysOftheCycle) {
        this.daysOftheCycle = daysOftheCycle;
    }

    @JsonProperty("daysOftheYear")
    public Integer getDaysOftheYear() {
        return daysOftheYear;
    }

    @JsonProperty("daysOftheYear")
    public void setDaysOftheYear(Integer daysOftheYear) {
        this.daysOftheYear = daysOftheYear;
    }

    @JsonProperty("deliveryReferenceNumber")
    public Integer getDeliveryReferenceNumber() {
        return deliveryReferenceNumber;
    }

    @JsonProperty("deliveryReferenceNumber")
    public void setDeliveryReferenceNumber(Integer deliveryReferenceNumber) {
        this.deliveryReferenceNumber = deliveryReferenceNumber;
    }

    @JsonProperty("depositDueAmount")
    public Integer getDepositDueAmount() {
        return depositDueAmount;
    }

    @JsonProperty("depositDueAmount")
    public void setDepositDueAmount(Integer depositDueAmount) {
        this.depositDueAmount = depositDueAmount;
    }

    @JsonProperty("destinationCountryTaxAmount")
    public Double getDestinationCountryTaxAmount() {
        return destinationCountryTaxAmount;
    }

    @JsonProperty("destinationCountryTaxAmount")
    public void setDestinationCountryTaxAmount(Double destinationCountryTaxAmount) {
        this.destinationCountryTaxAmount = destinationCountryTaxAmount;
    }

    @JsonProperty("entrySequenceNumber")
    public Integer getEntrySequenceNumber() {
        return entrySequenceNumber;
    }

    @JsonProperty("entrySequenceNumber")
    public void setEntrySequenceNumber(Integer entrySequenceNumber) {
        this.entrySequenceNumber = entrySequenceNumber;
    }

    @JsonProperty("financialCreditLineAmount")
    public Integer getFinancialCreditLineAmount() {
        return financialCreditLineAmount;
    }

    @JsonProperty("financialCreditLineAmount")
    public void setFinancialCreditLineAmount(Integer financialCreditLineAmount) {
        this.financialCreditLineAmount = financialCreditLineAmount;
    }

    @JsonProperty("gpogroupOccurs")
    public List<GpogroupOccur> getGpogroupOccurs() {
        return gpogroupOccurs;
    }

    @JsonProperty("gpogroupOccurs")
    public void setGpogroupOccurs(List<GpogroupOccur> gpogroupOccurs) {
        this.gpogroupOccurs = gpogroupOccurs;
    }

    @JsonProperty("instrumentID")
    public Integer getInstrumentID() {
        return instrumentID;
    }

    @JsonProperty("instrumentID")
    public void setInstrumentID(Integer instrumentID) {
        this.instrumentID = instrumentID;
    }

    @JsonProperty("interestPayCycleDay")
    public Double getInterestPayCycleDay() {
        return interestPayCycleDay;
    }

    @JsonProperty("interestPayCycleDay")
    public void setInterestPayCycleDay(Double interestPayCycleDay) {
        this.interestPayCycleDay = interestPayCycleDay;
    }

    @JsonProperty("interestPayCycleYear")
    public Double getInterestPayCycleYear() {
        return interestPayCycleYear;
    }

    @JsonProperty("interestPayCycleYear")
    public void setInterestPayCycleYear(Double interestPayCycleYear) {
        this.interestPayCycleYear = interestPayCycleYear;
    }

    @JsonProperty("lastAccessDate")
    public Integer getLastAccessDate() {
        return lastAccessDate;
    }

    @JsonProperty("lastAccessDate")
    public void setLastAccessDate(Integer lastAccessDate) {
        this.lastAccessDate = lastAccessDate;
    }

    @JsonProperty("nextMovement")
    public String getNextMovement() {
        return nextMovement;
    }

    @JsonProperty("nextMovement")
    public void setNextMovement(String nextMovement) {
        this.nextMovement = nextMovement;
    }

    @JsonProperty("outSequenceNumber")
    public Integer getOutSequenceNumber() {
        return outSequenceNumber;
    }

    @JsonProperty("outSequenceNumber")
    public void setOutSequenceNumber(Integer outSequenceNumber) {
        this.outSequenceNumber = outSequenceNumber;
    }

    @JsonProperty("periodRate")
    public Double getPeriodRate() {
        return periodRate;
    }

    @JsonProperty("periodRate")
    public void setPeriodRate(Double periodRate) {
        this.periodRate = periodRate;
    }

    @JsonProperty("productID")
    public Integer getProductID() {
        return productID;
    }

    @JsonProperty("productID")
    public void setProductID(Integer productID) {
        this.productID = productID;
    }

    @JsonProperty("quantityNumber")
    public Integer getQuantityNumber() {
        return quantityNumber;
    }

    @JsonProperty("quantityNumber")
    public void setQuantityNumber(Integer quantityNumber) {
        this.quantityNumber = quantityNumber;
    }

    @JsonProperty("resultZeros")
    public Integer getResultZeros() {
        return resultZeros;
    }

    @JsonProperty("resultZeros")
    public void setResultZeros(Integer resultZeros) {
        this.resultZeros = resultZeros;
    }

    @JsonProperty("signBalanceAmount")
    public String getSignBalanceAmount() {
        return signBalanceAmount;
    }

    @JsonProperty("signBalanceAmount")
    public void setSignBalanceAmount(String signBalanceAmount) {
        this.signBalanceAmount = signBalanceAmount;
    }

    @JsonProperty("signBalanceStartAmount")
    public String getSignBalanceStartAmount() {
        return signBalanceStartAmount;
    }

    @JsonProperty("signBalanceStartAmount")
    public void setSignBalanceStartAmount(String signBalanceStartAmount) {
        this.signBalanceStartAmount = signBalanceStartAmount;
    }

    @JsonProperty("startDate")
    public Integer getStartDate() {
        return startDate;
    }

    @JsonProperty("startDate")
    public void setStartDate(Integer startDate) {
        this.startDate = startDate;
    }

    @JsonProperty("stopDate")
    public Integer getStopDate() {
        return stopDate;
    }

    @JsonProperty("stopDate")
    public void setStopDate(Integer stopDate) {
        this.stopDate = stopDate;
    }

    @JsonProperty("suffix")
    public String getSuffix() {
        return suffix;
    }

    @JsonProperty("suffix")
    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    @JsonProperty("yearAverageBalanceAmount")
    public Double getYearAverageBalanceAmount() {
        return yearAverageBalanceAmount;
    }

    @JsonProperty("yearAverageBalanceAmount")
    public void setYearAverageBalanceAmount(Double yearAverageBalanceAmount) {
        this.yearAverageBalanceAmount = yearAverageBalanceAmount;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(accountNumber).append(annualPercentageCycle).append(annualPercentageYield).append(authorizedUserWaiverDurationNumber).append(balanceAmount).append(balanceStartAmount).append(branchID).append(chargeOffAmount).append(creditAvailableAmount).append(creditUsedAmount).append(customerId).append(customerName).append(cutoffDay).append(cycleAverageBalanceAmount).append(daysOftheCycle).append(daysOftheYear).append(deliveryReferenceNumber).append(depositDueAmount).append(destinationCountryTaxAmount).append(entrySequenceNumber).append(financialCreditLineAmount).append(gpogroupOccurs).append(instrumentID).append(interestPayCycleDay).append(interestPayCycleYear).append(lastAccessDate).append(nextMovement).append(outSequenceNumber).append(periodRate).append(productID).append(quantityNumber).append(resultZeros).append(signBalanceAmount).append(signBalanceStartAmount).append(startDate).append(stopDate).append(suffix).append(yearAverageBalanceAmount).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof BeforeResponse) == false) {
            return false;
        }
        BeforeResponse rhs = ((BeforeResponse) other);
        return new EqualsBuilder().append(accountNumber, rhs.accountNumber).append(annualPercentageCycle, rhs.annualPercentageCycle).append(annualPercentageYield, rhs.annualPercentageYield).append(authorizedUserWaiverDurationNumber, rhs.authorizedUserWaiverDurationNumber).append(balanceAmount, rhs.balanceAmount).append(balanceStartAmount, rhs.balanceStartAmount).append(branchID, rhs.branchID).append(chargeOffAmount, rhs.chargeOffAmount).append(creditAvailableAmount, rhs.creditAvailableAmount).append(creditUsedAmount, rhs.creditUsedAmount).append(customerId, rhs.customerId).append(customerName, rhs.customerName).append(cutoffDay, rhs.cutoffDay).append(cycleAverageBalanceAmount, rhs.cycleAverageBalanceAmount).append(daysOftheCycle, rhs.daysOftheCycle).append(daysOftheYear, rhs.daysOftheYear).append(deliveryReferenceNumber, rhs.deliveryReferenceNumber).append(depositDueAmount, rhs.depositDueAmount).append(destinationCountryTaxAmount, rhs.destinationCountryTaxAmount).append(entrySequenceNumber, rhs.entrySequenceNumber).append(financialCreditLineAmount, rhs.financialCreditLineAmount).append(gpogroupOccurs, rhs.gpogroupOccurs).append(instrumentID, rhs.instrumentID).append(interestPayCycleDay, rhs.interestPayCycleDay).append(interestPayCycleYear, rhs.interestPayCycleYear).append(lastAccessDate, rhs.lastAccessDate).append(nextMovement, rhs.nextMovement).append(outSequenceNumber, rhs.outSequenceNumber).append(periodRate, rhs.periodRate).append(productID, rhs.productID).append(quantityNumber, rhs.quantityNumber).append(resultZeros, rhs.resultZeros).append(signBalanceAmount, rhs.signBalanceAmount).append(signBalanceStartAmount, rhs.signBalanceStartAmount).append(startDate, rhs.startDate).append(stopDate, rhs.stopDate).append(suffix, rhs.suffix).append(yearAverageBalanceAmount, rhs.yearAverageBalanceAmount).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
