
package com.example;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "afterResponse",
    "beforeResponse",
    "movementsResponse"
})
public class Example implements Serializable
{

    @JsonProperty("afterResponse")
    private Object afterResponse;
    @JsonProperty("beforeResponse")
    private BeforeResponse beforeResponse;
    @JsonProperty("movementsResponse")
    private Object movementsResponse;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 2553534081802767450L;

    @JsonProperty("afterResponse")
    public Object getAfterResponse() {
        return afterResponse;
    }

    @JsonProperty("afterResponse")
    public void setAfterResponse(Object afterResponse) {
        this.afterResponse = afterResponse;
    }

    @JsonProperty("beforeResponse")
    public BeforeResponse getBeforeResponse() {
        return beforeResponse;
    }

    @JsonProperty("beforeResponse")
    public void setBeforeResponse(BeforeResponse beforeResponse) {
        this.beforeResponse = beforeResponse;
    }

    @JsonProperty("movementsResponse")
    public Object getMovementsResponse() {
        return movementsResponse;
    }

    @JsonProperty("movementsResponse")
    public void setMovementsResponse(Object movementsResponse) {
        this.movementsResponse = movementsResponse;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(afterResponse).append(beforeResponse).append(movementsResponse).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Example) == false) {
            return false;
        }
        Example rhs = ((Example) other);
        return new EqualsBuilder().append(afterResponse, rhs.afterResponse).append(beforeResponse, rhs.beforeResponse).append(movementsResponse, rhs.movementsResponse).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
