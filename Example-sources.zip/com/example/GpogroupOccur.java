
package com.example;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "authorizationNumber",
    "cycleCount",
    "description",
    "referenceNumber",
    "sequenceNumber",
    "signAmount",
    "signAmountAfter",
    "transactionAmount",
    "transactionAmountAfter",
    "transactionDate"
})
public class GpogroupOccur implements Serializable
{

    @JsonProperty("authorizationNumber")
    private Integer authorizationNumber;
    @JsonProperty("cycleCount")
    private Integer cycleCount;
    @JsonProperty("description")
    private String description;
    @JsonProperty("referenceNumber")
    private String referenceNumber;
    @JsonProperty("sequenceNumber")
    private Integer sequenceNumber;
    @JsonProperty("signAmount")
    private String signAmount;
    @JsonProperty("signAmountAfter")
    private String signAmountAfter;
    @JsonProperty("transactionAmount")
    private Double transactionAmount;
    @JsonProperty("transactionAmountAfter")
    private Double transactionAmountAfter;
    @JsonProperty("transactionDate")
    private Integer transactionDate;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -2221179678874871194L;

    @JsonProperty("authorizationNumber")
    public Integer getAuthorizationNumber() {
        return authorizationNumber;
    }

    @JsonProperty("authorizationNumber")
    public void setAuthorizationNumber(Integer authorizationNumber) {
        this.authorizationNumber = authorizationNumber;
    }

    @JsonProperty("cycleCount")
    public Integer getCycleCount() {
        return cycleCount;
    }

    @JsonProperty("cycleCount")
    public void setCycleCount(Integer cycleCount) {
        this.cycleCount = cycleCount;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("referenceNumber")
    public String getReferenceNumber() {
        return referenceNumber;
    }

    @JsonProperty("referenceNumber")
    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    @JsonProperty("sequenceNumber")
    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    @JsonProperty("sequenceNumber")
    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    @JsonProperty("signAmount")
    public String getSignAmount() {
        return signAmount;
    }

    @JsonProperty("signAmount")
    public void setSignAmount(String signAmount) {
        this.signAmount = signAmount;
    }

    @JsonProperty("signAmountAfter")
    public String getSignAmountAfter() {
        return signAmountAfter;
    }

    @JsonProperty("signAmountAfter")
    public void setSignAmountAfter(String signAmountAfter) {
        this.signAmountAfter = signAmountAfter;
    }

    @JsonProperty("transactionAmount")
    public Double getTransactionAmount() {
        return transactionAmount;
    }

    @JsonProperty("transactionAmount")
    public void setTransactionAmount(Double transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    @JsonProperty("transactionAmountAfter")
    public Double getTransactionAmountAfter() {
        return transactionAmountAfter;
    }

    @JsonProperty("transactionAmountAfter")
    public void setTransactionAmountAfter(Double transactionAmountAfter) {
        this.transactionAmountAfter = transactionAmountAfter;
    }

    @JsonProperty("transactionDate")
    public Integer getTransactionDate() {
        return transactionDate;
    }

    @JsonProperty("transactionDate")
    public void setTransactionDate(Integer transactionDate) {
        this.transactionDate = transactionDate;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(authorizationNumber).append(cycleCount).append(description).append(referenceNumber).append(sequenceNumber).append(signAmount).append(signAmountAfter).append(transactionAmount).append(transactionAmountAfter).append(transactionDate).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof GpogroupOccur) == false) {
            return false;
        }
        GpogroupOccur rhs = ((GpogroupOccur) other);
        return new EqualsBuilder().append(authorizationNumber, rhs.authorizationNumber).append(cycleCount, rhs.cycleCount).append(description, rhs.description).append(referenceNumber, rhs.referenceNumber).append(sequenceNumber, rhs.sequenceNumber).append(signAmount, rhs.signAmount).append(signAmountAfter, rhs.signAmountAfter).append(transactionAmount, rhs.transactionAmount).append(transactionAmountAfter, rhs.transactionAmountAfter).append(transactionDate, rhs.transactionDate).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
